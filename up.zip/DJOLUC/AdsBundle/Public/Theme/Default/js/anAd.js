$(document).ready(function(){
    //alert("ok");
    
    /*$(".pic_form > progress").attr("style", "display: inline-block;");
    new FormSubmit($(".pic_form").attr("action")+"/ajax", "pic_form", function(result){
        //alert(result);
        var rep = JSON.parse(result);
        
        if(rep.result){
            document.location.reload();
        }
    }, function(){
        alert("Error, please try again");
    });*/
    
    
    
    /*$("span.current").click(function(){
        if($("span.current").attr("style") === "transform: scale(1.1)"){
            $("span.current").attr("style", "");
        }else{
            $(this).attr("style", "transform: scale(1.1)");
        }
    });*/
    
    $('#i_submit').click( function(e) {
	//check whether browser fully supports all File API
	if (window.File && window.FileReader && window.FileList && window.Blob)
	{
		//get the file size and file type from file input field
		var fsize = $('#i_file')[0].files[0].size;
		
		if(fsize/1000>200) //do something if file size more than 1 mb (1048576)
		{
                    e.preventDefault();
                    alert(fsize/1000 +" kb is \nToo big. Please choose a file with 200kb max.");
		}/*else{
			alert(fsize +" bites\nYou are good to go!");
		}*/
	}else{
		alert("Please upgrade your browser, because your current browser lacks some new features we need!");
	}
});
    
    
    if($(".apply_button").length){
        
        $(".apply_form_ul").attr("style","display: none;");        
        $(".apply_button").click(function(e){
            e.preventDefault();
            //alert($(".apply_form_ul").attr("style"));
            if($(".apply_form_ul").attr("style") === "display: none;"){
                $(".apply_form_ul").attr("style","display: inline-block;");
            }else{
                $(".apply_form_ul").attr("style","display: none;");        
            }
        });
    }
    
    $("#page_div > .adsPicture img").click(function(e){
        e.preventDefault();
        if($(this).attr("bigLink")){
            new PictureDialog(JSON.parse($("input[name='pictures']").val()), $(this).attr("bigLink"));
        }
    });
});



var PictureDialog = function(pictures, currentPicture = ""){
    this.currentIndex = 0;
    for(var i = 0; i < pictures.length; i++){
        if(pictures[i] === currentPicture){
            this.currentIndex = i;
            break;
        }
    }
    this.pictures = pictures;
    
    var thisObject = this;
    
    this.init = function(){
        $("body").append( 
        '<dialog class="picturesViewDialog" style="display: none; transform: scale(0.0);">'+
            '<span class="header"> <button class="close" style="background: transparent;"><i class="fa fa-times"></i></button></span>'+
            '<button class="button_left"><i class="fa fa-chevron-left"></i></button>'+
            '<div class="picture_contener"></div>'+
            '<button class="button_right"><i class="fa fa-chevron-right"></i></button>'+
       '</dialog>'
        );
        $(".picturesViewDialog").attr("style", "display: block; transform: scale(0.0);");
        window.setTimeout(function(){
            $(".picturesViewDialog").attr("style", "display: block; transform: scale(1.0);");
            window.clearTimeout(this);
        }, 100);
        $(".picturesViewDialog > .picture_contener").html("");
        $(".picturesViewDialog > .picture_contener").append("<img src='"+this.pictures[this.currentIndex]+"' />");
        
        if(thisObject.currentIndex === thisObject.pictures.length - 1){
            $(".picturesViewDialog > .button_right").attr("style", "display: none;");
        }
        
        if(thisObject.currentIndex === 0){
            $(".picturesViewDialog > .button_left").attr("style", "display: none;");
        }
        
    };
    this.init();
    
    this.displayCurrrent = function(){
        $(".picturesViewDialog > .picture_contener").html("");
        $(".picturesViewDialog > .picture_contener").append("<img src='"+this.pictures[this.currentIndex]+"' />");
    };
    
    $(".picturesViewDialog > .header > .close").click(function(){
        $(".picturesViewDialog").attr("style", "display: block; transform: scale(0.0);");
        window.setTimeout(function(){
            $(".picturesViewDialog").attr("style", "display: none; transform: scale(0.1);");
            $(".picturesViewDialog").remove();
            window.clearTimeout(this);
        }, 500);
    });
    
    $(".picturesViewDialog > .button_left").click(function(){
        //alert(thisObject.currentIndex);
        if(thisObject.currentIndex > 0){
            thisObject.currentIndex--;
            thisObject.displayCurrrent();
        }
        
        if(thisObject.currentIndex === 0){
            $(this).attr("style", "display: none;");
        }
        
        $(".picturesViewDialog > .button_right").attr("style", "display: inline-block;");
    });
    
    $(".picturesViewDialog > .button_right").click(function(){
        //alert(thisObject.currentIndex);
        if(thisObject.currentIndex < thisObject.pictures.length - 1){
            thisObject.currentIndex++;
            thisObject.displayCurrrent();
        }
        
        if(thisObject.currentIndex === thisObject.pictures.length - 1){
            $(this).attr("style", "display: none;");
        }
        
        $(".picturesViewDialog > .button_left").attr("style", "display: inline-block;");
    });
};