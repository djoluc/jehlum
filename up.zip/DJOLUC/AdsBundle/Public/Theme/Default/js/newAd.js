$(document).ready(function(){
    var jobCat = '<optgroup class="jobGroupe" label="Job categories">'+$(".jobGroupe").html()+'</optgroup>';
    var classfieldCat = '<optgroup class="classfieldGroupe" label="Classfield categories">'+$(".classfieldGroupe").html()+'</optgroup>';
    $(".categories").html(jobCat);
    $(".type").change(function(){
        if(!$(".jobType")[0].checked){
            for(var i = 0; i < $(".jobGroupe > option").length; i++){
                if($(".jobGroupe > option")[i].selected){
                    $(".jobGroupe > option")[i].selected = false;
                }
            }
            $(".categories").html(classfieldCat);
        }else{
            for(var i = 0; i < $(".classfieldGroupe > option").length; i++){
                if($(".classfieldGroupe > option")[i].selected){
                    $(".classfieldGroupe > option")[i].selected = false;
                }
            }
            $(".categories").html(jobCat);
        }
    });
    
    
    
    $(".addPic").click(function(e){
        e.preventDefault();
        count = $(".multipleImageField > .select input[type='file']").length;
        if(count == 10){
           $(".addPic").attr("style", "display: none;");
        }
        $(".multipleImageField > .select").append('<div class="no-jsSelect"><input type="file" name="picture'+(count+1)+'" max="2" maxlength="2" value="" accept=".jpg, .jpeg, .gif, .png" /></div>');
    });
    /*new MultipleImageField();
    //alert($(".newAdForm progress").length);
    $(".newAdForm").submit(function(){
        $(".newAdForm button[type='submit'] i").attr("style", "inline-block;");
    });
    new FormSubmit($(".newAdForm").attr("action")+"/ajax", "newAdForm", function(result){
        $(".newAdForm button[type='submit'] i").attr("style", "none;");
        //alert(result);
        
        var rep = JSON.parse(result);
        
        if(rep.result){
            if(rep.email.length <= 0){
                document.location.replace("/adsManage/view/"+rep.adId+"");
            }else{
                alert("We just send you a mail on "+rep.email+". Please check your inbox/spambox to verify your email ID.");
                document.location.reload();
            }
        }else{
            alert("Error from server. Please try again");
        }
    }, function(){
        alert("Error, please try again");
    });*/
});