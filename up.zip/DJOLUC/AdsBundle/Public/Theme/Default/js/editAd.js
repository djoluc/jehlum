$(document).ready(function(){
    var jobCat = '<optgroup class="jobGroupe" label="Job categories">'+$(".jobGroupe").html()+'</optgroup>';
    var classfieldCat = '<optgroup class="classfieldGroupe" label="Classfield categories">'+$(".classfieldGroupe").html()+'</optgroup>';
    //$(".categories").html(jobCat);
    $(".type").change(function(){
        if(!$(".jobType")[0].checked){
            for(var i = 0; i < $(".jobGroupe > option").length; i++){
                if($(".jobGroupe > option")[i].selected){
                    $(".jobGroupe > option")[i].selected = false;
                }
            }
            $(".categories").html(classfieldCat);
        }else{
            for(var i = 0; i < $(".classfieldGroupe > option").length; i++){
                if($(".classfieldGroupe > option")[i].selected){
                    $(".classfieldGroupe > option")[i].selected = false;
                }
            }
            if($(".jobGroupe").length){
                for(var i = 0; i < $(".jobGroupe > option").length; i++){
                    if($(".jobGroupe > option")[i].selected){
                        $(".jobGroupe > option")[i].selected = false;
                    }
                }
            }
            $(".categories").html(jobCat);
        }
    });
});