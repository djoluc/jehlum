<?php

namespace DJOLUC\AdsBundle\Controller\Frontend;

/**
 * Description of AdsMainController
 *
 * @author djoluc
 */
class AdsMainController extends \App\Controller\BaseController{
    private $userDataSource, 
            $adsCategoryDataSource, 
            $adsLocationDataSource, 
            $adAuthorMailDataSource,
            $adsDataSource,
            $blackListDataSource,
            $userId,
            $user, 
            $isModoOrMore, 
            $isMiniAdmOrMore, 
            $isConnectedUser;
    
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsCategoryDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource();
        $this->adsLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsLocationDataSource();
        $this->adAuthorMailDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdAuthorMailDataSource();
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->blackListDataSource = new \DJOLUC\AdsBundle\Model\Backend\BlackListDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->user = $this->userDataSource->getUser($this->userId);
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $this->isConnectedUser = $this->userId > 0;
    }
    
    
    public function newAdsAction($message = ""){
        
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore,
            "isConnectedUser" => $this->isConnectedUser,
            "ClassfieldCategoriesOptions" => $this->adsCategoryDataSource->getTypeCategoriesAsHtmlOptions(\DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource::CLASSFIELD_TYPE),
            "jobCategoriesOptions" => $this->adsCategoryDataSource->getTypeCategoriesAsHtmlOptions(\DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource::JOB_TYPE),
            "locationsOptions" => $this->adsLocationDataSource->getAllLocationAsHtmlOptions(),
            "message" => $message
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/newAdsView.php");
    }
    
    

    
    public function addAction(){
        $out = Array(
            "result" => FALSE, 
            "message" => "Error when adding your add", 
        ); 
        
        $newAdsId = 0;
        
        if(array_key_exists("sent", $_POST)){
            require_once 'DJOLUC/Helper/php/fonct.php';
            $title = $this->getPostString("title");
            //$category = $this->getPostInt("category");
            $categories = $_POST["category"];
            $locations = $_POST["location"];
            $description = $this->getPostString("description");
            
            
            if($this->isConnectedUser){
                
                if($this->blackListDataSource->isInBlackList($this->user->getUserMail())){
                    $this->throwException("You are unable to post an ad. Please contact us on <b>info@jehlum.org</b>");
                }
                
                if($newAdsId = $this->adsDataSource->addAds($title, $description, $this->userId, FALSE, \time())){
                    $anAdLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AnAdLocationDataSource();
                    $anAdCategoryDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AnAdCategoryDataSource();
                    foreach ($locations AS $locationId){
                        $anAdLocationDataSource->addAdLocation($newAdsId, $locationId);
                    }
                    foreach ($categories AS $categoryId){
                        $anAdCategoryDataSource->addAdCategory($newAdsId, $categoryId);
                    }
                    $out["result"] = TRUE;
                    
                    if($this->isMiniAdmOrMore){
                        $this->adsDataSource->setAdsActivate($newAdsId);
                    }
                    
                    $this->adAuthorMailDataSource->addAdAuthorEmail($newAdsId, $this->user->getUserMail(), "", TRUE);
                    $out["email"] = $this->user->getUserMail();
                    if($this->isMiniAdmOrMore){
                        $out["email"] = "";
                        $out["adId"] = $newAdsId;
                    }
                    
                    $adsMediaDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource();
                    $adsManageController = new AdsManageController();
                    $firstPicTime = 0;
                    for($i = 1; $i <= 10; $i++){
                        if(array_key_exists("picture".$i."", $_FILES) && !empty($_FILES["picture".$i.""]["tmp_name"])){
                            $fileUploader = new \DJOLUC\Helper\php\FileUploader("picture".$i."", "runningData/AdsMedia/Image", $this->userId, "image", "time_name", "");
                            $time = time();
                            if($fileUploader->upload(false)){
                                if($i == 1) $firstPicTime = $time+$i;
                                $adsMediaDataSource->addAdsMedia($newAdsId, \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource::MEDIA_IMAGE_TYPE, $fileUploader->getFileName(), TRUE, "", $time+$i, 0, 0);
                            }
                            try{
                                $adsManageController->addWaterMarkAndBorderToPicture($fileUploader->getFileDir()."/".$fileUploader->getFileName());
                                miniature($fileUploader->getFileDir(), 200, $fileUploader->getFileDir()."/mini", $fileUploader->getFileName());
                            } catch (Exception $ex) {
                                $this->throwException("Error, invalid picture selected.");
                            }
                        }
                    }
                    $adsMediaDataSource->setAsCurrent($newAdsId, $firstPicTime);
                    /*if(count($_FILES["pictures"]["tmp_name"]) > 0){
                        $fileUploader = new \DJOLUC\Helper\php\FileUploader("pictures", "runningData/AdsMedia/Image", $this->userId, "image", "time_name", "");
                        $time = time();
                        for($i = 0; $i < count($_FILES["pictures"]["tmp_name"]); $i++){
                            if($fileUploader->uploadMultiple($i)){
                                $adsMediaDataSource->addAdsMedia($newAdsId, \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource::MEDIA_IMAGE_TYPE, $fileUploader->getFileName(), TRUE, "", $time+$i, 0, 0);
                            }
                            try{
                                $adsManageController->addWaterMarkAndBorderToPicture($fileUploader->getFileDir()."/".$fileUploader->getFileName());
                                miniature($fileUploader->getFileDir(), 200, $fileUploader->getFileDir()."/mini", $fileUploader->getFileName());
                            } catch (Exception $ex) {
                                $this->throwException("Error, invalid picture selected.");
                            }
                            
                        }
                    }*/
                
                    
                }
            }else{
                $newUserMail = $this->getPostString("email");
                
                if($this->blackListDataSource->isInBlackList($newUserMail)){
                    $this->throwException("You are unable to post an ad. Please contact us on <b>info@jehlum.org</b>");
                }
                
                $out["email"] = $newUserMail;
                if(!$this->userDataSource->isMailUsed($newUserMail)){
                    $newUserId = $this->userDataSource->addUser(\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::NORMAL_USER_TYPE, "", "", 0, "", 1, "", $newUserMail, "", "", "", "", 0, 0, \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::SIMPLE_RANG, "", FALSE, 0, 1, \time());
                }else{
                    $newUserId = $this->userDataSource->getUserWithMail($newUserMail)->getUserId();
                }
                
               $code = md5(rand(10000000, 99999999))."";

                //activation link
                if($newAdsId = $this->adsDataSource->addAds($title, $description, $newUserId, FALSE, \time())){
                    $anAdLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AnAdLocationDataSource();
                    $anAdCategoryDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AnAdCategoryDataSource();
                    foreach ($locations AS $locationId){
                        $anAdLocationDataSource->addAdLocation($newAdsId, $locationId);
                    }
                    foreach ($categories AS $categoryId){
                        $anAdCategoryDataSource->addAdCategory($newAdsId, $categoryId);
                    }
                    $out["result"] = TRUE;
                }
                
                $this->sendVerificationMail($code, $newUserMail, $newAdsId);
                
                $this->adAuthorMailDataSource->addAdAuthorEmail($newAdsId, $newUserMail, $code, FALSE);
                
                
                    $adsMediaDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource();
                    $adsManageController = new AdsManageController();
                    $firstPicTime = 0;
                    for($i = 1; $i <= 10; $i++){
                        if(array_key_exists("picture".$i."", $_FILES) && !empty($_FILES["picture".$i.""]["tmp_name"])){
                            $fileUploader = new \DJOLUC\Helper\php\FileUploader("picture".$i."", "runningData/AdsMedia/Image", $this->userId, "image", "time_name", "");
                            $time = time();
                            if($fileUploader->upload(false)){
                                if($i == 1) $firstPicTime = $time+$i;
                                $adsMediaDataSource->addAdsMedia($newAdsId, \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource::MEDIA_IMAGE_TYPE, $fileUploader->getFileName(), TRUE, "", $time+$i, 0, 0);
                            }
                            try{
                                $adsManageController->addWaterMarkAndBorderToPicture($fileUploader->getFileDir()."/".$fileUploader->getFileName());
                                miniature($fileUploader->getFileDir(), 200, $fileUploader->getFileDir()."/mini", $fileUploader->getFileName());
                            } catch (Exception $ex) {
                                $this->throwException("Error, invalid picture selected.");
                            }
                        }
                    }
                    $adsMediaDataSource->setAsCurrent($newAdsId, $firstPicTime);
                    /*if(count($_FILES["pictures"]["tmp_name"]) > 0){
                        $fileUploader = new \DJOLUC\Helper\php\FileUploader("pictures", "runningData/AdsMedia/Image", $this->userId, "image", "time_name", "");
                        $time = time();
                        for($i = 0; $i < count($_FILES["pictures"]["tmp_name"]); $i++){
                            if($fileUploader->uploadMultiple($i)){
                                $adsMediaDataSource->addAdsMedia($newAdsId, \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource::MEDIA_IMAGE_TYPE, $fileUploader->getFileName(), TRUE, "", $time+$i, 0, 0);
                            }
                            try{
                                $adsManageController->addWaterMarkAndBorderToPicture($fileUploader->getFileDir()."/".$fileUploader->getFileName());
                                miniature($fileUploader->getFileDir(), 200, $fileUploader->getFileDir()."/mini", $fileUploader->getFileName());
                            } catch (Exception $ex) {
                                $this->throwException("Error, invalid picture selected.");
                            }
                        }
                    }*/
                
                return $this->adAutorverificationAction($newUserMail);
            }
        }
        
        if(array_key_exists("c", $_GET) && $this->getGetString("c") == "ajax"){
            print $this->printPureJson($out);
        }else{
            if($out["result"]){
                if($this->isConnectedUser){
                    header("Location: ".SITE_ROOT."adsManage/view/".$newAdsId."");
                }else{
                    header("Location: /");
                }
            }else{
                return $this->newAdsAction($out["message"]);
            }
        }
    }
    
    
    public function adsEditAction($message = ""){
        
        $tmpAdsId = $this->getGetInt("c");
        
        $ads = $this->adsDataSource->getAds($tmpAdsId);
        
        if(!$this->isMiniAdmOrMore && $this->userId != $ads->getAdsAutor()){
            $this->throwException(UNABLE_PAGE);
        }
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "adsId" => $tmpAdsId, 
            "ads" => $ads,
            "ClassfieldCategoriesOptions" => $this->adsCategoryDataSource->getTypeCategoriesAsHtmlOptions(\DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource::CLASSFIELD_TYPE, $ads->getAdsId()),
            "jobCategoriesOptions" => $this->adsCategoryDataSource->getTypeCategoriesAsHtmlOptions(\DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource::JOB_TYPE, $ads->getAdsId()),
            "locationsOptions" => $this->adsLocationDataSource->getAllLocationAsHtmlOptions($ads->getAdsId()),
            "message" => $message
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/adsEditView.php");
    }
    
    
    
    public function editAction(){
        
        $out = Array(
            "result" => FALSE, 
            "message" => "Error"
        );
        
        $tmpAdsId = $this->getGetInt("c");
        
        $ads = $this->adsDataSource->getAds($tmpAdsId);
        
        if(!$this->isMiniAdmOrMore && $this->userId != $ads->getAdsAutor()){
            $this->throwException(UNABLE_PAGE);
        }
        
        
        if(array_key_exists("sent", $_POST)){
            $title = $this->getPostString("title");
            //$category = $this->getPostInt("category");
            $categoryIds = $_POST["category"];
            $locationIds = $_POST["location"];
            $description = $this->getPostString("description");
            
            if($this->adsDataSource->updateAds($tmpAdsId, $title, $description, $this->userId, $category)){
                $anAdLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AnAdLocationDataSource();
                $anAdCategoryDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AnAdCategoryDataSource();
                $anAdLocationDataSource->updateAdLocations($tmpAdsId, $locationIds);
                $anAdCategoryDataSource->updateAdCategories($tmpAdsId, $categoryIds);
                $out["result"] = TRUE;
            }
        }
        
        if(array_key_exists("d", $_GET) && $this->getGetString("d") == "ajax"){
            $this->printPureJson($out);
        }else{
            if($out["result"]){
                header("Location: ".SITE_ROOT."adsManage/view/".$tmpAdsId."");
            }else{
                return $this->adsEditAction($out["message"]);
            }
        }
        
    }
    
    
    public function adAutorverificationAction($email = "djoluc@gmail.com"){
        
        $adId = $this->getGetInt("c");
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore, 
            "email" => $email
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/adAutorVerificationView.php");
    }
    
    
    public function verifyConfirmPageAction($adId = 0){
        
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/verifyConfirmPageView.php");
    }
    
    
    public function verifyLinkAction(){
        $adId = $this->getGetInt("c");
        $code = $this->getGetString("d");
        
        $trueCode = $this->adAuthorMailDataSource->getAdAuthorEmail($adId)->getVerifyCode();
        
        if($trueCode == $code){
            $this->adAuthorMailDataSource->setVerify($adId);
            return $this->verifyConfirmPageAction($adId);
        }else{
            $this->throwException(UNABLE_PAGE);
        }
    }
    
    
    public function sendVerificationMail($code, $email, $adId):bool{
        
        $nom_site = "Jehlum";
        $adresse_site = "admin@jehlum.org";
        $conf_pass = $code;
        
        $passage_ligne = "\n";
        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $email)) // On filtre les serveurs qui rencontrent des bogues.
	{
            $passage_ligne = "\r\n";
        }else{
            $passage_ligne = "\n";
	}
	//=====Déclaration des messages au format texte et au format HTML.
	$message_txt = "Confirm your email.";
	$message_html='<!DOCTYPE html>
			<html>
                            <head>
                                <title>Email verification for an ad on '.$nom_site.'</title>
                            </head>
                            <body style="font-size: 18px; color: rgba(0, 0, 0, 0.7); border: 5px solid cyan; width: 500px; margin: auto; padding: 10px;">
                                <h1 style="color: cadetblue; text-align: center;">Jehlum</h1>
                                <div>This mail will help you to confirm your email on '.$nom_site.'.<br/>
                                    To confirm your email, you just have to click on this button:<br/>
                                    <br/><center><a target="_blank" href="https://'.$_SERVER["HTTP_HOST"].'/ads/verifyLink/'.$adId.'/'.$code.'" style="padding: 10px; margin: auto; margin-top: 10px; width: 100px; text-decoration: none; background: orange; color: #ffffff;">Confirm my email</a></center>
                                </div>
                                <p>If you have any questions/concerns, please get back to us on info@jehlum.org.</p>
                            </body>
                        </html>';
	//==========
				
	//=====Création de la boundary
	$boundary = "-----=".md5(rand());
	//==========
				
	//=====Définition du sujet.
	$sujet = "Your ad on jehlum";
	//=========
				
	//=====Création du header de l'e-mail.
	$header = "From: \"".$nom_site."\"<".$adresse_site.">".$passage_ligne;
	$header.= "Reply-to: \"".$nom_site."\" <".$adresse_site.">".$passage_ligne;
	$header.= "MIME-Version: 1.0".$passage_ligne;
	$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"".$boundary."\" ".$passage_ligne."";
	//==========
				
	//=====Création du message.
	$message = $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format texte.
	$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_txt.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format HTML
	$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_html.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	//==========
				
	//=====Envoi de l'e-mail.
	
        return mail($email,$sujet,$message,$header);
    }
    
    
    public function displayPageAction($message = "") {
        parent::displayPageAction();
        
        $adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        
        $numb = 50; 
        $first = 0;
        if(array_key_exists("b", $_GET) && array_key_exists("c", $_GET)){
            $first = $this->getGetInt("b");
            $numb = $this->getGetInt("c");
        }
        
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", "", "", "Jehlum", true), 
            "footer"=> \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "latestAds" => $adsDataSource->getActivatedAds("", $first, $numb), 
            "allAdsNumb" => $adsDataSource->getAllActivateAdsNumb(), 
            "first" => $first, 
            "numb" => $numb
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/mainView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        
        $thisObject = new self();
        
        $thisObject->addPage("", $thisObject);
        $thisObject->addPage("newAds", $thisObject);
        $thisObject->addPage("add", $thisObject, FALSE);
        $thisObject->addPage("adsEdit", $thisObject, FALSE);
        $thisObject->addPage("edit", $thisObject, FALSE);
        $thisObject->addPage("verifyLink", $thisObject, FALSE);
        
        $thisObject->rooting($cacheDir);
    }

}
