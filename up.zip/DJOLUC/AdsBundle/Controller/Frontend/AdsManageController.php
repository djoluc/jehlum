<?php

namespace DJOLUC\AdsBundle\Controller\Frontend;

/**
 * Description of AdsManageController
 *
 * @author djoluc
 */
class AdsManageController extends \App\Controller\BaseController {
    private $userDataSource, 
            $adsCategoryDataSource, 
            $adsLocationDataSource, 
            $adsDataSource,
            $adsMediaDataSource,
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore, 
            $isConnectedUser, 
            $adsId, 
            $isAdsAuthor;
    
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsCategoryDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource();
        $this->adsLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsLocationDataSource();
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->adsMediaDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $this->isConnectedUser = $this->userId > 0;
        $this->adsId = $this->getGetInt("c");
        $this->isAdsAuthor = ($this->adsDataSource->getAds($this->adsId)->getAdsAutor() == $this->userId);
    }
    
    
    public function viewAction(){
        
        $ads = $this->adsDataSource->getAds($this->adsId);
        
        
        if(!$ads->getIsActivate() && (!$this->isMiniAdmOrMore && !$this->isAdsAuthor)){
            $this->throwException(UNABLE_PAGE);
        }
        
        $isAdminAuthor = $this->userDataSource->getUser($ads->getAdsAutor())->getUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $isModoOrMoreAuthor = $this->userDataSource->getUser($ads->getAdsAutor())->getUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", "", "", $ads->getAdsTitle()), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore, 
            "ads" => $ads,
            "moreAds" => $this->adsDataSource->getCategoryAds($ads->getAdsCategory(), "", 0, 10),
            "isAdsAuthor" => $this->isAdsAuthor, 
            "isMiniAdmOrMore" => $this->isMiniAdmOrMore, 
            "isAdminAuthor" => $isAdminAuthor, 
            "isModoOrMoreAuthor" => $isModoOrMoreAuthor
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/adsView.php");
    }
    
    
    public function addWaterMarkAndBorderToPicture($picture){
        require_once 'DJOLUC/Helper/php/fonct.php';
        
        addTextToAnImage($picture, "JEHLUM.ORG", $picture, 45, 94, 127);
        
        addBorderToImage($picture, 150, $picture, 45, 94, 127);
    }
    
    
    public function addPictureAction(){
        $out = Array(
            "result" => FALSE, 
            "message" => "Error when uploading the picture"
        );
        
        if(array_key_exists("sent", $_POST)){
            require_once 'DJOLUC/Helper/php/fonct.php';
            
            $fileUploader = new \DJOLUC\Helper\php\FileUploader("picture", "runningData/AdsMedia/Image", $this->userId, "image", "own_name", $this->userId."_".\time());
            if($fileUploader->upload(false)){
                if($this->adsMediaDataSource->addAdsMedia($this->adsId, \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource::MEDIA_IMAGE_TYPE, $fileUploader->getFileName(), TRUE, "", \time(), 0, 0)){
                    $out["result"] = TRUE;
                }
                $this->addWaterMarkAndBorderToPicture($fileUploader->getFileDir()."/".$fileUploader->getFileName());
                miniature($fileUploader->getFileDir(), 200, $fileUploader->getFileDir()."/mini", $fileUploader->getFileName());
                
                $this->clearCache($this->getRefererRequestUrlWithoutHttp());
            }
        }
        
        
        if(array_key_exists("d", $_GET) && $this->getGetString("d") == "ajax"){
            $this->printPureJson($out);
        }else{
           header("Location: ".SITE_ROOT."adsManage/view/".$this->adsId);
        }
    }
    
    
    public function deletePictureAction(){
        $out = Array(
            "result" => FALSE,
            "message" => "Error when deleting the picture"
        );
        
        $tmpAdsId = $this->getGetInt("c");
        $tmpPictureTime = $this->getGetInt("d");
        
        if($this->adsMediaDataSource->deleteAdsMedia($tmpAdsId, $tmpPictureTime)){
            $out["result"] = TRUE;
            $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        }
        
        header("Location: ".SITE_ROOT."adsManage/view/".$tmpAdsId);
    }
    
    public function definePictureAction(){
        
        $tmpAdsId = $this->getGetInt("c");
        $tmpPictureTime = $this->getGetInt("d");
        
        $this->adsMediaDataSource->setAsCurrent($tmpAdsId, $tmpPictureTime);
        $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        
        
         header("Location: ".SITE_ROOT."adsManage/view/".$tmpAdsId);
    }
    
    
    public function deletePageAction(){
        $tmpAdsId = $this->getGetInt("c");
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "adsId" => $tmpAdsId, 
            "isMiniAdminOrMore" => $this->isMiniAdmOrMore
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/adsDeleteConfirmView.php");
    }

    
    public function deleteAction(){
        $tmpAdsId = $this->getGetInt("c");
        $deleteMessage = array_key_exists("message", $_POST)?$this->getPostString("message"):"";
        
        $deleteMessage = str_replace("\n", "<br/>", stripslashes($deleteMessage));
        
        $deleteMessage = str_replace(" ", "&nbsp;", $deleteMessage);
        
        $deleteMessage = str_replace("\t", "&nbsp;", $deleteMessage);
        
        $allPictures = $this->adsMediaDataSource->getAdsPictures($tmpAdsId);
       
        foreach ($allPictures AS $picture){
            $this->adsMediaDataSource->deleteAdsMedia($picture->getAdsId(), $picture->getMediaAddTime());
        }
        
        $adAuthorMailDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdAuthorMailDataSource();
        $ad = $this->adsDataSource->getAds($tmpAdsId);
        
        if($this->adsDataSource->deleteAds($tmpAdsId)){
            $this->sendDeleteMail($adAuthorMailDataSource->getAdAuthorEmail($tmpAdsId)->getEmail(), $ad->getAdsTitle(), $deleteMessage);
        }
        
        header("Location: ".SITE_ROOT."");
    }
    
    
    public function enableAction(){
        $tmpAdsId = $this->getGetInt("c");
        
        $ads = $this->adsDataSource->getAds($tmpAdsId);
        $adAuthorMailDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdAuthorMailDataSource();
        
        if(!$this->isMiniAdmOrMore && $this->userId != $ads->getAdsAutor()){
            $this->throwException(UNABLE_PAGE);
        }
        
        if($this->adsDataSource->setAdsActivate($tmpAdsId)){
            $this->sendApprovalMail($adAuthorMailDataSource->getAdAuthorEmail($tmpAdsId)->getEmail(), $tmpAdsId);
        }
        
        $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        
        
        header("Location: ".SITE_ROOT."adsManage/view/".$tmpAdsId);
    }
    
    
    
    
    
    public function disableAction(){
        $tmpAdsId = $this->getGetInt("c");
        
        $ads = $this->adsDataSource->getAds($tmpAdsId);
        
        if(!$this->isMiniAdmOrMore && $this->userId != $ads->getAdsAutor()){
            $this->throwException(UNABLE_PAGE);
        }
        
        $this->adsDataSource->setAdsActivate($tmpAdsId, FALSE);
        
        $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        
        header("Location: ".SITE_ROOT."adsManage/view/".$tmpAdsId);
    }
    


    public function sendApprovalMail($email, $adId):bool{
        
        $nom_site = "Jehlum";
        $adresse_site = "admin@jehlum.org";
        
        $passage_ligne = "\n";
        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $email)) // On filtre les serveurs qui rencontrent des bogues.
	{
            $passage_ligne = "\r\n";
        }else{
            $passage_ligne = "\n";
	}
	//=====Déclaration des messages au format texte et au format HTML.
	$message_txt = "Confirm your email.";
	$message_html='<!DOCTYPE html>
			<html>
                            <head>
                                <title>Ad approve on '.$nom_site.'</title>
                            </head>
                            <body style="font-size: 18px; color: rgba(0, 0, 0, 0.7); border: 5px solid cyan; width: 500px; margin: auto; padding: 10px;">
                                <h1 style="color: cadetblue; text-align: center;">Jehlum</h1>
                                <div>This mail is about your ad on '.$nom_site.'.<br/>
                                    Thanks. Your ad is approved now and you can visit our website to check it out
                                    <br/>
                                    <br/><center><a target="_blank" href="https://'.$_SERVER["HTTP_HOST"].'/adsManage/view/'.$adId.'" style="padding: 10px; margin: auto; margin-top: 10px; width: 100px; text-decoration: none; background: orange; color: #ffffff;">Check it</a></center>
                                </div>
                                <p>
                                    If you have any questions/concerns, please get back to us on info@jehlum.org
                                </p>
                            </body>
                        </html>';
	//==========
				
	//=====Création de la boundary
	$boundary = "-----=".md5(rand());
	//==========
				
	//=====Définition du sujet.
	$sujet = "Your ad on jehlum";
	//=========
				
	//=====Création du header de l'e-mail.
	$header = "From: \"".$nom_site."\"<".$adresse_site.">".$passage_ligne;
	$header.= "Reply-to: \"".$nom_site."\" <".$adresse_site.">".$passage_ligne;
	$header.= "MIME-Version: 1.0".$passage_ligne;
	$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"".$boundary."\" ".$passage_ligne."";
	//==========
				
	//=====Création du message.
	$message = $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format texte.
	$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_txt.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format HTML
	$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_html.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	//==========
				
	//=====Envoi de l'e-mail.
	
        return mail($email,$sujet,$message,$header);
    }
    
    
    
    public function sendDeleteMail($email, $adTitle, $deleteMessage):bool{
        
        $nom_site = "Jehlum";
        $adresse_site = "admin@jehlum.org";
        
        $passage_ligne = "\n";
        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $email)) // On filtre les serveurs qui rencontrent des bogues.
	{
            $passage_ligne = "\r\n";
        }else{
            $passage_ligne = "\n";
	}
	//=====Déclaration des messages au format texte et au format HTML.
	$message_txt = "Confirm your email.";
	$message_html='<!DOCTYPE html>
			<html>
                            <head>
                                <title>Ad delete on '.$nom_site.'</title>
                            </head>
                            <body style="font-size: 18px; color: rgba(0, 0, 0, 0.7); border: 5px solid cyan; width: 500px; margin: auto; padding: 10px;">
                                <h1 style="color: cadetblue; text-align: center;">Jehlum</h1>
                                <div>This mail is about your ad "'.$adTitle.'" on '.$nom_site.'.<br/>
                                    Sorry. Your ad is not approved due to following reason:
                                    <p>
                                        '.$deleteMessage.'
                                    </p>
                                    <br/>
                                </div>
                                <p>
                                    If you have any questions/concerns, please get back to us on info@jehlum.org
                                </p>
                            </body>
                        </html>';
	//==========
				
	//=====Création de la boundary
	$boundary = "-----=".md5(rand());
	//==========
				
	//=====Définition du sujet.
	$sujet = "Your ad on jehlum";
	//=========
				
	//=====Création du header de l'e-mail.
	$header = "From: \"".$nom_site."\"<".$adresse_site.">".$passage_ligne;
	$header.= "Reply-to: \"".$nom_site."\" <".$adresse_site.">".$passage_ligne;
	$header.= "MIME-Version: 1.0".$passage_ligne;
	$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"".$boundary."\" ".$passage_ligne."";
	//==========
				
	//=====Création du message.
	$message = $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format texte.
	$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_txt.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format HTML
	$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_html.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	//==========
				
	//=====Envoi de l'e-mail.
	
        return mail($email,$sujet,$message,$header);
    }
    
    
    
    public function sendApplyMail($adAuthorEmail, $applyEmail, $adTitle, $fileIndex, $fileLink){
        $nom_site = "Jehlum";
        $adresse_site = "admin@jehlum.org";
        
        $passage_ligne = "\n";
        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $adAuthorEmail)) // On filtre les serveurs qui rencontrent des bogues.
	{
            $passage_ligne = "\r\n";
        }else{
            $passage_ligne = "\n";
	}
        
        $attacheMessage = "";
        if(!empty($fileLink)){
            $attacheMessage = '<p>The attached file link is: <a href="https://'.$_SERVER["HTTP_HOST"].'/'.$fileLink.'">attached file</a></p>';
        }
        
        
        
	//=====Déclaration des messages au format texte et au format HTML.
	$message_txt = "Confirm your email.";
	$message_html='<!DOCTYPE html>
			<html>
                            <head>
                                <title>Ad apply on '.$nom_site.'</title>
                            </head>
                            <body style="font-size: 18px; color: rgba(0, 0, 0, 0.7); border: 5px solid cyan; width: 500px; margin: auto; padding: 10px;">
                                <h1 style="color: cadetblue; text-align: center;">Jehlum</h1>
                                <div>This mail is about your ad "'.$adTitle.'" on '.$nom_site.'.<br/>
                                    Somebody applied to your ad with this email id:
                                    <p>
                                        <b>'.$applyEmail.'</b>
                                    </p>
                                    <br/>
                                    '.$attacheMessage.'
                                </div>
                                <p>
                                    If you have any questions/concerns, please get back to us on info@jehlum.org
                                </p>
                            </body>
                        </html>';
	//==========
				
	//=====Création de la boundary
	$boundary = "-----=".md5(rand());
	//==========
				
	//=====Définition du sujet.
	$sujet = "Ad application";
	//=========
				
	//=====Création du header de l'e-mail.
	$header = "From: \"".$nom_site."\"<".$adresse_site.">".$passage_ligne;
	$header.= "Reply-to: \"".$nom_site."\" <".$adresse_site.">".$passage_ligne;
	$header.= "MIME-Version: 1.0".$passage_ligne;
	$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"".$boundary."\" ".$passage_ligne."";
	//==========
				
	//=====Création du message.
	$message = $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format texte.
	$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_txt.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format HTML
	$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_html.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	//==========
        
        
        //===================Attache file
        /*$tmp_name = $_FILES[$fileIndex]['tmp_name']; // get the temporary file name of the file on the server 
        $file_name = $_FILES[$fileIndex]['name'];  // get the name of the file 
        $size = $_FILES[$fileIndex]['size'];  // get size of the file for size validation 
        $file_type = $_FILES[$fileIndex]['type'];  // get type of the file 
        $file_error = $_FILES[$fileIndex]['error']; // get the error (if any) 
 
        
        $handle = fopen($tmp_name, "r");  // set the file handle only for reading the file 
        $content = fread($handle, $size); // reading the file 
        fclose($handle); 
        
        $encoded_content = chunk_split(base64_encode($content)); 
        
        $message .= "--$boundary\r\n"; 
        $message .="Content-Type: $file_type; name=".$file_name."\r\n"; 
        $message .="Content-Disposition: attachment; filename=".$file_name."\r\n"; 
        $message .="Content-Transfer-Encoding: base64\r\n"; 
        $message .="X-Attachment-Id: ".rand(1000, 99999)."\r\n\r\n";  
        $message .= $encoded_content; // Attaching the encoded file with email */
				
	//=====Envoi de l'e-mail.
	
        return mail($adAuthorEmail,$sujet,$message,$header);
    }
    
    
    
    
    public function displayApplyConfirm($email){
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore, 
            "email" => $email
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/applyConfirmPageView.php");
    }
    
    
    
    public function applyAction(){
        if(array_key_exists("sent", $_POST)){
            $applyEmail = $this->getPostString("email");
            $adId = $this->getGetInt("c");
            $fileIndex = "cv";
            
            $ad = $this->adsDataSource->getAds($adId);
            $adAuthorMailDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdAuthorMailDataSource();
            $adAuthorMail = $adAuthorMailDataSource->getAdAuthorEmail($adId);
            
            
            
            $adApplyDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsApplyDataSource();
            $fileUpload = new \DJOLUC\Helper\php\FileUploader("cv", "runningData/AdsApply/".$adId."", $this->userId, "document", "time_name", "");
            if($fileUpload->upload(FALSE)){
                 $adApplyDataSource->addAdApply($adId, $applyEmail, $fileUpload->getFileName(), \time());
                 
                 $this->sendApplyMail($adAuthorMail->getEmail(), $applyEmail, $ad->getAdsTitle(), $fileIndex, $fileUpload->getFileDir()."/".$fileUpload->getFileName());
                 
                 //header("Location: /adsManage/view/".$adId."");
                 
                 return $this->displayApplyConfirm($adAuthorMail->getEmail());
            }
        }else{
            header("Location: /");
        }
    }
    

    
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("", $thisObject);
        $thisObject->addPage("view", $thisObject);
        $thisObject->addPage("addPicture", $thisObject, FALSE);
        $thisObject->addPage("deletePicture", $thisObject, FALSE);
        $thisObject->addPage("definePicture", $thisObject, FALSE);
        $thisObject->addPage("enable", $thisObject, FALSE);
        $thisObject->addPage("disable", $thisObject, FALSE);
        $thisObject->addPage("deletePage", $thisObject, FALSE);
        $thisObject->addPage("delete", $thisObject, FALSE);
        $thisObject->addPage("enable", $thisObject, FALSE);
        $thisObject->addPage("disable", $thisObject, FALSE);
        $thisObject->addPage("apply", $thisObject);
       
        $thisObject->rooting($cacheDir);
    }

}
