<?php

namespace DJOLUC\AdsBundle\Controller\Frontend;

/**
 * Description of AdsByCategoryController
 *
 * @author djoluc
 */
class AdsByCategoryController extends \App\Controller\BaseController {
    private $userDataSource, 
            $adsCategoryDataSource,
            $adsDataSource,
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore, 
            $isConnectedUser;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsCategoryDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource();
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
        
        $categoryId = $this->getGetInt("b");
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore, 
            "adsCategories" => $this->adsCategoryDataSource->getAllAdsCategory(),
            "categoryId" => $categoryId,
            "categoryAds" => $this->adsDataSource->getCategoryAds($categoryId)
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/adsByCategoryView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }
}
