<?php


namespace DJOLUC\AdsBundle\Controller\Frontend;

/**
 * Description of AdsByLocationController
 *
 * @author djoluc
 */
class AdsByLocationController extends \App\Controller\BaseController {
    private $userDataSource, 
            $adsLocationDataSource,
            $adsDataSource,
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore, 
            $isConnectedUser;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsLocationDataSource();
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
        
        $locationId = $this->getGetInt("b");
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore, 
            "adsLocations" => $this->adsLocationDataSource->getAllLocation(),
            "locationId" => $locationId,
            "locationAds" => $this->adsDataSource->getLocationAds($locationId)
        ], 
                "DJOLUC/AdsBundle/Views/Frontend/adsByLocationView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }

}
