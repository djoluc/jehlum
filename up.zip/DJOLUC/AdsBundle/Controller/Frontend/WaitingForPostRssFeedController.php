<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DJOLUC\AdsBundle\Controller\Frontend;

/**
 * Description of WaitingForPostRssFeedController
 *
 * @author djoluc
 */
class WaitingForPostRssFeedController extends \App\Controller\BaseController {
    private $adsDataSource, 
            $waitingForPostAdsDataSource,
            $userDataSource, 
            $userId, 
            $isAdmin,
            $isModoOrMore;
    
    public function __construct() {
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->waitingForPostAdsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\WaitingForPostAdsDataSource();
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isAdmin = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() > \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::ADM_RANG;
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() > \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        
    }
    
    public function feedAction($lang = "") {
        parent::displayPageAction($lang);
        
        
        \header("Content-Type: application/rss+xml; charset=UTF-8");
        
        $rssfeed = '<?xml version="1.0" encoding="UTF-8"?>';
        $rssfeed .= '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">';
        $rssfeed .= '<channel>';
        $rssfeed .= '<title>Jehlum ads rss feeds</title>';
        $rssfeed .= '<link>'.SITE_URL.'</link>';
        $rssfeed .= '<description>This is jehlum RSS feed</description>';
        $rssfeed .= '<language>en-us</language>';
        $rssfeed .= '<atom:link href="'.SITE_URL.'/pendingAdsRssFeed/feed" rel="self" type="application/rss+xml" />';
        $rssfeed .= '<copyright>Copyright (C) 2019 jehlum.org</copyright>';
        
        
        $ads = $this->adsDataSource->getActivatedAds("", 0, 20);
        
        //$ad = new \DJOLUC\AdsBundle\Model\Frontend\Ads(0, "", "", 0, 0, 0);
        foreach ($ads AS $ad){
            $rssfeed .= '<item>';
            $rssfeed .= '<title>' .htmlspecialchars($ad->getAdsTitle()). '</title>';
            $rssfeed .= '<description>' .htmlspecialchars($ad->getAdsDescription()). '</description>';
            //$rssfeed .= '<![CDATA[<img src="'.$ad->getCurrentPictureUrl().'" alt="Picture">]>';
           // $rssfeed .= '<content:encoded><![CDATA[<p><p><img src="'.$ad->getCurrentPictureUrl().'" height="250" width="250" /></p></p>]]></content:encoded>';
            $rssfeed .= '<link>' .$ad->getAdLink(). '</link>';
            $rssfeed .= '<guid>' .$ad->getAdLink(). '</guid>';
            $rssfeed .= '<pubDate>' .\date("D, d M Y H:i:s O", $ad->getAdsAddTime()). '</pubDate>';
            $rssfeed .= '</item>';
        }
        
        $rssfeed .= '</channel>';
        $rssfeed .= '</rss>';
        
        return $rssfeed;
    }
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
        
        
        \header("Content-Type: application/rss+xml; charset=UTF-8");
        
        $rssfeed = '<?xml version="1.0" encoding="UTF-8"?>';
        $rssfeed .= '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">';
        $rssfeed .= '<channel>';
        $rssfeed .= '<title>Jehlum ads rss feeds</title>';
        $rssfeed .= '<link>'.SITE_URL.'</link>';
        $rssfeed .= '<description>This is jehlum RSS feed</description>';
	$rssfeed .= '<media:thumbnail url="'.$ad->getCurrentPictureUrl().'" height="75" width="75" />';
        $rssfeed .= '<language>en-us</language>';
        $rssfeed .= '<atom:link href="'.SITE_URL.'/pendingAdsRssFeed/feed" rel="self" type="application/rss+xml" />';
        $rssfeed .= '<copyright>Copyright (C) 2019 jehlum.org</copyright>';
        
        
        $adsId = $this->waitingForPostAdsDataSource->getNextReadyToBePostForRssAds(0, 10);
        
        //$ad = new \DJOLUC\AdsBundle\Model\Frontend\Ads(0, "", "", 0, 0, 0);
        foreach ($adsId AS $adId){
            $ad = $this->adsDataSource->getAds($adId);
            $rssfeed .= '<item>';
            $rssfeed .= '<title>' .$ad->getAdsTitle(). '</title>';
            $rssfeed .= '<description>' .$ad->getAdsDescription(). '</description>';
            $rssfeed .= '<media:thumbnail url="'.$ad->getCurrentPictureUrl().'" height="75" width="75" />';
            $rssfeed .= '<link>' .$ad->getAdLink(). '</link>';
            $rssfeed .= '<pubDate>' .\date("D, d M Y H:i:s O", $ad->getAdsAddTime()). '</pubDate>';
            $rssfeed .= '</item>';
        }
        
        $rssfeed .= '</channel>';
        $rssfeed .= '</rss>';
        
        return $rssfeed;
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("", $thisObject);
        $thisObject->addPage("feed", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }

}
