<?php

namespace DJOLUC\AdsBundle\Controller\Backend;

/**
 * Description of AdsLocationController
 *
 * @author djoluc
 */
class AdsLocationController extends \App\Controller\BaseController {
    private $userDataSource, 
            $adsLocationDataSource, 
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore, 
            $isConnectedUser;
    
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsLocationDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    public function addAction(){
        $out = Array(
            "result" => false,
            "message" => "Error when adding location"
        );
        
        if(array_key_exists("sent", $_POST)){
            $name = $this->getPostString("location");
            
            if(!$this->adsLocationDataSource->isLocationExist($name)){
                $out["result"] = $this->adsLocationDataSource->addLocation($name, \time());
                $out["message"] = "";
            }else{
                $out["message"] = "Location already exists";
            }
            
            $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        }
        
        if($out["result"]){
            $out["message"] = "Success";
        }
        
        if(array_key_exists("c", $_GET) && $this->getGetString("c") == "ajax"){
            return $this->printPureJson($out);
        }else{
            if($out["result"]){
                \header("Location: ".SITE_ROOT."adsLocation");
            }else{
                return $this->displayPageAction($out["message"]);
            }
        }
    }
    
    
    public function deleteAction(){
        $out = Array(
            "result" => FALSE, 
            "message" => "Error when deleting the category"
        );
        
        $LocationId = $this->getGetInt("c");
        
        $out["result"] = $this->adsLocationDataSource->deleteAdsLocation($LocationId);
        
        $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        
        if($out["result"]){
            $out["message"] = "Success";
        }
        
        if(array_key_exists("d", $_GET) && $this->getGetString("d") == "ajax"){
            return $this->printPureJson($out);
        }else{
            if($out["result"]){
                \header("Location: ".SITE_ROOT."adsLocation");
            }else{
                return $this->displayPageAction($out["message"]);
            }
        }
        
    }
    
    
    
    public function displayPageAction($message = "") {
        parent::displayPageAction();
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore, 
            "adsLocations" => $this->adsLocationDataSource->getAllLocation(), 
            "message" => $message
        ], 
                "DJOLUC/AdsBundle/Views/Backend/adsLocationMainView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        
        if(!$thisObject->isMiniAdmOrMore){
            $thisObject->throwException(UNABLE_PAGE);
        }
        
        $thisObject->addPage("", $thisObject);
        $thisObject->addPage("add", $thisObject, FALSE);
        $thisObject->addPage("delete", $thisObject, FALSE);
        
        $thisObject->rooting($cacheDir);
    }
}
