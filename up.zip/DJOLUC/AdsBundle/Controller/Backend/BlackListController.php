<?php

namespace DJOLUC\AdsBundle\Controller\Backend;

/**
 * Description of BlackListController
 *
 * @author djoluc
 */
class BlackListController extends \App\Controller\BaseController {
    private $userDataSource, 
            $adsDataSource,
            $adsLocationDataSource,
            $blackListDataSource,
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore, 
            $isConnectedUser;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->adsLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsLocationDataSource();
        $this->blackListDataSource = new \DJOLUC\AdsBundle\Model\Backend\BlackListDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    public function addAction(){
        if(!$this->isMiniAdmOrMore){
            $this->throwException(UNABLE_ACTION);
        }
        
        
        if(array_key_exists("sent", $_POST)){
            $email = $this->getPostString("email");
            
            if(!$this->blackListDataSource->isInBlackList($email)){
                $this->blackListDataSource->addToBlackList($email, \time());
                
                $this->clearCache($this->getRefererRequestUrlWithoutHttp());
                
                \header("Location: /blackList");
            }else{
                return $this->displayPageAction("<b>".$email."</b> is already in black list.");
            }
        }else{
            return $this->displayPageAction("Error");
        }
    }
    
    
    public function deleteAction(){
        if(!$this->isMiniAdmOrMore){
            $this->throwException(UNABLE_ACTION);
        }
        
        
        if(array_key_exists("c", $_GET)){
            $email = $this->getGetString("c");
            $this->blackListDataSource->deleteFromBlckList($email);
            
            $this->clearCache($this->getRefererRequestUrlWithoutHttp());
            
            \header("Location: /blackList");
        }else{
            return $this->displayPageAction("Error");
        }
    }
    
    
    
    public function displayPageAction($message = "") {
        parent::displayPageAction();
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore,
            "blackLists" => $this->blackListDataSource->getBlackList("", 0, 1000), 
            "message" => $message
        ], 
                "DJOLUC/AdsBundle/Views/Backend/blackListView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        $thisObject->addPage("", $thisObject);
        $thisObject->addPage("add", $thisObject, FALSE);
        $thisObject->addPage("delete", $thisObject, FALSE);
        $thisObject->addPage("editemail", $thisObject);
        $thisObject->addPage("edit", $thisObject, FALSE);
        
        $thisObject->rooting($cacheDir);
    }

    
}
