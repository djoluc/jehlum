<?php

namespace DJOLUC\AdsBundle\Controller\Backend;

/**
 * Description of LinkedinController
 *
 * @author djoluc
 */
class LinkedinController extends \App\Controller\BaseController {
    private $linkedinOauthTokenDataSource, 
            $userDataSource, 
            $adsDataSource,
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore,
            $linkedinClient;
    
    public function __construct() {
        $this->linkedinOauthTokenDataSource = new \DJOLUC\AdsBundle\Model\Backend\LinkedinOauthTokenDataSource();
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $this->linkedinClient = new \LinkedIn\Client("77prnqog9edtcd", "tAbul9Ptn5xuvgLe");
        $this->linkedinClient->setRedirectUrl(SITE_URL."?a=linkedin&b=getToken");
        if($this->linkedinOauthTokenDataSource->isTokenExist() && !$this->linkedinOauthTokenDataSource->isTokenExpire()){
            $this->linkedinClient->setAccessToken(new \LinkedIn\AccessToken($this->linkedinOauthTokenDataSource->getToken(), $this->linkedinOauthTokenDataSource->getTokenExpireAt()));
        }
    }
    
    
    public function authenticateAction(){
        
         if(!$this->isMiniAdmOrMore){
            $this->throwException("You can not access this page.");
        }
        
        $scopes = [
            \LinkedIn\Scope::READ_BASIC_PROFILE, 
            \LinkedIn\Scope::READ_EMAIL_ADDRESS,
            \LinkedIn\Scope::MANAGE_COMPANY,
            \LinkedIn\Scope::SHARING,
        ];
        
        $authUrl = $this->linkedinClient->getLoginUrl($scopes);
        $_SESSION['oauth2state'] = $this->linkedinClient->getState();
        \header("Location: ".$authUrl."");
    }
    
    public function getTokenAction(){
        if(array_key_exists("code", $_GET)){
            $code = $this->getGetString("code");
            
            $accessToken = $this->linkedinClient->getAccessToken($code);
            $this->linkedinClient->setAccessToken(new \LinkedIn\AccessToken($accessToken->getToken(), $accessToken->getExpiresAt()));
            $this->linkedinOauthTokenDataSource->setToken($accessToken->getToken(), $accessToken->getExpiresAt());
            
            \header("Location: /linkedin");
        }
        
        return "Error when processing";
    }
    
    
    
    public static function postAdStaticly($adId){
        
        $thisObject = new self();
        
        return $thisObject->postAd($adId);
    }
    
    
    
    
    public function postAd($adId){
        $out = FALSE;
        $ad = $this->adsDataSource->getAds($adId);
        //$adId = 87;
        //$ad = new \DJOLUC\AdsBundle\Model\Frontend\Ads(87, "Title2", "Description", 1, true, "1000", TRUE);
        $currentPicture = $ad->getAdsCurrentPicture();
        $pictureLink = SITE_URL."/DJOLUC/MainBundle/Public/Theme/Default/image/logo.png";
        if(!empty($currentPicture->getMediaName())){
            $pictureLink = SITE_URL.'/runningData/AdsMedia/Image/'.$currentPicture->getMediaName().'';
        }
        try{
        if(!$this->linkedinOauthTokenDataSource->isTokenExpire()){
            //https://www.linkedin.com/company/jehlum/
            $companyId = "13245238";
            //$companyId = "19061985";
        
            $companyShare = $this->linkedinClient->post(
                'companies/' . $companyId . '/shares',
                [
                    'comment' => $ad->getAdsTitle(),
                    'content' => [
                        'title' => $ad->getAdsTitle(),
                        'description' => 'Jehlum ad',
                        'submitted-url' => SITE_URL.'/adsManage/view/'.$adId.'',
                        //'submitted-image-url' => 'https://github.com/fluidicon.png',
                        'submitted-image-url' => $pictureLink
                    ],
                    'visibility' => [
                        'code' => 'anyone'
                    ]
                ]
            );

            $out = !empty($companyShare["updateKey"]);
        }
        
        } catch (Exception $ex){
            
        }
        
        
        return $out;
    }


    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
        
        if(!$this->isMiniAdmOrMore){
            $this->throwException("You can not access this page.");
        }
        
        $dateManager = new \DJOLUC\Helper\php\DateManager();
        
        $expireString = $dateManager->getDateReference($this->linkedinOauthTokenDataSource->getTokenExpireAt());
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore, 
            "expireString" => $expireString
        ], 
                "DJOLUC/AdsBundle/Views/Backend/linkedinView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        $thisObject->addPage("", $thisObject);
        $thisObject->addPage("authenticate", $thisObject, FALSE);
        $thisObject->addPage("getToken", $thisObject, FALSE);
        
        $thisObject->rooting($cacheDir);
    }
}
