<?php

namespace DJOLUC\AdsBundle\Controller\Backend;

/**
 * Description of PendingAdsController
 *
 * @author djoluc
 */
class PendingAdsController extends \App\Controller\BaseController  {
    private $userDataSource, 
            $adsDataSource,
            $adsLocationDataSource,
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore, 
            $isConnectedUser;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->adsLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsLocationDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore,
            "pendingAds" => $this->adsDataSource->getPendingAds()
        ], 
                "DJOLUC/AdsBundle/Views/Backend/pendingAdsView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        
        if(!$thisObject->isMiniAdmOrMore){
            $thisObject->throwException(UNABLE_PAGE);
        }
        
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }
}
