<?php

namespace DJOLUC\AdsBundle\Controller\Backend;

/**
 * Description of AdsCategoryController
 *
 * @author djoluc
 */
class AdsCategoryController extends \App\Controller\BaseController {
    private $userDataSource, 
            $adsCategoryDataSource, 
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore, 
            $isConnectedUser;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsCategoryDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    
    public function addAction(){
        $out = Array(
            "result" => false,
            "message" => "Error when adding category"
        );
        
        if(array_key_exists("sent", $_POST)){
            $type = $this->getPostInt("type");
            $name = $this->getPostString("category");
            
            if(!$this->adsCategoryDataSource->isCategoryExist($type, $name)){
                $out["result"] = $this->adsCategoryDataSource->addCategory($type, $name, \time());
            }else{
                $out["message"] = "Category already exists";
            }
            
            $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        }
        
        if($out["result"]){
            $out["message"] = "Success";
        }
        
        if(array_key_exists("c", $_GET) && $this->getGetString("c") == "ajax"){
            return $this->printPureJson($out);
        }else{
            if($out["result"]){
                \header("Location: ".SITE_ROOT."adsCategory");
            }else{
                return $this->displayPageAction($out["message"]);
            }
        }
    }
    
    
    public function deleteAction(){
        $out = Array(
            "result" => FALSE, 
            "message" => "Error when deleting the category"
        );
        
        $categoryId = $this->getGetInt("c");
        
        $out["result"] = $this->adsCategoryDataSource->deleteAdsCategory($categoryId);
        
        $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        
        if($out["result"]){
            $out["message"] = "Success";
        }
        
        if(array_key_exists("d", $_GET) && $this->getGetString("d") == "ajax"){
            return $this->printPureJson($out);
        }else{
            if($out["result"]){
                \header("Location: ".SITE_ROOT."adsCategory");
            }else{
                return $this->displayPageAction($out["message"]);
            }
        }
        
    }
    
    
    public function displayPageAction($message = "") {
        parent::displayPageAction();
        
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId" => $this->userId,
            "isModoOrMore" => $this->isModoOrMore, 
            "adsCategories" => $this->adsCategoryDataSource->getAllAdsCategory(), 
            "message" => $message
        ], 
                "DJOLUC/AdsBundle/Views/Backend/adsCategoryMainView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        
        $thisObject = new self();
        
        if(!$thisObject->isMiniAdmOrMore){
            $thisObject->throwException(UNABLE_PAGE);
        }
        
        $thisObject->addPage("add", $thisObject, FALSE);
        $thisObject->addPage("delete", $thisObject, FALSE);
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }
}
