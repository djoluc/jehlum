<?php $title = "Ads category";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/login.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/formBase.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/miniCard.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/AdsBundle/Public/Theme/Default/css/adsCategory.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/login.js?version=1.1"></script>
        
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        <div id="page_div">
            <div class="category_contener" style="width: 350px;">
                <span class="header"><?= ADS." ". strtolower(LOCATION); ?></span>
                <?php if(count($data["adsLocations"]) == 0): ?>
                <div class="empty_indicator">
                    No ads category available
                </div>
                <?php else: ?>
                <ul class="categories">
                    <?php foreach ($data["adsLocations"] AS $location): ?>
                    <a href="<?= SITE_ROOT ?>location/<?= $location->getLocationId(); ?>" style="text-decoration: none; color: inherit;" ><li style="height: 40px; line-height: 40px; <?= $data["locationId"] == $location->getLocationId()?"background: rgba(0, 0, 0, 0.1);":""; ?>">
                        <div>
                            <?= $location->getLocationName()."(".$location->getAdsNumb().")"; ?>
                        </div>
                            <i style=" display: inline-block; float: right; margin-top: -30px;" class="fa fa-chevron-right"></i>
                    </li></a>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
            <div class="category_form_contener" id="form_div">
                <h3 style="text-align: center; text-decoration: underline;">Location Ads</h3>
                <div class="latestAddBox">
        
            <div class="contener" style="width: available;">
            <?php if(count($data["locationAds"]) != 0):  ?>
            <?php foreach ($data["locationAds"] AS $ad): //$ad = new DJOLUC\AdsBundle\Model\Frontend\Ads(0, "", "", 0, 0, $adsLocation, $isActivate, $adsAddTime); ?>
            <div class="ad">
                <a href="/adsManage/view/<?= $ad->getAdsId(); ?>"><span class="picture">
                    <span class="onpicture location"><i class="fa fa-map-marker"></i> <?= $ad->getLocationName(); ?></span>
                    <span class="onpicture category"><i class="fa fa-folder"></i> <?= $ad->getAdTypeName(); ?></span>
                    <?php if(!empty($ad->getAdsCurrentPicture()->getMediaName())): ?>
                    <img src="<?= SITE_ROOT ?>runningData/AdsMedia/Image/<?= $ad->getAdsCurrentPicture()->getMediaName(); ?>" />
                    <?php else: ?>
                    <img src="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/image/logo.png" />
                    <?php endif; ?>
                </span></a>
                <!--<ul class="datas">
                    <li class="data" style="font-weight: bold;"><a href="<?= SITE_ROOT ?>adsManage/view/<?= $ad->getAdsId(); ?>"><?= $ad->getAdsTitle(); ?></a></li>
                    <li class="data" style="height: 55px;">
                        <?php
                        $adsUser = $ad->getAdsUser();
                        ?>
                        <div class="mini_card" style="background: transparent;">
                            <a href="<?= SITE_ROOT ?>profil/<?= $adsUser->getUserId(); ?>"><span class="picture round" style="width: 40px; height: 40px;">
                                <?php if(!empty($adsUser->getUserProfilMiniPicture())): ?>
                                <img src="<?= $adsUser->getUserProfilMiniPicture(); ?>" />
                                <?php endif; ?>
                            </span></a>
                            <ul class="data">
                                <li style="font-weight: bold; margin-left: -30px;"><?= $adsUser->getUserNom()." ".$adsUser->getUserPrenomsJson(); ?></li>
                            </ul>
                        </div>
                    </li>
                </ul>-->
                <div class="footer">
                    <a href="<?= SITE_ROOT ?>/adsManage/enable/<?= $ad->getAdsId(); ?>"><button style="float: right;">Apply</button></a> &nbsp;
                </div>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
            <div style="display: block; width: 400px; height: 200px; line-height: 200px; text-align: center;">
                No ad to display
            </div>
            <?php endif; ?>
        </div>
    </div>
            </div>
        </div>
    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"] ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>