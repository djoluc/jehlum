<?php $title = "Jehlum home";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT; ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
         <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/searchBar.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/miniCard.css?version=1.0" media="all" />
        <!--<link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/main_actuality_box.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css?version=1.0" media="all" /
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/horizontalScrollView.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />-->
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
        <script src="http://www.openlayers.org/api/OpenLayers.js"></script>
        <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>
        <script type="text/javascript" src="/DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="/DJOLUC/RegisterBundle/Public/Theme/Default/js/searchBar.js?version=1.0"></script>
        <script type="text/javascript" src="/DJOLUC/LocationBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="/DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="/DJOLUC/ProductBundle/Public/Theme/Default/js/ProductLike.js?version=1.0"></script>
        <script type="text/javascript" src="/DJOLUC/ProductBundle/Public/Theme/Default/js/UserShoppingCart.js?version=1.0"></script>
        <script type="text/javascript" src="/DJOLUC/MainBundle/Public/Theme/Default/js/searchMap.js?version=1.0"></script>
        <script type="text/javascript" src="/DJOLUC/Helper/js/searchBar.js?version=1.0"></script>
        <script type="text/javascript" src="/DJOLUC/MainBundle/Public/Theme/Default/js/search.js?version=1.0"></script>
        <!--<script type="text/javascript" src="DJOLUC/PaymentBundle/Public/Theme/Default/js/MtnMobileMoney.js"></script>-->
        
        <style>
.buttonload {
    background-color: #4CAF50; /* Green background */
    border: none; /* Remove borders */
    color: white; /* White text */
    padding: 12px 24px; /* Some padding */
    font-size: 16px; /* Set a font-size */
}
</style>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>



<div id="page_div">
    <div class="latestAddBox">
        <span class="header">
            <fieldset>
                <legend><b style="color: #000000; font-size: 30px;">Latest Ads</b></legend>
            </fieldset>
        </span>
        
        <div class="contener">
            <?php if(count($data["latestAds"]) != 0):  ?>
            <?php foreach ($data["latestAds"] AS $ad): //$ad = new DJOLUC\AdsBundle\Model\Frontend\Ads(0, "", "", 0, 0, $adsLocation, $isActivate, $adsAddTime); ?>
            <div class="ad">
                <a href="/adsManage/view/<?= $ad->getAdsId(); ?>"><span class="picture">
                    <span class="onpicture location"><i class="fa fa-map-marker"></i> <?= $ad->getLocationName(); ?></span>
                    <span class="onpicture category"><i class="fa fa-folder"></i> <?= $ad->getAdTypeName(); ?></span>
                    <?php if(!empty($ad->getAdsCurrentPicture()->getMediaName())): ?>
                    <img src="/runningData/AdsMedia/Image/mini/<?= $ad->getAdsCurrentPicture()->getMediaName(); ?>" />
                    <?php else: ?>
                    <img src="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/image/logo.png" />
                    <?php endif; ?>
                </span></a>
                <ul class="datas">
                    <li class="data" style="font-weight: bold;"><a href="<?= SITE_ROOT ?>adsManage/view/<?= $ad->getAdsId(); ?>"><?= $ad->getAdsTitle(); ?></a></li>
                    <li class="data" style="font-size: 12px; color: #000000;"><i class="fa fa-clock"></i> Posted <?= $ad->getTimeReference(); ?></li>
                    <!--<li class="data" style="height: 55px;">
                        <?php
                        $adsUser = $ad->getAdsUser();
                        ?>
                        <div class="mini_card" style="background: transparent;">
                            <a href="<?= SITE_ROOT ?>profil/<?= $adsUser->getUserId(); ?>"><span class="picture round" style="width: 40px; height: 40px;">
                                <?php if(!empty($adsUser->getUserProfilMiniPicture())): ?>
                                <img src="<?= $adsUser->getUserProfilMiniPicture(); ?>" />
                                <?php endif; ?>
                            </span></a>
                            <ul class="data">
                                <li style="font-weight: bold; margin-left: -30px;"><?= $adsUser->getUserNom()." ".$adsUser->getUserPrenomsJson(); ?></li>
                            </ul>
                        </div>
                    </li>-->
                </ul>
                <!--<div class="footer">
                    <button style="float: right;">Apply</button> &nbsp;
                </div>-->
            </div>
            
            <?php endforeach; ?>
            <?php else: ?>
            <div style="display: block; width: 400px; height: 200px; line-height: 200px; text-align: center;">
                No ad to display
            </div>
            <?php endif; ?>
        </div>
        <?php if($data["allAdsNumb"]  > $data["first"]+$data["numb"]): ?>
        <a href="/ads/<?= $data["first"]+$data["numb"] ?>/<?= $data["numb"] ?>"><button style="float: right; margin-right: 200px;"><i class="fa fa-plus">More</i></button></a>
        <?php endif; ?>
    </div>
</div>

    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>