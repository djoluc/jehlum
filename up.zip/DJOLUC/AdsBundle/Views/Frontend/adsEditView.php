<?php $title = "Edit Ads";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/login.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/formBase.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/AdsBundle/Public/Theme/Default/css/adsCategory.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/login.js?version=1.1"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/AdsBundle/Public/Theme/Default/js/editAd.js?version=1.0"></script>
        
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        <div id="page_div">
            <div id="form_div">
                <h3 style="text-align: center; text-decoration: underline;" >New ads form</h3>
                <form method="POST" action="<?= SITE_ROOT ?>ads/edit/<?= $data["ads"]->getAdsId(); ?>">
                    <label>
                        Title: 
                        <input maxlength="300" type="text" name="title" value="<?= $data["ads"]->getAdsTitle(); ?>" placeholder="Ads title..." required />
                    </label>
                    <fieldset>
                        <legend>Ad type:</legend>
                        <label>
                            Job
                            <input class="jobType type" checked type="radio" name="type" />
                        </label>
                        
                        <label>
                            Classfields
                            <input class="classfieldType type" type="radio" name="type" />
                        </label>
                    </fieldset>
                    <label>
                        Category: 
                        <select class="categories" name="category[]" multiple>
                            <optgroup class="jobGroupe" style='<?= $data["ads"]->getAdType()==\DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource::CLASSFIELD_TYPE?"display: none;":""; ?>' label="Job categories">
                                <?= $data["jobCategoriesOptions"] ?>
                            </optgroup>
                            
                            <optgroup class="classfieldGroupe" style='<?= $data["ads"]->getAdType()== \DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource::JOB_TYPE?"display: none;":""; ?>' label="Classfield categories">
                                <?= $data["ClassfieldCategoriesOptions"] ?>
                            </optgroup>
                        </select>
                    </label>
                    <label>
                        Location: 
                        <select name="location[]" multiple>
                            <?= $data["locationsOptions"] ?>
                        </select>
                    </label>
                    <label>
                        Description: 
                        <textarea name="description" placeholder="Description..." required><?= $data["ads"]->getAdsPureDescription(); ?></textarea>
                    </label>
                    <p style="color: red;">
                        <?= $data["message"]; ?>
                    </p>
                    <input type="hidden" value="" name="sent" />
                    <button type="submit">Edit</button>
                </form>
            </div>
        </div>
    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"] ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>