<?php $title = "".$data["ads"]->getAdsTitle()."";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/login.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/formBase.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/miniCard.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/headerView.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/picturesViewDialog.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/AdsBundle/Public/Theme/Default/css/adsView.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/login.js?version=1.1"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/AdsBundle/Public/Theme/Default/js/anAd.js?version=1.1"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/Helper/js/FormSubmit.js?version=1.0"></script>
        
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        
        <div id="page_div">
            <div class="adsPicture" style="border-radius: 5px;">
                <span class="header" style=" display: block; margin-bottom: 2px; color: rgba(0, 0, 0, 1); overflow: visible; word-wrap: break-word; white-space: normal; height: fit-content; font-weight: bold; padding: 5px; border-top-right-radius: 5px; border-top-left-radius: 5px; font-size: 22px;"><?= $data["ads"]->getAdsTitle(); ?></span>
                <p style="padding-top: 0px; margin: 0px;">
                    <?php if(!($data["isAdsAuthor"] || $data["isModoOrMoreAuthor"])): ?>
                        <!--<a href="<?= SITE_ROOT ?>ads/apply/<?= $data["ads"]->getAdsId(); ?>">-->
                            <div class="apply_div">
                                <button style="background: green;" class="apply_button">Apply</button>
                                <ul class="apply_form_ul">
                                    <li style="background: rgba(45, 94, 127, 1); color: rgba(255, 255, 255, 0.7); padding: 5px;"><h4 style="margin: 0px;"><center>Please fill this form to apply</center></h4></li>
                                    <li>
                                        <form method="POST" action="/adsManage/apply/<?= $data["ads"]->getAdsId(); ?>" enctype="multipart/form-data">
                                            <label>
                                                Your email id: 
                                                <input  required type="email" name="email" value="" placeholder="Email..."/>
                                            </label>
                                            <label>
                                                Your cv(.pdf, .doc, .docx) <i style="font-size: 13px;">200kb max.</i>&nbsp;: 
                                                <input id="i_file" type="file" name="cv" accept=".pdf,.doc,.docx" />
                                            </label>
                                            <input type="hidden" value="" name="sent" />
                                            <button id="i_submit" type="submit">Submit</button>
                                        </form>
                                    </li>
                                </ul>
                            </div>&nbsp;
                        <!--</a>-->
                        <?php endif; ?>
                    <?php if($data["isMiniAdmOrMore"]): ?>
                        <?php if($data["ads"]->getIsActivate()): ?>
                        <a href="<?= SITE_ROOT ?>adsManage/disable/<?= $data["ads"]->getAdsId(); ?>"><button>Disapprove</button></a>
                        <?php else: ?>
                        <a href="<?= SITE_ROOT ?>adsManage/enable/<?= $data["ads"]->getAdsId(); ?>"><button>Approve</button></a>
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php if($data["isAdsAuthor"] || $data["isMiniAdmOrMore"]): ?>
                        <a href="<?= SITE_ROOT ?>adsManage/deletePage/<?= $data["ads"]->getAdsId(); ?>"><button>Delete</button></a>
                        <a href="<?= SITE_ROOT ?>ads/adsEdit/<?= $data["ads"]->getAdsId(); ?>"><button>Edit</button></a>
                        <?php endif; ?>
                </p>
                <span class="current">
                    <?php $currentPitcure = $data["ads"]->getAdsCurrentPicture(); ?>
                    <?php if(!empty($currentPitcure->getMediaName())): ?>
                    <img bigLink="/runningData/AdsMedia/Image/<?= $currentPitcure->getMediaName(); ?>" src="<?= SITE_ROOT ?>runningData/AdsMedia/Image/<?= $currentPitcure->getMediaName(); ?>" />
                    <?php else: ?>
                    <img src="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/image/logo.png" />
                    <?php endif; ?>
                    <?php if($data["isAdsAuthor"] || $data["isMiniAdmOrMore"]): ?>
                    <a href="<?= SITE_ROOT ?>adsManage/deletePicture/<?= $currentPitcure->getAdsId(); ?>/<?= $currentPitcure->getMediaAddTime(); ?>"><button style="">Delete picture</button></a>
                    <?php endif; ?>
                </span>
                <ul class="pictures_box">
                    <?php 
                    $pictureArray = Array();
                    $adsPictures = $data["ads"]->getAdsPictures();
                    
                    if(count($adsPictures) == 0):
                    ?>
                    
                    <!--p style="text-align: center; height: 200px; line-height: 200px;">
                        No picture for the moment
                    </p>-->
                    
                    <?php else: ?>
                    <?php foreach($adsPictures AS $adsPicture): 
                        $pictureArray[count($pictureArray)] = "/runningData/AdsMedia/Image/".$adsPicture->getMediaName()."";
                        //$adsPicture = new DJOLUC\AdsBundle\Model\Frontend\AdsMedia(0, 0, "", FALSE, "", 0, FALSE, 0); 
                        
                        if(!$adsPicture->getIsPrincipal()):
                        ?>
                    <li>
                        <div style="font-size: 12px;">
                            <a href="/runningData/AdsMedia/Image/<?= $adsPicture->getMediaName(); ?>"><span><img bigLink="/runningData/AdsMedia/Image/<?= $adsPicture->getMediaName(); ?>" src="<?= SITE_ROOT ?>runningData/AdsMedia/Image/mini/<?= $adsPicture->getMediaName(); ?>" /></span></a>
                            <?php if($data["isAdsAuthor"] || $data["isMiniAdmOrMore"]): ?>
                            <a href="<?= SITE_ROOT ?>adsManage/deletePicture/<?= $adsPicture->getAdsId(); ?>/<?= $adsPicture->getMediaAddTime(); ?>">Delete</a> &nbsp; <a href="<?= SITE_ROOT ?>adsManage/definePicture/<?= $adsPicture->getAdsId(); ?>/<?= $adsPicture->getMediaAddTime(); ?>">Define</a>
                            <?php endif; ?>
                        </div>
                    </li>
                    <?php 
                    endif;
                    endforeach; ?>
                    <?php endif; ?>
                </ul>
                <?php if(($data["isAdsAuthor"] || $data["isMiniAdmOrMore"]) && count($adsPictures) <= 10): ?>
                <div class="form_div" style="background: cyan; padding: 10px;">
                    <form method="POST" class="pic_form" action="<?= SITE_ROOT ?>adsManage/addPicture/<?= $data["ads"]->getAdsId(); ?>" enctype="multipart/form-data">
                        <label>
                            Select a picture:
                            <input type="file" required name="picture" accept=".png,.jpg,.jpeg,.gif" value="" />
                        </label>
                        <progress style="display: none;" max="1" value="0" ></progress>
                        <input type="hidden" name="sent" value="" />
                        <button type="submit">Upload</button><br><br>
                    </form>
                </div>
                <?php endif; ?>
                <br/>
                
                
                
                <div class="header_view">
                    <!--<span class="header" style="overflow: visible; word-wrap: break-word; white-space: normal; height: fit-content; font-weight: bold;"><?= $data["ads"]->getAdsTitle(); ?></span>-->
                    <div class="content" style="display: block; word-wrap: break-word; word-break: keep-all; font-size: 17px;">
                        <p style="color: #484d5c;"><?= $data["ads"]->getAdsDescription() ?></p>
                    </div>
                    <span class="footer" style="color: rgba(0, 0, 0, 0.7); font-size: 13px; height: fit-content;">
                        <i class="fa fa-folder" style="color: red;"></i> <?= $data["ads"]->getAllCategoryAsString(); ?> &nbsp; <i class="fa fa-map-marker" style="color: red;"></i> <?= $data["ads"]->getAllLocationAsString(); ?> &nbsp; &nbsp;
                    </span>
                </div>
            </div>
            <div class="ads_information">
               <!-- <div class="info">
                    <span>Ads posted by</span>
                    <?php
                    $adsUser = $data["ads"]->getAdsUser();
                    //$adsUser = new \DJOLUC\RegisterBundle\Model\Frontend\User(0, 0, "", "", 0, "", 1, "", "", "", "", "", "", 0, 0, 1, "", 1, 1, 1, 0);
                    ?>
                    <br/>
                    <div class="mini_card">
                        <a href="<?= SITE_ROOT ?>profil/<?= $adsUser->getUserId(); ?>"><span class="picture round">
                            <?php if(!empty($adsUser->getUserProfilMiniPicture())): ?>
                            <img src="<?= $adsUser->getUserProfilMiniPicture(); ?>" />
                            <?php endif; ?>
                        </span></a>
                        <ul class="data">
                            <li style="font-weight: bold;"><?= $adsUser->getUserNom()." ".$adsUser->getUserPrenomsJson(); ?></li>
                            <li><i class="fa fa-phone"></i><?= " +".$adsUser->getUserCountryPhoneCode()."".$adsUser->getUserPhoneNumber(); ?></li>
                        </ul>
                    </div><br/>
                </div> -->
                
                <?php if(count($data["moreAds"])): ?>
                <div class="info">
                    <span>More Ads From similar categories</span>
                    <?php foreach($data["moreAds"] AS $otherAds): //$otherAds = new DJOLUC\AdsBundle\Model\Frontend\Ads(0, "", "", 0, 0, 0, FALSE, 0); ?>
                    <div class="mini_card" style="border-bottom: 1px solid rgba(0, 0, 0, 0.1);">
                        <a href="<?= SITE_ROOT ?>adsManage/view/<?= $otherAds->getAdsId(); ?>"><span class="picture">
                            <?php if(!empty($otherAds->getAdsCurrentPicture()->getMediaName())): ?>
                                <img src="<?= SITE_ROOT ?>runningData/AdsMedia/Image/mini/<?= $otherAds->getAdsCurrentPicture()->getMediaName(); ?>" />
                            <?php endif; ?>
                        </span></a>
                        <ul class="data">
                            <li style="font-weight: bold;"><?= $otherAds->getAdsTitle(); ?></li>
                            <li style="font-size: 12px; color: rgba(0, 0, 0, 0.5);"><i class="fa fa-folder"></i> <?= $otherAds->getCategoryName(); ?> &nbsp; &nbsp;  <i class="fa fa-map-marker"></i> <?= $otherAds->getLocationName(); ?></li>
                        </ul>
                    </div><br/>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <input type="hidden" name="pictures" value='<?= json_encode($pictureArray); ?>' />
    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"] ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>
