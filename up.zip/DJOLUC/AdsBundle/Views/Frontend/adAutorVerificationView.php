<?php $title = "Ads";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/login.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/formBase.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/AdsBundle/Public/Theme/Default/css/adsCategory.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/login.js?version=1.1"></script>
        
        
        <style>
            .info{
                display: block;
                width: 600px;
                height: 200px;
                background: #ffffff;
                padding: 10px;
                margin: auto;
                border: 1px solid rgba(0, 0, 0, 0.1);
                border-radius: 5px;
            }
            
            
            
            .info ul{
                display: block;
                list-style: none;
                width: 100%;
                height: 100%;
                padding: 0px;
                margin: 0px;
            }
            
            .info ul li.icon{
                display: inline-block;
                width: 150px;
                height: 100px;
                font-size: 100px;
                float: left;
                margin-top: 35px;
                color: red;
            }
            
            
            .info ul li.text{
                display: inline-block;
                width: calc(100% - 150px);
                height: 100px;
                margin-top: 30px;
                float: right;
                color: #000000;
                font-size: 25px;
            }
            
            @media all and (max-width:  600px){
                .info{
                    width: calc(100% - 20px);
                }
                
                .info ul li.icon{
                    width: 100px;
                    font-size: 80px;
                }
                
                .info ul li.text{
                    width: calc(100% - 100px);
                    font-size: 20px;
                }
            }
        </style>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        <div id="page_div">
            <div class="info">
                <h3 style="text-align: center; color: green">Ad posted!</h3>
                <ul>
                    <li class="icon">
                        <i class="fa fa-envelope-open"></i>
                    </li>
                    <li class="text">
                        <p>
                            We just send you a mail on <b><?= $data["email"]; ?></b>. Please check your inbox/spambox to verify your email ID.
                        </p>
                    </li>
                </ul>
            </div>
        </div>
    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"] ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>