<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of HouseMediaDataSource
 *
 * @author djoluc
 */
class AdsMediaDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "ads_media_table";
    
    const MEDIA_IMAGE_TYPE = 1;
    const MEDIA_VIDEO_TYPE = 2;
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("ads_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("media_type", Array(
            Array(
                "name" => $this::INT_ATTR, 
                "param" => "2", 
                "completers" => ""
            )
        ));
        $this->addColumns("media_name", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "300", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_principal", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::NOT_NULL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::DEFAULT_ATTR, 
                "param" => "", 
                "completers" => "FALSE"
            )
        ));
        $this->addColumns("media_legend", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "200", 
                "completers" => ""
            )
        ));
        $this->addColumns("media_add_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR,
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_deleted", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::NOT_NULL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::DEFAULT_ATTR, 
                "param" => "", 
                "completers" => "FALSE"
            )
        ));
        $this->addColumns("media_delete_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR,
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addRelation($this->columns[0]["name"], AdsDataSource::TABLE_NAME."(".AdsDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
    
        $this->createTable($this::TABLE_NAME);
        
        if(!\is_dir("runningData/AdsMedia")){
            \mkdir("runningData/AdsMedia");
        }
        
        if(!\is_dir("runningData/AdsMedia/Image")){
            \mkdir("runningData/AdsMedia/Image");
        }
        
        if(!\is_dir("runningData/AdsMedia/Video")){
            \mkdir("runningData/AdsMedia/Video");
        }
        
        
    }
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new self();
        
        return $thisObject->columns;
    }
    
    
    
    public function addAdsMedia($adsId, $mediaType, $mediaName, $isPrincipal, $legend, $mediaAddTime, $isDeleted, $mediaDeletedTime):bool{
        $out = false;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns)).")
                ");
        $i = 1;
        $query->bindValue($i++, $adsId, \PDO::PARAM_INT);
        $query->bindValue($i++, $mediaType, \PDO::PARAM_INT);
        $query->bindValue($i++, $mediaName, \PDO::PARAM_STR);
        $query->bindValue($i++, $isPrincipal, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $legend, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $mediaAddTime, \PDO::PARAM_INT);
        $query->bindValue($i++, $isDeleted, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $mediaDeletedTime, \PDO::PARAM_INT);
        if($query->execute()){
            $out = TRUE;
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        if($isPrincipal){
            $this->setAsCurrent($adsId, $mediaAddTime);
        }
        
        return $out;
    }
    
    
    
    
    public function getCurrentAdsMedia($adsId):AdsMedia{
        $out = AdsMedia::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[3]["name"]." = ?;
                ");
        $query->bindValue(1, $adsId, \PDO::PARAM_INT);
        $query->bindValue(2, TRUE, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->queryToAdsMedia($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    
    public function setAsCurrent($adsId, $mediaTime){
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this->columns[3]["name"]." = ? WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[5]["name"]." != ?;
                ");
        $i = 1;
        $query->bindValue($i++, FALSE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $adsId, \PDO::PARAM_INT);
        $query->bindValue($i++, $mediaTime, \PDO::PARAM_INT);
        $query->execute();
        $query->closeCursor();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this->columns[3]["name"]." = ? WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[5]["name"]." = ?;
                ");
        $i = 1;
        $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $adsId, \PDO::PARAM_INT);
        $query->bindValue($i++, $mediaTime, \PDO::PARAM_INT);
        $query->execute();
        $query->closeCursor();
    }

    
    public function unsetAll($adsId):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this->columns[3]["name"]." = ? WHERE ".$this->columns[0]["name"]." = ?;
               ");
        $query->bindValue(1, FALSE, \PDO::PARAM_BOOL);
        $query->bindValue(2, $houseId, \PDO::PARAM_INT);
        $out = $query->execute();
        $query->closeCursor();
        
        return $out;
    }

    
    
    
    
    public function getAdsPictures($adsId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[1]["name"]." = ?
                        ORDER BY ".$this->columns[count($this->columns) - 3]["name"]." ASC;
                ");
        $query->bindValue(1, $adsId, \PDO::PARAM_INT);
        $query->bindValue(2, $this::MEDIA_IMAGE_TYPE, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdsMedias($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    
    
    
    public function getAdsVideos($adsId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $adsId, \PDO::PARAM_INT);
        $query->bindValue(2, $this::MEDIA_VIDEO_TYPE, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdsMedias($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    
    public function getAdsMedia($adsId, $mediaAddTime):AdsMedia{
        $out = AdsMedia::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[5]["name"]." = ?;
                ");
        $query->bindValue(1, $adsId, \PDO::PARAM_INT);
        $query->bindValue(2, $mediaAddTime, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdsMedia($query);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function deleteAdsMedia($adsId, $mediaAddTime):bool{
        $media = $this->getAdsMedia($adsId, $mediaAddTime);
        if(!empty($media->getMediaName())){
            if($media->getMediaType() == \DJOLUC\AdsBundle\Model\Frontend\AdsMediaDataSource::MEDIA_IMAGE_TYPE){
                \unlink("runningData/AdsMedia/Image/".$media->getMediaName()."");
                \unlink("runningData/AdsMedia/Image/mini/".$media->getMediaName()."");
            }else{
                \unlink("runningData/AdsMedia/Video/".$media->getMediaName()."");
            }
        }
            
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[5]["name"]." = ?;
                ");
        $query->bindValue(1, $adsId, \PDO::PARAM_INT);
        $query->bindValue(2, $mediaAddTime, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }



    public function queryToAdsMedia(\PDOStatement $query):AdsMedia{
        $out = AdsMedia::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new AdsMedia($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        
        return $out;
    }
    
    
    
    public function queryToAdsMedias(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
           $i = 0;
           $out[count($out)] = new AdsMedia($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
}
