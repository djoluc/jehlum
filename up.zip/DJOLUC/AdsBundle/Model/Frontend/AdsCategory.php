<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AdsCategory
 *
 * @author djoluc
 */
class AdsCategory {
    private $categoryId, 
            $categoryType,
            $categoryName, 
            $categoryAddTime;
    
    
    public function __construct($categoryId, $categoryType, $categoryName, $categoryAddTime) {
        $this->categoryId = $categoryId;
        $this->categoryType = $categoryType;
        $this->categoryName = $categoryName;
        $this->categoryAddTime = $categoryAddTime;
    }

    
    public function getCategoryId() {
        return $this->categoryId;
    }

    public function getCategoryType() {
        return $this->categoryType;
    }

    public function getCategoryName() {
        return $this->categoryName;
    }

    public function getCategoryAddTime() {
        return $this->categoryAddTime;
    }

    public function setCategoryId($categoryId) {
        $this->categoryId = $categoryId;
    }

    public function setCategoryType($categoryType) {
        $this->categoryType = $categoryType;
    }

    public function setCategoryName($categoryName) {
        $this->categoryName = $categoryName;
    }

    public function setCategoryAddTime($categoryAddTime) {
        $this->categoryAddTime = $categoryAddTime;
    }

        
    public static function getEmpty():AdsCategory{
        return new AdsCategory(0, 0, "", 0);
    }
    
    
    
    public function getAdsNumb($search = ""):int{
        $adsDataSource = new AdsDataSource();
        
        return $adsDataSource->getCategoryAdsNumb($this->categoryId, $search);
    }

}
