<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AnAdLocation
 *
 * @author djoluc
 */
class AnAdLocation {
    private $adId, 
            $locationId;
    
    public function __construct($adId, $locationId) {
        $this->adId = $adId;
        $this->locationId = $locationId;
    }
    
    
    public function getAdId() {
        return $this->adId;
    }

    public function getLocationId() {
        return $this->locationId;
    }

    public function setAdId($adId) {
        $this->adId = $adId;
    }

    public function setLocationId($locationId) {
        $this->locationId = $locationId;
    }


    public static function getEmpty():AnAdLocation{
        return new AnAdLocation(0, 0);
    }

}
