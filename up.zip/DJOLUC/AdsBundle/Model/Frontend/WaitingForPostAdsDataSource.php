<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of WaitingForPostAdsDataSource
 *
 * @author djoluc
 */
class WaitingForPostAdsDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "waiting_for_social_post_ads_table";
    
    const POST_AFTER_SECONDE_TIME = 45*60;
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("ad_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNIQUE_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("time_to_post", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addRelation($this->columns[0]["name"], AdsDataSource::TABLE_NAME."(".AdsDataSource::getColumns()[0]["name"].")", "ON UPDATE CASCADE ON DELETE CASCADE");
        $this->createTable($this::TABLE_NAME);
    }
    
    
    
    
    public function addWaitingAd($adId, $postAtTime):bool{
        if($this->isInWaitingList($adId)){
            return FALSE;
        }
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(?, ?);
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        $query->bindValue(2, $postAtTime, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public static function addWaitingAdStaticly($adId):bool{
        $thisObject = new self();
        $postAtTime = 0;
        $currentMaxTime = $thisObject->getWaitingAdsMaxTime();
        if($currentMaxTime == 0){
            $postAtTime = \time() + WaitingForPostAdsDataSource::POST_AFTER_SECONDE_TIME;
        }else{
            $postAtTime = $currentMaxTime + WaitingForPostAdsDataSource::POST_AFTER_SECONDE_TIME;
        }
        
        
        return $thisObject->addWaitingAd($adId, $postAtTime);
    }
    
    
    public function isInWaitingList($adId):bool{
        $out = FALSE;
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] > 0;
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getWaitingAdsMaxTime():int{
        $out = 0;
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT MAX(".$this->columns[1]["name"].") AS max FROM ".$this::TABLE_NAME.";
                ");
        if($query->execute()){
            if($data = $query->fetch()){
                $out = empty($data["max"])?0:$data["max"];
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getNextReadyToBePostAds($first = 0, $numb = 2):array{
        $out = Array();
        $time = \time();
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"]." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[1]["name"]." < ? ORDER BY ".$this->columns[1]["name"]." ASC LIMIT ?, ?;
                ");
        $query->bindValue(1, $time, \PDO::PARAM_INT);
        $query->bindValue(2, $first, \PDO::PARAM_INT);
        $query->bindValue(3, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            while($data = $query->fetch()){
                $out[count($out)] = $data[$this->columns[0]["name"]];
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getNextReadyToBePostForRssAds($first = 0, $numb = 2):array{
        $out = Array();
        $time = \time()-15*60;
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"]." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[1]["name"]." < ? ORDER BY ".$this->columns[1]["name"]." ASC LIMIT ?, ?;
                ");
        $query->bindValue(1, $time, \PDO::PARAM_INT);
        $query->bindValue(2, $first, \PDO::PARAM_INT);
        $query->bindValue(3, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            while($data = $query->fetch()){
                $out[count($out)] = $data[$this->columns[0]["name"]];
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    
    public function deleteFromWaitingList($adId):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?; 
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;

    }
}
