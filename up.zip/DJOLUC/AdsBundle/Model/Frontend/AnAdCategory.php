<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AnAdLocation
 *
 * @author djoluc
 */
class AnAdCategory {
    private $adId, 
            $categoryId;
    
    public function __construct($adId, $categoryId) {
        $this->adId = $adId;
        $this->categoryId = $categoryId;
    }

    public function getAdId() {
        return $this->adId;
    }

    public function getCategoryId() {
        return $this->categoryId;
    }

    public function setAdId($adId) {
        $this->adId = $adId;
    }

    public function setCategoryId($categoryId) {
        $this->categoryId = $categoryId;
    }

        


    public static function getEmpty():AnAdLocation{
        return new AnAdCategory(0, 0);
    }

}
