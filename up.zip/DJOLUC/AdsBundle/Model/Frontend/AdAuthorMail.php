<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AdAuthorMail
 *
 * @author djoluc
 */
class AdAuthorMail {
    private $adId, 
            $email, 
            $verifyCode,
            $isVerified;
    
    
    public function __construct($adId, $email, $verifyCode, $isVerified) {
        $this->adId = $adId;
        $this->email = $email;
        $this->verifyCode = $verifyCode;
        $this->isVerified = $isVerified;
    }

    
    public function getAdId() {
        return $this->adId;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getVerifyCode() {
        return $this->verifyCode;
    }

    public function getIsVerified() {
        return $this->isVerified;
    }

    public function setAdId($adId) {
        $this->adId = $adId;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function setVerifyCode($verifyCode) {
        $this->verifyCode = $verifyCode;
    }

    public function setIsVerified($isVerified) {
        $this->isVerified = $isVerified;
    }

        
    public static function getEmpty():AdAuthorMail{
        return new AdAuthorMail(0, "", "", FALSE);
    }
}
