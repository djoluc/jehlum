<?php


namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AnAdCategoryDataSource
 *
 * @author djoluc
 */
class AnAdCategoryDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "and_add_category";
    
    public function __construct() {
        parent::__construct();
        
        
        $this->addColumns("ad_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("ad_category", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        
        $this->addRelation($this->columns[0]["name"], AdsDataSource::TABLE_NAME."(".AdsDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        $this->addRelation($this->columns[1]["name"], AdsCategoryDataSource::TABLE_NAME."(". AdsCategoryDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        $this->createTable($this::TABLE_NAME);
    }
    
    
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new self();
        
        return $thisObject->columns;
    }
    
    
    
    public function addAdCategory($adId, $categoryId):bool{
        if($this->isAdsCategory($adId, $categoryId)){
            return FALSE;
        }
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns)).");
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        $query->bindValue(2, $categoryId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function updateAdCategories($adId, $categoryIds){
        $currentCategories = $this->getAdAllCategory($adId);
        
        foreach ($currentCategories AS $currentCategory){
            foreach ($categoryIds AS $categoryId){
                if($categoryId == $currentCategory->getCategoryId()){
                    continue;
                }else{
                    $this->deleteAdCategory($adId, $currentCategory->getCategoryId());
                }
            }
        }
        
        
        foreach ($categoryIds AS $categoryId){
            if(!$this->isAdsCategory($adId, $categoryId)){
                $this->addAdCategory($adId, $categoryId);
            }
        }
    }
    
    
    
    public function getAdAllCategory($adId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAnAdCategories($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function isAdsCategory($adId, $categoryId):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[1]["name"].") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        $query->bindValue(2, $categoryId, \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] > 0;
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function deleteAdCategory($adId, $locationId):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        $query->bindValue(2, $locationId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = TRUE;
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function queryToAnAdCategory(\PDOStatement $query):AnAdCategory{
        $out = AnAdCategory::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new AnAdcategory($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    public function queryToAnAdCategories(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new AnAdCategory($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
}
