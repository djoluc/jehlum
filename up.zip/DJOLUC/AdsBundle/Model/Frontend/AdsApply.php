<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AdsApply
 *
 * @author djoluc
 */
class AdsApply {
    private $adId, 
            $applyAuhorEmail, 
            $attachedFileName, 
            $applyTime;
    
    
    public function __construct($adId, $applyAuhorEmail, $attachedFileName, $applyTime) {
        $this->adId = $adId;
        $this->applyAuhorEmail = $applyAuhorEmail;
        $this->attachedFileName = $attachedFileName;
        $this->applyTime = $applyTime;
    }

    
    public function getAdId() {
        return $this->adId;
    }

    public function getApplyAuhorEmail() {
        return $this->applyAuhorEmail;
    }

    public function getAttachedFileName() {
        return $this->attachedFileName;
    }

    public function getApplyTime() {
        return $this->applyTime;
    }

    public function setAdId($adId) {
        $this->adId = $adId;
    }

    public function setApplyAuhorEmail($applyAuhorEmail) {
        $this->applyAuhorEmail = $applyAuhorEmail;
    }

    public function setAttachedFileName($attachedFileName) {
        $this->attachedFileName = $attachedFileName;
    }

    public function setApplyTime($applyTime) {
        $this->applyTime = $applyTime;
    }

            
    public static function getEMpty():AdsApply{
        return new AdsApply(0, 0, 0, "", 0);
    }

}
