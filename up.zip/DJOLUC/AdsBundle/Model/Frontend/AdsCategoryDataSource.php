<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AdsCategoryDataSource
 *
 * @author djoluc
 */
class AdsCategoryDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "ads_category_table";
    
    const JOB_TYPE = 1;
    const CLASSFIELD_TYPE = 2;
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("category_id", Array(
            Array(
                "name" => $this::COLUMN_INDEX_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("category_type", Array(
            Array(
                "name" => $this::INT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("category_name", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "300", 
                "completers" => ""
            )
        ));
        $this->addColumns("category_add_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addPrimaryKey($this->columns[0]["name"]);
        //$this->createTable($this::TABLE_NAME);
    }
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new self();
        
        return $thisObject->columns;
    }
    
    
    
    public function addCategory($categoryType, $categoryName, $categoryAddTime):bool{
        $out = FALSE;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns) - 1).");
                ");
        $query->bindValue(1, $categoryType, \PDO::PARAM_STR);
        $query->bindValue(2, $categoryName, \PDO::PARAM_STR);
        $query->bindValue(3, $categoryAddTime, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getAdsCategory($categoryId):AdsCategory{
        $out = AdsCategory::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?; 
                ");
        $query->bindValue(1, $categoryId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdsCategory($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function deleteAdsCategory($categoryId):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME."  WHERE ".$this->columns[0]["name"]." = ?; 
                ");
        $query->bindValue(1, $categoryId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function isCategoryExist($categoryType, $categoryName):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME."  WHERE ".$this->columns[1]["name"]." = ? AND lower(".$this->columns[2]["name"].") = ?; 
                ");
        $query->bindValue(1, $categoryType, \PDO::PARAM_INT);
        $query->bindValue(2, strtolower($categoryName), \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] > 0;
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getAllAdsCategory():array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." ORDER BY ".$this->columns[2]["name"]." ASC; 
                ");
        if($query->execute()){
            $out = $this->queryToAdsCategories($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getAllCategoryAsHtmlOptions($adId = 0):string{
        $categories = $this->getAllAdsCategory();
        
        $anAdCategoryDataSource = new AnAdCategoryDataSource();
        
        $out = "";
        foreach ($categories AS $category){
            if($anAdCategoryDataSource->isAdsCategory($adId, $category->getCategoryId())){
                $out .= "<option selected value='".$category->getCategoryId()."'>".$category->getCategoryName()."</option>";
            }else{
               $out .= "<option value='".$category->getCategoryId()."'>".$category->getCategoryName()."</option>"; 
            }
        }
        
        return $out;
    }
    
    
    
    public function getTypeCategoriesAsHtmlOptions($type, $adId = 0):string{
        $categories = $this->getAllAdsCategory();
        
        $anAdCategoryDataSource = new AnAdCategoryDataSource();
        
        $out = "";
        foreach ($categories AS $category){
            if($category->getCategoryType() == $type){
                if($anAdCategoryDataSource->isAdsCategory($adId, $category->getCategoryId())){
                    $out .= "<option selected value='".$category->getCategoryId()."'>".$category->getCategoryName()."</option>";
                }else{
                    $out .= "<option value='".$category->getCategoryId()."'>".$category->getCategoryName()."</option>"; 
                }
            }
        }
        
        return $out;
    }
    
    
    public function getCategoryNumb():int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME."; 
                ");
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            $this->throwException("AdsCategoryDataSource::getCategoryNumb:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    private function queryToAdsCategory(\PDOStatement $query):AdsCategory{
        $out = AdsCategory::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new AdsCategory($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    
    private function queryToAdsCategories(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new AdsCategory($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
}
