<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AdsLocation
 *
 * @author djoluc
 */
class AdsLocation {
    private $locationId, 
            $locationName, 
            $locationAddTime;
    
    public function __construct($locationId, $locationName, $locationAddTime) {
        $this->locationId = $locationId;
        $this->locationName = $locationName;
        $this->locationAddTime = $locationAddTime;
    }

    
    public function getLocationId() {
        return $this->locationId;
    }

    public function getLocationName() {
        return $this->locationName;
    }

    public function getLocationAddTime() {
        return $this->locationAddTime;
    }

    public function setLocationId($locationId) {
        $this->locationId = $locationId;
    }

    public function setLocationName($locationName) {
        $this->locationName = $locationName;
    }

    public function setLocationAddTime($locationAddTime) {
        $this->locationAddTime = $locationAddTime;
    }
    
    
    public static function getEmpty():AdsLocation{
        return new AdsLocation(0, "", 0);
    }
    
    
    public function getAdsNumb($search = ""):int{
        $adsDataSource = new AdsDataSource();
        
        return $adsDataSource->getLocationAdsNumb($this->locationId, $search);
    }
}
