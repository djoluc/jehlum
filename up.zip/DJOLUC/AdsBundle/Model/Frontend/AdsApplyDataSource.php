<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AdsApplyDataSource
 *
 * @author djoluc
 */
class AdsApplyDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "ads_apply_table";
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("apply_id", Array(
            Array(
                "name" => $this::COLUMN_INDEX_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("apply_ad_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("apply_ad_author_email", Array(
            Array(
                "name" => $this::TEXT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
        ));
        $this->addColumns("apply_add_attache_file", Array(
            Array(
                "name" => $this::VARCHAR_ATTR,
                "param" => "300", 
                "completers" => ""
            )
        ));
        $this->addColumns("apply_add_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        if(!\is_dir("runningData/AdsApply")){
            \mkdir("runningData/AdsApply");
        }
        
        $this->addPrimaryKey($this->columns[0]["name"]);
        $this->addRelation($this->columns[1]["name"], AdsDataSource::TABLE_NAME."(".AdsDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        
        $this->createTable($this::TABLE_NAME);
    }
    
    
    public static function getColumns():array {
        parent::getColumns();
        
        $thisObject = new self();
        
        return $thisObject->columns;
    }
    
    
    public function addAdApply($adId, $applyAuhorEmail, $attachedFileName, $applyTime):int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns) - 1).");
                ");
        $i = 1;
        $query->bindValue($i++, $adId, \PDO::PARAM_INT);
        $query->bindValue($i++, $applyAuhorEmail, \PDO::PARAM_STR);
        $query->bindValue($i++, $attachedFileName, \PDO::PARAM_STR);
        $query->bindValue($i++, $applyTime, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->DbPdo->lastInsertId();
        }else{
            $this->throwException("AdsApplyDataSource::addAdApply() ".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getAdApply($adApplyId):AdsApply{
        $out = AdsApply::getEMpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $adApplyId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdsApply($query);
        }else{
            $this->throwException("AdsApplyDataSource::getAdApply() ".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getAdApplies($adId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdsApplies($query);
        }else{
            $this->throwException("AdsApplyDataSource::getAdApply() ".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function updateAttachedFile($applyId, $fileName):bool{
        $out = FALSE;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this->columns[3]["name"]." = ? WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $fileName, \PDO::PARAM_STR);
        $query->bindValue(2, $applyId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = TRUE;
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    private function queryToAdsApply(\PDOStatement $query):AdsApply{
        $out = AdsApply::getEMpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new AdsApply($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
    }
    
    private function queryToAdsApplies(\PDOStatement $query):array{
        $out = Array();
        
        if($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new AdsApply($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
}
