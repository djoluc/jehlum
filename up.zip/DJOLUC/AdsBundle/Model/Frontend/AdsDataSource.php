<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AdsDataSource
 *
 * @author djoluc
 */
class AdsDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "ads_table";
    
    public function __construct() {
        parent::__construct();
        
        
        $this->addColumns("ads_id", Array(
            Array(
                "name" => $this::COLUMN_INDEX_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("ads_title", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "300", 
                "completers" => ""
            )
        ));
        $this->addColumns("ads_description", Array(
            Array(
                "name" => $this::TEXT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("ads_autor", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        /*$this->addColumns("ads_category", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));*/
        $this->addColumns("is_activate", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::NOT_NULL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::DEFAULT_ATTR, 
                "param" => "", 
                "completers" => "FALSE"
            )
        ));
        $this->addColumns("ads_add_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_posted", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        
        $this->addPrimaryKey($this->columns[0]["name"]);
        $this->addRelation($this->columns[3]["name"], \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME."(".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID.")", "ON DELETE CASCADE ON UPDATE CASCADE");
        $this->createTable($this::TABLE_NAME);
        
        
        $toPostAds = $this->getReadyToPostAds();
        
        foreach ($toPostAds AS $ad){
            //$this->shareOnFacebook(SITE_ROOT."adsManage/view/".$ad->getAdsId());
            break;
        }
    }
    
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new self();
        
        return $thisObject->columns;
    }
    
    
    public function addAds($adsTitle, $adsDescription, $adsAutor, $isActivate, $adsAddTime, $isPosted = FALSE):int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns) - 1).");
                ");
        $i = 1;
        $query->bindValue($i++, $adsTitle, \PDO::PARAM_STR);
        $query->bindValue($i++, $adsDescription, \PDO::PARAM_STR);
        $query->bindValue($i++, $adsAutor, \PDO::PARAM_INT);
        $query->bindValue($i++, $isActivate, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $adsAddTime, \PDO::PARAM_INT);
        $query->bindValue($i++, $isPosted, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->DbPdo->lastInsertId();
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getAllActivateAdsNumb():int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT count(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this->columns[4]["name"]." = ?;
                ");
        $query->bindValue(1, TRUE, \PDO::PARAM_BOOL);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function updateAds($adsId, $adsTitle, $adsDescription, $adsAutor):bool{
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this->columns[1]["name"]." = ? , ".$this->columns[2]["name"]." = ?, ".$this->columns[3]["name"]." = ?  WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $i = 1;
        $query->bindValue($i++, $adsTitle, \PDO::PARAM_STR);
        $query->bindValue($i++, $adsDescription, \PDO::PARAM_STR);
        $query->bindValue($i++, $adsAutor, \PDO::PARAM_INT);
        $query->bindValue($i++, $adsId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function setAdsActivate($adsId, $status = TRUE):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this->columns[4]["name"]." = ? WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $i = 1;
        $query->bindValue($i++, $status, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $adsId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        if($status && !$this->isAdPosted($adId)){
            WaitingForPostAdsDataSource::addWaitingAdStaticly($adsId);
        }
        
        return $out;
    }
    
    
    public function setAdsPosted($adsId, $status = TRUE):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this->columns[6]["name"]." = ? WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $i = 1;
        $query->bindValue($i++, $status, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $adsId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }

    
    
    
    public function isAdPosted($adId){
        return $this->getAds($adId)->getIsPosted();
    }

    
    
    public function getAds($adsId): Ads{
        $out = Ads::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $adsId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAds($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getSearchedAdProposition($locationId, $search = "", $first = 0, $limit = 10):array{
        $out = Array();
        $search = strtolower($search);
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." LEFT JOIN ".AnAdLocationDataSource::TABLE_NAME." ON 
                    ".$this::TABLE_NAME.".".$this->columns[0]["name"]." = ".AnAdLocationDataSource::TABLE_NAME.".".AnAdLocationDataSource::getColumns()[0]["name"]." WHERE 
                    ".AnAdLocationDataSource::getColumns()[1]["name"]." = ? AND ".$this->columns[4]["name"]." = ? AND
                (
                        ".$this->columns[1]["name"]." LIKE ? OR
                ".$this->columns[2]["name"]." LIKE ?
                )
             ORDER BY ".$this->columns[count($this->columns) - 2]["name"]." DESC LIMIT ?, ?;
                ");
        $i = 1;
        $query->bindValue($i++, $locationId, \PDO::PARAM_INT);
        $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, $first, \PDO::PARAM_INT);
        $query->bindValue($i++, $limit, \PDO::PARAM_INT);
        if($query->execute()){
            while ($data = $query->fetch()){
                $out[count($out)] = $data[$this->columns[1]["name"]];
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getSearchedAds($locationId, $search = "", $first = 0, $limit = 10):array{
        $out = Array();
        $search = strtolower($search);
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." LEFT JOIN ".AnAdLocationDataSource::TABLE_NAME." ON 
                    ".$this::TABLE_NAME.".".$this->columns[0]["name"]." = ".AnAdLocationDataSource::TABLE_NAME.".".AnAdLocationDataSource::getColumns()[0]["name"]." WHERE 
                    ".AnAdLocationDataSource::getColumns()[1]["name"]." = ? AND ".$this->columns[4]["name"]." = ? AND
                (
                    ".$this->columns[1]["name"]." LIKE ? OR
                    ".$this->columns[2]["name"]." LIKE ?
                )
             ORDER BY ".$this->columns[count($this->columns) - 2]["name"]." DESC LIMIT ?, ?;
                ");
        $i = 1;
        $query->bindValue($i++, $locationId, \PDO::PARAM_INT);
        $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, $first, \PDO::PARAM_INT);
        $query->bindValue($i++, $limit, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdss($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getSearchedAdNumb($locationId, $search = ""):int{
        $out = 0;
        $search = strtolower($search);
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT count(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME." LEFT JOIN ".AnAdLocationDataSource::TABLE_NAME." ON 
                    ".$this::TABLE_NAME.".".$this->columns[0]["name"]." = ".AnAdLocationDataSource::TABLE_NAME.".".AnAdLocationDataSource::getColumns()[0]["name"]." WHERE 
                    ".AnAdLocationDataSource::getColumns()[1]["name"]." = ? AND ".$this->columns[4]["name"]." = ? AND
                (
                        ".$this->columns[1]["name"]." LIKE ? OR
                ".$this->columns[2]["name"]." LIKE ?
                )
                ");
        $i = 1;
        $query->bindValue($i++, $locationId, \PDO::PARAM_INT);
         $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getPendingAdsNumb():int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME." LEFT JOIN ".AdAuthorMailDataSource::TABLE_NAME." ON ".$this::TABLE_NAME.".".$this->columns[0]["name"]." = ".AdAuthorMailDataSource::TABLE_NAME.".".AdAuthorMailDataSource::getColumns()[0]["name"]." WHERE ".AdAuthorMailDataSource::TABLE_NAME.".".AdAuthorMailDataSource::getColumns()[3]["name"]." = ? AND  ".$this->columns[4]["name"]." = ?;
                ");
        $query->bindValue(1, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue(2, FALSE, \PDO::PARAM_BOOL);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            $this->throwException("AdsDataSource::getPendingAdsNumb:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getPendingAds():array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." LEFT JOIN ".AdAuthorMailDataSource::TABLE_NAME." ON ".$this::TABLE_NAME.".".$this->columns[0]["name"]." = ".AdAuthorMailDataSource::TABLE_NAME.".".AdAuthorMailDataSource::getColumns()[0]["name"]." WHERE ".AdAuthorMailDataSource::TABLE_NAME.".".AdAuthorMailDataSource::getColumns()[3]["name"]." = ? AND  ".$this->columns[4]["name"]." = ? 
                        ORDER BY ".$this->columns[count($this->columns)-2]["name"]." DESC;
                ");
        $query->bindValue(1, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue(2, FALSE, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->queryToAdss($query);
        }else{
            $this->throwException("AdsDataSource::getPendingAdsNumb:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getActivatedAds($search = "", $first = 0, $numb = 20):array{
        $out = Array();
        
        $search = strtolower($search);
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[4]["name"]." = ? AND 
                        (
                          lower(".$this->columns[1]["name"].") LIKE ? OR 
                          lower(".$this->columns[2]["name"].") LIKE ? 
                        )
                    ORDER BY ".$this->columns[count($this->columns) - 2]["name"]." DESC LIMIT ?, ?;
                ");
        $i = 1;
        $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, $first, \PDO::PARAM_INT);
        $query->bindValue($i++, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdss($query);
        }else{
            $this->throwException("AdsDataSource::getActivatedAds:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    
    public function getCategoryAds($categoryId, $search = "", $first = 0, $numb = 20):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[4]["name"]." = ? AND 
                        (
                          lower(".$this->columns[1]["name"].") LIKE ? OR 
                          lower(".$this->columns[2]["name"].") LIKE ?
                        )
                    ORDER BY ".$this->columns[count($this->columns) - 2]["name"]." DESC LIMIT ?, ?;
                ");
        $i = 1;
        $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, $first, \PDO::PARAM_INT);
        $query->bindValue($i++, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdss($query);
        }else{
            $this->throwException("AdsDataSource::getActivatedAds:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getCategoryAdsNumb($categoryId, $search = ""):int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this->columns[5]["name"]." = ? AND ".$this->columns[4]["name"]." = ? AND 
                        (
                          lower(".$this->columns[1]["name"].") LIKE ? OR 
                          lower(".$this->columns[2]["name"].") LIKE ?
                        );
                ");
        $i = 1;
        $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $categoryId, \PDO::PARAM_INT);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            $this->throwException("AdsDataSource::getActivatedAds:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getLocationAds($locationId, $search = "", $first = 0, $numb = 20):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[4]["name"]." = ? AND ".$this->columns[0]["name"]." IN (SELECT ".AnAdLocationDataSource::getColumns()[0]["name"]." FROM ".AnAdLocationDataSource::TABLE_NAME." WHERE ".\DJOLUC\AdsBundle\Model\Frontend\AnAdLocationDataSource::getColumns()[1]["name"]." = ? ) AND 
                        (
                          lower(".$this->columns[1]["name"].") LIKE ? OR 
                          lower(".$this->columns[2]["name"].") LIKE ?
                        )
                    ORDER BY ".$this->columns[count($this->columns) - 2]["name"]." DESC LIMIT ?, ?;
                ");
        $i = 1;
        $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $locationId, \PDO::PARAM_INT);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, $first, \PDO::PARAM_INT);
        $query->bindValue($i++, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdss($query);
        }else{
            $this->throwException("AdsDataSource::getActivatedAds:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getLocationAdsNumb($locationId, $search = ""):int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this->columns[4]["name"]." = ? AND ".$this->columns[0]["name"]." IN (SELECT ".AnAdLocationDataSource::getColumns()[0]["name"]." FROM ".AnAdLocationDataSource::TABLE_NAME." WHERE ".\DJOLUC\AdsBundle\Model\Frontend\AnAdLocationDataSource::getColumns()[1]["name"]." = ? ) AND 
                        (
                          lower(".$this->columns[1]["name"].") LIKE ? OR 
                          lower(".$this->columns[2]["name"].") LIKE ?
                        );
                ");
        $i = 1;
        $query->bindValue($i++, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $locationId, \PDO::PARAM_INT);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$search."%", \PDO::PARAM_STR);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            $this->throwException("AdsDataSource::getActivatedAds:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getUserAllAds($userId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[3]["name"]." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdss($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getUserMoreAds($userId, $currentAdsId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[3]["name"]." = ? AND ".$this->columns[0]["name"]." != ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $currentAdsId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAdss($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function deleteAds($adsId):bool{
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $adsId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getReadyToPostAds():array{
        $out = Array();
        
        $timestamp = \time() - 30*60;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[count($this->columns) - 2]["name"]." <= ? AND ".$this->columns[count($this->columns)-1]["name"]." = ? ORDER BY ".$this->columns[count($this->columns)-2]["name"]." DESC;
                ");
        $query->bindValue(1, $timestamp, \PDO::PARAM_INT);
        $query->bindValue(2, FALSE, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->queryToAdss($query);
        }else{
            $this->throwException(__CLASS__."::".__FUNCTION__.":".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    
    
    public function shareOnFacebook($contentLink){
        $fb = new \Facebook\Facebook([
            'app_id' => 'xxxxxxxxxx',
            'app_secret' => 'xxxxxxxxxx',
            'default_graph_version' => 'v2.2',
        ]);

        $linkData = [
            'link' => $contentLink,
            'message' => 'Your message here'
        ];
        $pageAccessToken ='yournonexpiringtoken';

        try {
            $response = $fb->post('/me/feed', $linkData, $pageAccessToken);
        } catch(Facebook\Exceptions\FacebookResponseException $e) {
            echo 'Graph returned an error: '.$e->getMessage();
            exit;
        } catch(Facebook\Exceptions\FacebookSDKException $e) {
            echo 'Facebook SDK returned an error: '.$e->getMessage();
            exit;
        }
        $graphNode = $response->getGraphNode();
    }
    
    
    
    private function queryToAds(\PDOStatement $query):Ads{
        $out = Ads::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new Ads($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    
    
    private function queryToAdss(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new Ads($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
}
