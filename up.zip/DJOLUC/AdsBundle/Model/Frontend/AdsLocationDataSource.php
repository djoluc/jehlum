<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of LocationDataSource
 *
 * @author djoluc
 */
class AdsLocationDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "ads_location_table";
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("location_id", array(
            Array(
                "name" => $this::COLUMN_INDEX_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("location_name", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "300", 
                "completers" => ""
            )
        ));
        $this->addColumns("location_add_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addPrimaryKey($this->columns[0]["name"]);
        $this->createTable($this::TABLE_NAME);
    }
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new self();
        
        return $thisObject->columns;
    }
    
    
    
    
    public function addLocation($locationName, $locationAddTime):bool{
        $out = FALSE;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns) - 1).");
                ");
        $query->bindValue(1, $locationName, \PDO::PARAM_STR);
        $query->bindValue(2, $locationAddTime, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
   public function getLocation($locationId):AdsLocation{
       $out = AdsLocation::getEmpty();
       
       $query = new \PDOStatement();
       $query = $this->DbPdo->prepare
               ("
                   SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
               ");
       $query->bindValue(1, $locationId, \PDO::PARAM_INT);
       if($query->execute()){
           $out = $this->queryToAdsLocation($query);
       }else{
           $this->throwException($query->errorInfo()[2]);
       }
       $query->closeCursor();
       
       return $out;
   }
   
   
   public function deleteAdsLocation($locationId):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME."  WHERE ".$this->columns[0]["name"]." = ?; 
                ");
        $query->bindValue(1, $locationId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
   
   
   public function isLocationExist($locationName):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME."  WHERE lower(".$this->columns[1]["name"].") = ?; 
                ");
        $query->bindValue(1, strtolower($locationName), \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] > 0;
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
   
   
   public function getAllLocation():array{
       $out = Array();
       
       $query = new \PDOStatement();
       $query = $this->DbPdo->prepare
               ("
                   SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." ORDER BY ".$this->columns[1]["name"]." ASC;
               ");
       if($query->execute()){
           $out = $this->queryToAdsLocations($query);
       }else{
           $this->throwException($query->errorInfo()[2]);
       }
       $query->closeCursor();
       
       return $out;
   }
   
   public function getAllLocationAsHtmlOptions($adId = 0):string{
       $locations = $this->getAllLocation();
       
       $anAdLocationDataSource = new AnAdLocationDataSource();
       
       $out = "";
       
       foreach ($locations AS $location){
           if($anAdLocationDataSource->isAdsLocation($adId, $location->getLocationId())){
               $out .= "<option selected value='".$location->getLocationId()."'>".$location->getLocationName()."</option>";
           }else{
               $out .= "<option value='".$location->getLocationId()."'>".$location->getLocationName()."</option>";
           }
           
       }
       
       return $out;
   }
   
   
   public function getLocationNumb():int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME."; 
                ");
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            $this->throwException("AdsLocationDataSource::getLocationNumb:".$query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
   
   
   
   public function queryToAdsLocation(\PDOStatement $query):AdsLocation{
       $out = AdsLocation::getEmpty();
       
       if($data = $query->fetch()){
           $i = 0;
           $out = new AdsLocation($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
       }
       
       return $out;
   }
   
   
   public function queryToAdsLocations(\PDOStatement $query):array{
       $out = Array();
       
       while($data = $query->fetch()){
           $i = 0;
           $out[count($out)] = new AdsLocation($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
       }
       
       return $out;
   }
}
