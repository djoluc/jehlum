<?php

namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of AnAdLocationDataSource
 *
 * @author djoluc
 */
class AnAdLocationDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "an_ads_location";
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("ad_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("ad_location", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        
        $this->addRelation($this->columns[0]["name"], AdsDataSource::TABLE_NAME."(".AdsDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        $this->addRelation($this->columns[1]["name"], AdsLocationDataSource::TABLE_NAME."(".AdsLocationDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        $this->createTable($this::TABLE_NAME);
    }
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new self();
        
        return $thisObject->columns;
    }
    
    
    
    public function addAdLocation($adId, $locationId):bool{
        if($this->isAdsLocation($adId, $locationId)){
            return FALSE;
        }
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns)).");
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        $query->bindValue(2, $locationId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function updateAdLocations($adId, $locationIds){
        $currentLocations = $this->getAdAllLocation($adId);
        
        foreach ($currentLocations AS $currentLocation){
            foreach ($locationIds AS $locationId){
                if($locationId == $currentLocation->getLocationId()){
                    continue;
                }else{
                    $this->deleteAdLocation($adId, $currentLocation->getLocationId());
                }
            }
        }
        
        
        foreach ($locationIds AS $locationId){
            if(!$this->isAdsLocation($adId, $locationId)){
                $this->addAdLocation($adId, $locationId);
            }
        }
    }
    
    
    
    public function getAdAllLocation($adId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToAnAdLocations($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function isAdsLocation($adId, $locationId):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[1]["name"].") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        $query->bindValue(2, $locationId, \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] > 0;
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function deleteAdLocation($adId, $locationId):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $adId, \PDO::PARAM_INT);
        $query->bindValue(2, $locationId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = TRUE;
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function queryToAnAdLocation(\PDOStatement $query):AnAdLocation{
        $out = AnAdLocation::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new AnAdLocation($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    public function queryToAnAdLocations(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new AnAdLocation($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
}
