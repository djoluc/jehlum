<?php


namespace DJOLUC\AdsBundle\Model\Frontend;

/**
 * Description of Ads
 *
 * @author djoluc
 */
class Ads {
    private $adsId, 
            $adsTitle, 
            $adsDescription, 
            $adsAutor, 
            $isActivate, 
            $adsAddTime, 
            $isPosted;
    
    
    public function __construct($adsId, $adsTitle, $adsDescription, $adsAutor, $isActivate, $adsAddTime, $isPosted = FALSE) {
        $this->adsId = $adsId;
        $this->adsTitle = $adsTitle;
        $this->adsDescription = $adsDescription;
        $this->adsAutor = $adsAutor;
        $this->isActivate = $isActivate;
        $this->adsAddTime = $adsAddTime;
        $this->isPosted = $isPosted;
    }
    
    
    public function getAdsId() {
        return $this->adsId;
    }
    public function getIsActivate() {
        return $this->isActivate;
    }

    public function setIsActivate($isActivate) {
        $this->isActivate = $isActivate;
    }

    public function getAdsTitle() {
        return $this->adsTitle;
    }

    public function getAdsDescription() {
        $out = str_replace("\n", "<br/>", stripslashes($this->adsDescription));
        
        $out = str_replace(" ", " &nbsp;", $out);
        
        $out = str_replace("\t", " &nbsp;", $out);
        
        return $out;
    }
    
    public function getAdsPureDescription() {
        return $this->adsDescription;
    }

    public function getAdsAutor() {
        return $this->adsAutor;
    }

    public function getAdsCategory() {
        $anAdCategoryDataSource = new AnAdCategoryDataSource();
        
        $categories = $anAdCategoryDataSource->getAdAllCategory($this->adsId);
        
        return isset($categories[0])?$categories[0]->getCategoryId():0;
    }
    
    
    public function getAdTypeName(){
        $adsCategoryDataSource = new AdsCategoryDataSource();
        $adCategory = $adsCategoryDataSource->getAdsCategory($this->getAdsCategory());
        
        return $adCategory->getCategoryType()== AdsCategoryDataSource::JOB_TYPE?"Job":"Classfield";
    }
    
    
    public function getAdType(){
        $adsCategoryDataSource = new AdsCategoryDataSource();
        $adCategory = $adsCategoryDataSource->getAdsCategory($this->getAdsCategory());
        
        return $adCategory->getCategoryType();
    }

    public function getAdsLocation() {
        $anAdLocationDataSource = new AnAdLocationDataSource();
        
        $locations = $anAdLocationDataSource->getAdAllLocation($this->adsId);
        return isset($locations[0])?$locations[0]->getLocationId():0;
    }
    
    
    public function getIsPosted() {
        return $this->isPosted;
    }

    public function setIsPosted($isPosted) {
        $this->isPosted = $isPosted;
    }

    

    public function getAdsAddTime() {
        return $this->adsAddTime;
    }
    
    public function getTimeReference(){
        $dateManege = new \DJOLUC\Helper\php\DateManager();
        
        return $dateManege->getDateReference($this->adsAddTime);
    }

    public function setAdsId($adsId) {
        $this->adsId = $adsId;
    }

    public function setAdsTitle($adsTitle) {
        $this->adsTitle = $adsTitle;
    }

    public function setAdsDescription($adsDescription) {
        $this->adsDescription = $adsDescription;
    }

    public function setAdsAutor($adsAutor) {
        $this->adsAutor = $adsAutor;
    }

    public function setAdsAddTime($adsAddTime) {
        $this->adsAddTime = $adsAddTime;
    }
    


    public static function getEmpty():Ads{
        return new Ads(0, "", "", 0, "", 0);
    }
    
    
    public function getCategoryName():string{
        $adsCategoryDataSource = new AdsCategoryDataSource();
        
        return $adsCategoryDataSource->getAdsCategory($this->getAdsCategory())->getCategoryName();
    }
    
    
    public function getLocationName():string{
        $adsLocationDataSource = new AdsLocationDataSource();
        
        return $adsLocationDataSource->getLocation($this->getAdsLocation())->getLocationName();
    }
    
    
    public function getAdsPictures():array{
        $adsMediaDataSource = new AdsMediaDataSource();
        
        return $adsMediaDataSource->getAdsPictures($this->adsId);
    }
    
    
    public function getAdsCurrentPicture():AdsMedia{
        $adsMediaDataSource = new AdsMediaDataSource();
        
        return $adsMediaDataSource->getCurrentAdsMedia($this->adsId);
    }
    
    
    
    public function getAdsUser():\DJOLUC\RegisterBundle\Model\Frontend\User{
        $userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        
        return $userDataSource->getUser($this->adsAutor);
    }
    
    
    public function getAllLocationAsString():string{
        $out = "";
        
        $anAdLocationDataSource = new AnAdLocationDataSource();
        $adsLocationDataSource = new AdsLocationDataSource();
        
        $locations = $anAdLocationDataSource->getAdAllLocation($this->adsId);
        
        $i = 0;
        foreach ($locations AS $location){
            $adsLocation = $adsLocationDataSource->getLocation($location->getLocationId());
            if(++$i == count($locations)){
                $out .= $adsLocation->getLocationName();
            }else{
                $out .= $adsLocation->getLocationName().", ";
            }
        }
        
        return $out;
    }
    
    
    public function getAllCategoryAsString():string{
        $out = "";
        
        $anAdCategoryDataSource = new AnAdCategoryDataSource();
        $adsCategoryDataSource = new AdsCategoryDataSource();
        
        $categories = $anAdCategoryDataSource->getAdAllCategory($this->adsId);
        
        $i = 0;
        foreach ($categories AS $category){
            $adsCategory = $adsCategoryDataSource->getAdsCategory($category->getCategoryId());
            if(++$i == count($categories)){
                $out .= $adsCategory->getCategoryName();
            }else{
                $out .= $adsCategory->getCategoryName().", ";
            }
        }
        
        return $out;
    }
    
    
    public function getAdLink():string{
        return SITE_URL.'/adsManage/view/'.$this->getAdsId().'';
    }
    
    
    public function getCurrentPictureUrl():string{
        return SITE_URL.'/runningData/AdsMedia/Image/'.$this->getAdsCurrentPicture()->getMediaName().'';
    }
    
}
