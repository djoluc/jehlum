<?php

namespace DJOLUC\AdsBundle\Model\Backend;
/**
 * Description of BlackListDataSource
 *
 * @author djoluc
 */
class BlackListDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "back_list";
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("back_email", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "500", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNIQUE_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("add_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        
        $this->createTable($this::TABLE_NAME);
    }
    
    public function addToBlackList($email, $time):bool{
        $out = FALSE;
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns)).");
                ");
        $query->bindValue(1, $email, \PDO::PARAM_STR);
        $query->bindValue(2, $time, \PDO::PARAM_INT);
        if($query->execute()){
            $out = TRUE;
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function isInBlackList($email):bool{
        $out = FALSE;
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[0]["name"].") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $email, \PDO::PARAM_STR);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] > 0;
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function deleteFromBlckList($email):bool{
        $out = false;
        if($this->isInBlackList($email)){
            $query = new \PDOStatement();
            $query = $this->DbPdo->prepare
                    ("
                        DELETE FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                    ");
            $query->bindValue(1, $email, \PDO::PARAM_STR);
            $out = $query->execute();
            if(!$out){
                $this->throwException($query->errorInfo()[2]);
            }
            $query->closeCursor();
        }
        return $out;
    }
    
    
    public function getBlackList($search, $first = 0, $numb = 10):array{
        $out = Array();
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE lower(".$this->columns[0]["name"].") LIKE ? 
                    ORDER BY ".$this->columns[1]["name"]." DESC LIMIT ?, ?;
                ");
        $query->bindValue(1, "%".strtolower($search)."%", \PDO::PARAM_STR);
        $query->bindValue(2, $first, \PDO::PARAM_INT);
        $query->bindValue(3, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToBlackLists($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function queryToBlackList(\PDOStatement $query):BlackList{
        $out = BlackList::getEmpty();
        if($data = $query->fetch()){
            $i = 0; 
            $out = new BlackList($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    
    public function queryToBlackLists(\PDOStatement $query):array{
        $out = Array();
        while($data = $query->fetch()){
            $i = 0; 
            $out[count($out)] = new BlackList($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
}
