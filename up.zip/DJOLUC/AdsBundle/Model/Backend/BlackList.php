<?php


namespace DJOLUC\AdsBundle\Model\Backend;

/**
 * Description of BlackList
 *
 * @author djoluc
 */
class BlackList {
    private $email, 
            $time;
    
    public function __construct($email, $time) {
        $this->email = $email;
        $this->time = $time;
    }

    
    public function getEmail() {
        return $this->email;
    }

    public function getTime() {
        return $this->time;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function setTime($time) {
        $this->time = $time;
    }


    public static function getEmpty():BlackList{
        return new BlackList("", 0);
    }
}
