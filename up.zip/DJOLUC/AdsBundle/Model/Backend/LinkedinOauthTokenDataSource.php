<?php

namespace DJOLUC\AdsBundle\Model\Backend;

/**
 * Description of LinkedinOauthTokenDataSource
 *
 * @author djoluc
 */
class LinkedinOauthTokenDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "linkedin_oauth_token";
    
    public function __construct() {
        parent::__construct();
        
        
        $this->addColumns("auth_token", Array(
            Array(
                "name" => $this::TEXT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("auth_expire", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        
        $this->createTable($this::TABLE_NAME);
    }
    
    
    
    public function setToken($authToken, $expire){
        if($this->isTokenExist()){
            $this->updateToken($authToken, $expire);
        }else{
            $this->addToken($authToken, $expire);
        }
    }
    
    
    public function isTokenExist():bool{
        $out = FALSE;
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this->columns[1]["name"].") AS numb FROM ".$this::TABLE_NAME.";
                ");
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] > 0;
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function addToken($authToken, $expire){
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(?, ?);
                ");
        $query->bindValue(1, $authToken, \PDO::PARAM_STR);
        $query->bindValue(2, $expire, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function updateToken($authToken, $expire):bool{
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this->columns[0]["name"]." = ?, ".$this->columns[1]["name"].";
                ");
        $query->bindValue(1, $authToken, \PDO::PARAM_STR);
        $query->bindValue(2, $expire, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getToken():string{
        $out = "";
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"]." FROM ".$this::TABLE_NAME.";
                ");
        
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data[$this->columns[0]["name"]];
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getTokenExpireAt():int{
        $out = 0;
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[1]["name"]." FROM ".$this::TABLE_NAME.";
                ");
        
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data[$this->columns[1]["name"]];
            }
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    
    public function isTokenExpire():bool{
        return ($this->getTokenExpireAt() <= \time());
    }
}
