<?php

define("CATEGORY", "Category");
define("LOCATION", "Location");
define("ADS", "Ads");
define("NAME", "Name");
define("ADD", "Add");
define("SUBMIT", "Submit");
define("UNABLE_PAGE", "You can not access this page");
