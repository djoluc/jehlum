<?php $title = "Page d'accueil";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/main.css" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/general.css" media="all" />
        <script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/main.js"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/register.js"></script>
        
        <style>
.buttonload {
    background-color: #4CAF50; /* Green background */
    border: none; /* Remove borders */
    color: white; /* White text */
    padding: 12px 24px; /* Some padding */
    font-size: 16px; /* Set a font-size */
}

/* Add a right margin to each icon */
.fa {
    margin-left: -12px;
    margin-right: 8px;
}
</style>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?php require_once 'Header/header.php'; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        
        <div id="left_menu_content" style="width: 0px;">
            <ul>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                <li>Ajouter du contenu</li>
                
            </ul>
        </div>
        <div id="main_page_image_div">
            <div class="main_top_contener">
                
                <div class="inscript_div">
                    
                    <form id="register_form">
                        <select name="user_type">
                            <option value="1">UTILISATEUR</option>
                            <option value="2">ARTISAN</option>
                        </select>
                        <label>
                            <input type="text" placeholder="email" name="email" value="" required/>
                            <p class="email_info">
                                <i class="fa fa-warning "></i>Saisissez dans ce champs votre adresse email.(Obligatoire)
                            </p>
                        </label>
                        <label>
                            <input type="password" placeholder="mot de passe" name="password" reduired/>
                            <p class="pass_info">
                                 <i class="fa fa-warning "></i>Saisissez dans ce champs votre nouveau mot de passe.(Obligatoire)
                            </p>
                        </label>
                        <label>
                            <input type="password" placeholder="mot de passe" name="password_conf" required/>
                            <p class="pass_conf_info">
                                <i class="fa fa-warning "></i>Saisissez encore votre nouveau mot de passe pour confirmation.(Obligatoire)
                            </p>
                        </label>
                        <button type="submit">S'INSCRIRE</button>
                    </form>
                    <p>Vous soullez aller plus vite? Utilisez les réseaux sociaux:</p>
                    <div class="social_inscript_buttons">
                        <button class="inscript_fb_button">Facebook</button>
                        <button class="inscript_google_button">Google</button>
                    </div>
                </div>
            </div>
        </div>
<button class="buttonload">
  <i class="fa fa-spinner fa-spin "></i>Loading
</button>

<button style="width: auto; background: cadetblue;" class="buttonload">
  <i class="fa fa-warning "></i>Loading
</button>

<button style="width: auto; background: cadetblue;" class="buttonload">
  <i class="fa fa-bars "></i>Loading
</button>

<button style="width: auto; background: cadetblue;" class="buttonload">
  <i class="fa fa-sign-in "></i>Loading
</button>

<button class="buttonload">
  <i class="fa fa-circle-o-notch fa-spin"></i>Loading
</button>

<button class="buttonload">
  <i class="fa fa-refresh fa-spin"></i>Loading
</button>
<div id="gmap" style="width: 100%; min-height: 500px; border: 1px solid cyan;">
    
</div>
        <?= $salut; ?>
    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        foot
        <button class="w3-button w3-display-left w3-black" onclick="plusDivs(-1)">&#10094;</button>
        <button class="w3-button w3-display-right w3-black" onclick="plusDivs(1)">&#10095;</button>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>