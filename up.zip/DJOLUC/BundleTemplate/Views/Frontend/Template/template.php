<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html" lang="auto" charset="UTF-8"/>
		<?= $head_include; ?>
		<title><?= $title ?></title>
	</head>
        
        <header>
            <?= $header ?>
        </header>
	
    <body>
        
        <?= $body_content; ?>
            
    </body>
	<footer>
		<input type="hidden" id="ajaxFeedback" name="ajaxFeedback" value="0" />
                <?= $footer ?>
	</footer>
</html>