<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html" lang="auto" charset="UTF-8"/>
		<?= $head_include; ?>
		<title><?= $title ?></title>
	</head>
	
    <body>
        
        <?= $body_content; ?>

    </body>
	
</html>