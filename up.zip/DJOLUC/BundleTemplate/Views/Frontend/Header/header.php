<div id="top_bar">
            <span class="logo">
                    ARTISAN D'ICI
            </span>
            <form>
                <select>
                    <option>Par pays</option>
                    <option>Par métier</option>
                </select>
                <input type="text" placeholder="recherche..."/>
                <button type="submit">RECHERCHE</button>
            </form>
        </div>
        <div class="admin_bar">
            <ul id="admin_menu">
                <li>Home</li>
                <li>Article</li>
                <li>Gestion des utilisateurs</li>
                <li></li>
            </ul>
        </div>
        <div id="menu_bar_contener">
            <div class="menu_bar">
                <ul id="right_menu">
                    <li>AUTRE</li>
                    <li>CONEXION</li>
                    <li class="current">INSCRIPTION</li>
                </ul>
            <button class="left_menu_button"></button>
        </div>
</div>

