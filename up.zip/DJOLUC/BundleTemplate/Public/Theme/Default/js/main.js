var menuBar = null;

$(document).ready(function(){
    //alert();
    /*$.post("?", 
            {}, 
            function(result){
                alert(result);
                /*var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
                        
                if(rep.result){
                    iconDiv.setAttribute("link", rep.link);
                }else{
                    document.querySelector("#link_ul").removeChild(liElement);
                    fileSimulator.showError(rep.message);
                }
            });*/
    
    var menu_bar_offsetTop = document.querySelector("#menu_bar_contener").offsetTop;
    if(window.pageYOffset > menu_bar_offsetTop){
        document.querySelector("#menu_bar_contener").setAttribute("style", "position: fixed; top: 0px;");
    }else{
        document.querySelector("#menu_bar_contener").setAttribute("style", " ");
    }
    $(window).scroll(function(e){
        if(window.pageYOffset > menu_bar_offsetTop){
            document.querySelector("#menu_bar_contener").setAttribute("style", "position: fixed; top: 0px;");
        }else{
            document.querySelector("#menu_bar_contener").setAttribute("style", " ");
        }
    });
    
});



/*function openFullscreen() {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.mozRequestFullScreen) { /* Firefox 
    elem.mozRequestFullScreen();
  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari & Opera 
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE/Edge 
    elem.msRequestFullscreen();
  }
}*/
