<?php

define("UNABLE_ACTION", "You can access this option");
define("UNABLE_PAGE", "You can not access the page you requested");
define("PROFILE_PICTURE", "Profile picture");
define("SEND", "Send");
define("COMPLETE", "Complete");
define("CHOOSE", "Choose");
define("LAST_NAME", "Last name");
define("FIRST_NAME", "First name");
define("BIRTHDAY", "Birthday");
define("PLACE_OF_BIRTH", "Place of birth");
define("GENDER", "Gender");
define("PHONE", "Phone");
define("PROFESSION", "Profession");
define('COUNTRY', "Country");
define("TOWN", "Town");
define("DISTRICT", "District");
define("MAN", "Man");
define("WOMAN", "Woman");
define("PROFILE", "Profile");
define("EDIT", "Edit");
define("PASSWORD", "Password");
define("NEWW", "New");
define("CONFIRME", "Confirme");
define("OLD", "Old");
define("CURRENT", "Current");
define("LOGIN", "Login");
define("SIGNE_UP", "Signe up");

