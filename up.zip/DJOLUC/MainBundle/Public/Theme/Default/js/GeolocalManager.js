

function GeolocalManager(){
    
}