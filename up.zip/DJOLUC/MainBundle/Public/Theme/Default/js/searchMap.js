var searchMap = null;


function SearchMap(contener_id){
    this.geolocalManager = new GeolocalManager();
    this.ateliers = JSON.parse($(".search_user_locations").text());
    this.map = null;
    var thisClass = this;
    
    
    this.geolocalManager.locate(function(lat, long){
        thisClass.map = L.map(contener_id, {
            center: [lat, long],//latitude, longitude
            zoom: 10
        });
    
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(thisClass.map);
        
        for(var i = 0; i < thisClass.ateliers.length; i++){
            thisClass.addPositionPointerAndPopup("Artisan", thisClass.ateliers[i].lat, thisClass.ateliers[i].long);
        }
        
        //thisClass.addAteliersLocation();
     });
}


SearchMap.prototype.addPositionPointerAndPopup = function(popupMessage, lat, long){
    L.marker([lat, long]).addTo(searchMap.map)
        .bindPopup(popupMessage)
        .openPopup();
};