var menuBar = null;
var searchBar = null;

$(document).ready(function(){
    registerUserLocation();
    autoLoad();
    /*if($("#searchForm").length){
        searchBar = new SearchBar(function(text){
        if(text !== ""){
            loadSearchProposition(text);
        }else{
            searchBar.clearAutoComplete();
        }
     }, 
    function(text){
        $("#searchForm").submit();
        }, 
        false);
    }*/
    
    //searchBar.fillAutoComplete(["ok", "test", "ok"]);
    
    if($("#menu_bar_contener > .menu_bar > .menu_top_ul > .menu > button.bars").css("display") == "inline-block"){
        $("#menu_bar_contener > .menu_bar > .menu_top_ul > .menu > ul").css("display", "none");
        $("#menu_bar_contener > .menu_bar > .menu_top_ul > .menu > button.bars").click(function(e){
            e.preventDefault();
            if($("#menu_bar_contener > .menu_bar > .menu_top_ul > .menu > ul").css("display") == "block")
                $("#menu_bar_contener > .menu_bar > .menu_top_ul > .menu > ul").css("display", "none");
            else
                $("#menu_bar_contener > .menu_bar > .menu_top_ul > .menu > ul").css("display", "block");
        });
    }
    
    
    if($(".mobile-search").length && $(".mobile-search").css("display") == "inline-block"){
        $(".search_form_div").attr("style", "display: none;");
        $(".mobile-search").click(function(e){
            e.preventDefault();
            if($(".search_form_div").attr("style") == "display: block;"){
                $(".search_form_div").attr("style", "display: none;")
            }else{
                $(".search_form_div").attr("style", "display: block;")
            }
        });
    }
    
    if(!$(".search_form_div").length){
        $(".mobile-search").attr("style", "display: none; background: transparent; border: 1px solid rgba(0, 0, 0, 0.1); border-radius: 10px; color: rgba(0, 0, 0, 0.4);");
    }
    
    
    
    
    textareaJob();
    
    
    offset();
});



/*function openFullscreen() {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.mozRequestFullScreen) { /* Firefox 
    elem.mozRequestFullScreen();
  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari & Opera 
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE/Edge 
    elem.msRequestFullscreen();
  }
}*/


function offset(){  
    var menu_bar_offsetTop = document.querySelector("#menu_bar_contener > .menu_bar").offsetTop;
    var afterMenuExist = !(document.querySelector(".header_after_menu") === null);
    //var gallery_picture_offsetTop = null;
    //var artisan_contener_offset = null;
    if(window.pageYOffset > menu_bar_offsetTop){
        
        document.querySelector("#menu_bar_contener > .menu_bar").setAttribute("style", "position: fixed; top: 0px; background: #ffffff; color: #000000; box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);");
        if(afterMenuExist)
            document.querySelector(".header_after_menu").setAttribute("style", "margin-top: 60px;");
        //$("#left_menu_content > ul").css("top", "60px");
    }else{
        document.querySelector("#menu_bar_contener > .menu_bar").setAttribute("style", " ");
        if(afterMenuExist)
            document.querySelector(".header_after_menu").setAttribute("style", "");
        //$("#left_menu_content > ul").css("top", "150px");
    }
    
    $(window).scroll(function(e){
        if(window.pageYOffset > menu_bar_offsetTop){
            document.querySelector("#menu_bar_contener > .menu_bar").setAttribute("style", "position: fixed; top: 0px; background: #ffffff; color: #000000;box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);");
            if(afterMenuExist)
                document.querySelector(".header_after_menu").setAttribute("style", "margin-top: 60px;");
            //$("#left_menu_content > ul").css("top", "60px");
        }else{
            document.querySelector("#menu_bar_contener > .menu_bar").setAttribute("style", " ");
            if(afterMenuExist)
                document.querySelector(".header_after_menu").setAttribute("style", "");
            //$("#left_menu_content > ul").css("top", "150px");
        }
        
         /*if($(".right_box").length){
             if(window.pageYOffset > artisan_contener_offset-600){
                document.querySelector(".right_box").setAttribute("style", "");
            }else if(window.pageYOffset > gallery_picture_offsetTop){
                document.querySelector(".right_box").setAttribute("style", "position: fixed; top: 70px; right: 0px;");
            //document.querySelector(".right_box").offsetTop = window.pageYOffset;
            }else{
                document.querySelector(".right_box").setAttribute("style", "");
            }
         }*/
        
    });
    
    /*if($(".right_box").length){
        gallery_picture_offsetTop = document.querySelector(".right_box").offsetTop;
        artisan_contener_offset = document.querySelector("#artisan_contener").offsetTop;
    
        if(window.pageYOffset > artisan_contener_offset-600){
            document.querySelector(".right_box").setAttribute("style", "");
        }else if(window.pageYOffset > gallery_picture_offsetTop){
            document.querySelector(".right_box").setAttribute("style", "position: fixed; top: 0px;");
        }else{
            document.querySelector(".right_box").setAttribute("style", "");
        }
    }*/
    
}


function loadSearchProposition(text){
    $.post("?a=mainSearch&proposition", 
        {txt: text, sent: ""}, 
        function(result){
            //alert(result);
            var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
            
            searchBar.fillAutoComplete(rep.propo);
            
        });
}


function registerUserLocation(){
    if(typeof GeolocalManager === "function"){
        var geolocalManager = new GeolocalManager();
        //alert(typeof GeolocalManager );
        geolocalManager.locate(function(lat, long){
            $.post("?a=userLocation&add", 
            {sent: "", longitude: long, latitude: lat, altitude: 0, country:"", town: "", district: "", means: 2}, 
            function(result){
            //alert(result);
            });
        });
    }
        
}



function textareaJob(){
    HTMLTextAreaElement.prototype.getCaretPosition = function () { //return the caret position of the textarea
        return this.selectionStart;
    };
    HTMLTextAreaElement.prototype.setCaretPosition = function (position) { //change the caret position of the textarea
        this.selectionStart = position;
        this.selectionEnd = position;
        this.focus();
    };
    HTMLTextAreaElement.prototype.hasSelection = function () { //if the textarea has selection then return true
        if (this.selectionStart == this.selectionEnd) {
            return false;
        } else {
            return true;
        }
    };
    HTMLTextAreaElement.prototype.getSelectedText = function () { //return the selection text
        return this.value.substring(this.selectionStart, this.selectionEnd);
    };
    HTMLTextAreaElement.prototype.setSelection = function (start, end) { //change the selection area of the textarea
        this.selectionStart = start;
        this.selectionEnd = end;
        this.focus();
    };

    if(document.getElementsByTagName('textarea').length){
    var textarea = document.getElementsByTagName('textarea')[0]; 
   
    textarea.onkeydown = function(event) {
    
        //support tab on textarea
        if (event.keyCode == 9) { //tab was pressed
            var newCaretPosition;
            newCaretPosition = textarea.getCaretPosition() + "    ".length;
            textarea.value = textarea.value.substring(0, textarea.getCaretPosition()) + "    " + textarea.value.substring(textarea.getCaretPosition(), textarea.value.length);
            textarea.setCaretPosition(newCaretPosition);
            return false;
        }
        if(event.keyCode == 8){ //backspace
            if (textarea.value.substring(textarea.getCaretPosition() - 4, textarea.getCaretPosition()) == "    ") { //it's a tab space
                var newCaretPosition;
                newCaretPosition = textarea.getCaretPosition() - 3;
                textarea.value = textarea.value.substring(0, textarea.getCaretPosition() - 3) + textarea.value.substring(textarea.getCaretPosition(), textarea.value.length);
                textarea.setCaretPosition(newCaretPosition);
            }
        }
        if(event.keyCode == 37){ //left arrow
            var newCaretPosition;
            if (textarea.value.substring(textarea.getCaretPosition() - 4, textarea.getCaretPosition()) == "    ") { //it's a tab space
                newCaretPosition = textarea.getCaretPosition() - 3;
                textarea.setCaretPosition(newCaretPosition);
            }    
        }
        if(event.keyCode == 39){ //right arrow
            var newCaretPosition;
            if (textarea.value.substring(textarea.getCaretPosition() + 4, textarea.getCaretPosition()) == "    ") { //it's a tab space
                newCaretPosition = textarea.getCaretPosition() + 3;
                textarea.setCaretPosition(newCaretPosition);
            }
        } 
    };
    }
}



function autoLoad(){
        $.ajax({
            method: 'POST',
            enctype: 'multipart/form-data',
            url: "/",
            data: {},
            processData: false,
            contentType: false,
            timeout: 60000
        }).done(function(result){ 
            window.setTimeout(function(){
                autoLoad();
                window.clearTimeout(this);
            }, 10000);
        }).fail(function(){
            window.setTimeout(function(){
                autoLoad();
                window.clearTimeout(this);
            }, 10000);
        });
    }
