var searchBar = null
$(document).ready(function(){
    searchBar = new SearchBar(function(text){
        loadPropos($(".header_after_menu form > select[name='location']").val(), text);
    }, 
    function(text){
        //alert(text);
        
    }, false);
});



function loadPropos(locId, sh){
    $.post("/search/loadAdPropos",
        {locationId: locId, search: sh}, 
        function(result){
            //alert(result);
            var rep = JSON.parse(result);
            
            searchBar.fillAutoComplete(rep);
            
        });
}