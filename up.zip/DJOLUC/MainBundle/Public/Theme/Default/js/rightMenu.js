/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var isOpen = false;

function open(){
    //alert(document.getElementById("right_menu"));
    document.getElementById("right_menu").getElementsByTagName("ul")[0].style = "left: auto; min-height: 0;";
    
    var top = document.getElementById("top");
    var moddle = document.getElementById("middle");
    var bottom = document.getElementById("bottom");
    top.style.display = "none";
    middle.style.width = "10px";
    middle.style.height = "10px";
    bottom.style.display = "none";
}

function close(){
    document.getElementById("right_menu").getElementsByTagName("ul")[0].style.left = "-999em";
    
    var top = document.getElementById("top");
    var moddle = document.getElementById("middle");
    var bottom = document.getElementById("bottom");
    top.style.display = "block";
    middle.style.width = "5px";
    middle.style.height = "5px";
    bottom.style.display = "block";
}

function menuClick(){
    //alert();
    if(isOpen){
        close();
        isOpen = false;
    }else{
        open();
        isOpen = true;
    }
}


