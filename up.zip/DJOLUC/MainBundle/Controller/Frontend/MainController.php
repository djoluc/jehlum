<?php

namespace DJOLUC\MainBundle\Controller\Frontend;

require_once 'DJOLUC/RegisterBundle/Controller/Frontend/LoginController.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'App/Controller/BaseController.php';

use DJOLUC\RegisterBundle\Controller\Frontend;
use DJOLUC\RegisterBundle\Model;

/*use Twig\Node\Expression\NameExpression;

use Twig\Loader\FilesystemLoader;*/


//require_once 'vendor/autoload.php';

//require_once 'vendor/twig/twig/src/Environment.php';
//require_once 'vendor/twig/twig/lib/Twig/Loader/Filesystem.php';

/**
 * Description of MainController
 *
 * @author djoluc
 */
class MainController extends \App\Controller\BaseController{
    private $sessionManageController, 
            $userDataSource,
            $artisanUserDataSource, 
            $productDataSource, 
            $pageDataSource, 
            $pageGalleryPictureDataSource, 
            $newProducNumb, 
            $newProductFirst, 
            $newGPictureNumb, 
            $newGPictureFirst, 
            $search;
    public function __construct() {
        $this->sessionManageController = new Frontend\SessionManageController();
        $this->userDataSource = new Model\Frontend\UserDataSource();
        $this->newProducNumb = array_key_exists("newProductNumb", $_GET)?(int)filter_input(INPUT_GET, "newProductNumb"):30;
        $this->newProductFirst = array_key_exists("newProductFirst", $_GET)?(int)filter_input(INPUT_GET, "newProductFirst"):0;
        $this->newGPictureNumb =  array_key_exists("newGPictureNumb", $_GET)?(int)filter_input(INPUT_GET, "newGPictureNumb"):30;
        $this->newGPictureFirst = array_key_exists("newGPictureFirst", $_GET)?(int)filter_input(INPUT_GET, "newGPictureFirst"):0;
        $this->search = array_key_exists("search", $_GET)?filter_input(INPUT_GET, "search"):"";
    }
    
    
    
    public static function populateMainHeader($displaySearchBar = false, $searchData = "", $searchValue = "", $lang = "", $pageTitle = "Home", $displayAfterMenu = false){
        
        require_once 'DJOLUC/RegisterBundle/Controller/Frontend/LoginController.php';
        require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
        require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
        
        
        $authenticationMenu = Frontend\LoginController::populateAuthenticationMenu();
        
        $leftMenu = MainController::populateLeftMenu();
        
        
        $rightMenu = MainController::populateRightSmallMenu();
        
        
        
        $userId = 0;
        $isAdminUser = FALSE;
        $isAdm = false;
        $userNumb = 0;
        
        $mainConroller = new MainController();
        
        if(isset($_SESSION[Frontend\SessionManageController::SESSION_USER_ID])){
            $userId = $_SESSION[Frontend\SessionManageController::SESSION_USER_ID];
            $userNumb = $mainConroller->userDataSource->getUserNumb($userId);
            $userRang = $mainConroller->userDataSource->getUser($userId)->getUserRang();
            if($userRang > Model\Frontend\UserDataSource::SIMPLE_RANG){
                $isAdminUser = TRUE;
            }
            
            if($userRang == Model\Frontend\UserDataSource::ADM_RANG){
                $isAdm = TRUE;
            }
        }
        
        $adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $adsCategoryDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsCategoryDataSource();
        $adsLocationDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsLocationDataSource();
        
        
        return $mainConroller->renderView([ 
            "authMenu"=>$authenticationMenu,
            "leftMenu"=>$leftMenu,
            "rightMenu"=>$rightMenu,
            "isAdminUser"=>$isAdminUser,
            "isAdm"=>$isAdm,
            "userNumb"=>$userNumb, 
            "userId"=>$userId, 
            "displaySearchBar"=>$displaySearchBar, 
            "searchData"=>$searchData, 
            "searchValue"=>$searchValue, 
            "pageTitle" => $pageTitle,
            "pendingAdsNumb" => $adsDataSource->getPendingAdsNumb(), 
            "categoryNumb" => $adsCategoryDataSource->getCategoryNumb(), 
            "locationNumb" => $adsLocationDataSource->getLocationNumb(), 
            "displayAfterMenuArea" => $displayAfterMenu, 
            "locationAsOptions" => $adsLocationDataSource->getAllLocationAsHtmlOptions()
        ], 
                'DJOLUC/MainBundle/Views/Frontend/Header/header.php');
    }
    
    
    public static function populateFooter($lang = ""){
        $mainConroller = new MainController();
        
        return $mainConroller->renderView([ 
            
        ], 
                'DJOLUC/MainBundle/Views/Frontend/Footer/footer.php');
    }


    public function displayPageAction() {
        parent::displayPageAction();
        
        $salut = "Salut tout le monde ".filter_input(INPUT_SERVER, "DOCUMENT_ROOT");
        
        /*$authenticationMenu = Frontend\LoginController::populateAuthenticationMenu();
        
        $leftMenu = MainController::populateLeftMenu();
        
        $shoppingCardMenu = \DJOLUC\ProductBundle\Controller\Frontend\MainController::populateShoppingCardMenu();*/
        
        
        $userId = 0;
        $isAdminUser = FALSE;
        $isAdm = false;
        $userNumb = 0;
        $userQuartier = "";
        
        
        if(isset($_SESSION[Frontend\SessionManageController::SESSION_USER_ID])){
            $userId = $_SESSION[Frontend\SessionManageController::SESSION_USER_ID];
            $userNumb = $this->userDataSource->getUserNumb($userId);
            $userRang = $this->userDataSource->getUser($userId)->getUserRang();
            $userQuartier = $this->userDataSource->getUser($userId)->getUserQuartier();
            if($userRang > Model\Frontend\UserDataSource::SIMPLE_RANG){
                $isAdminUser = TRUE;
            }
            
            if($userRang == Model\Frontend\UserDataSource::ADM_RANG){
                $isAdm = TRUE;
            }
        }
        
        $adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        
        
        return $this->renderView([
            "isAdminUser"=>$isAdminUser,
            "isAdm"=>$isAdm,
            "userNumb"=>$userNumb, 
            "userId"=>$userId, 
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", "", "", "Jehlum", true), 
            "footer"=> MainController::populateFooter(),
            "artisanUsersWithBetterNote"=>COUNT($this->userDataSource->getArtisanUsersWithBetterNote(50, 0))!=0?$this->userDataSource->getArtisanUsersWithBetterNote(50, 0):$this->userDataSource->getArtisanUsers(50, 0), 
            "actifArtisans"=>$this->userDataSource->getActifArtisans(20, 0), 
            "isEmptyApp"=>($this->userDataSource->getUserNumb(0)<=1),
            "search"=>$this->search, 
            "searchUsers"=>!empty($this->search)?$this->userDataSource->getSearchUsers($userId, 10, $this->search, "artisan"):Array(), 
            "searchUsersWithQuartier"=>!empty($this->search)?$this->userDataSource->getSearchUsersWithQuartier($userId, 10, $this->search, "artisan", $userQuartier):Array(), 
            "userQuartier"=>$userQuartier, 
            "latestAds" => $adsDataSource->getActivatedAds("", 0, 12), 
            "allAdsNumb" => $adsDataSource->getAllActivateAdsNumb()
        ], 
                'DJOLUC/MainBundle/Views/Frontend/mainView.php');
    }

    public static function rooter($lang = "") {
        parent::rooter();
        
        $mainController = new MainController();
        
        print $mainController->displayPageAction();
    }
    
    public static function populateLeftMenu(){
        
        $mainController = new MainController();
        $userDataSource = new Model\Frontend\UserDataSource();
        $userId = Model\Frontend\UserDataSource::getCurrentUserId();
        return $mainController->renderView([
            "userId"=>$userId, 
            "user"=>$userDataSource->getUser($userId)
        ], 'DJOLUC/MainBundle/Views/Frontend/Menu/leftMenu.php');
    }
    
    
    public static function populateRightSmallMenu(){
        $mainController = new MainController();
        $userDataSource = new Model\Frontend\UserDataSource();
        $userId = Model\Frontend\UserDataSource::getCurrentUserId();
        return $mainController->renderView([
            "userId"=>$userId, 
            "user"=>$userDataSource->getUser($userId),
        ], 'DJOLUC/MainBundle/Views/Menu/rightMenu.php');
    }
}
