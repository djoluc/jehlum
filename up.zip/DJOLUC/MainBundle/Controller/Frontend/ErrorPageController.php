<?php

namespace DJOLUC\MainBundle\Controller\Frontend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';

/**
 * Description of ErrorPageController
 *
 * @author djoluc
 */
class ErrorPageController extends \App\Controller\BaseController{
    
    
    
    
    public function displayPageAction($message = "") {
        parent::displayPageAction();
        
        
        return $this->renderView([
            "header"=> MainController::populateMainHeader(), 
            "footer"=> MainController::populateFooter(), 
            "message"=>$message
        ], 
                "DJOLUC/MainBundle/Views/Frontend/errorPageView.php");
    }

    public static function rooter($message = "", $code = "") {
        parent::rooter();
        
        
        $thisClass = new ErrorPageController();
        
        print $thisClass->displayPageAction($message);
    }

}
