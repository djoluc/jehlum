<?php

namespace DJOLUC\MainBundle\Controller\Frontend;

/**
 * Description of PrivacyController
 *
 * @author djoluc
 */
class PrivacyController extends \App\Controller\BaseController {
    private $userDataSource, 
            $userId;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
    }
    
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
        
        return $this->renderView([
            "header" => MainController::populateMainHeader(), 
            "footer" => MainController::populateFooter()
        ], 
                "DJOLUC/MainBundle/Views/Frontend/privacyView.php");
    }

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }
}
