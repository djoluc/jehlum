<?php

namespace DJOLUC\MainBundle\Controller\Frontend;
/**
 * Description of SearchController
 *
 * @author djoluc
 */
class SearchController extends \App\Controller\BaseController {
    private $sessionManageController, 
            $userDataSource,
            $adsDataSource,
            $userId, 
            $keyword;
    
    public function __construct() {
        $this->sessionManageController = new \DJOLUC\RegisterBundle\Controller\Frontend\SessionManageController();
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->adsDataSource = new \DJOLUC\AdsBundle\Model\Frontend\AdsDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->keyword = array_key_exists("search", $_GET)?filter_input(INPUT_GET, "search"):"";
    }
    
    public function loadAdProposAction(){
        $locationId = $this->getPostInt("locationId");
        $search = $this->getPostString("search");
        
        return $this->printPureJson($this->adsDataSource->getSearchedAdProposition($locationId, $search, 0, 10));
    }
    
    
    public function displayPageAction() {
        
        $locationId = $this->getGetInt("location");
        $search = $this->getGetString("search");
        
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", "", "", "Jehlum", true), 
            "footer"=> MainController::populateFooter(),
            "adsNumb" => $this->adsDataSource->getSearchedAdNumb($locationId, $search), 
            "ads" => $this->adsDataSource->getSearchedAds($locationId, $search, 0, 20)
        ], 
                'DJOLUC/MainBundle/Views/Frontend/searchView.php');
    }
    
    

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("", $thisObject);
        $thisObject->addPage("loadAdPropos", $thisObject, FALSE);
        
        $thisObject->rooting($cacheDir);
    }
}
