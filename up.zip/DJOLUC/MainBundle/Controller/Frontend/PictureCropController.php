<?php

namespace DJOLUC\MainBundle\Controller\Frontend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/ProfilPictureDataSource.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';

/**
 * Description of PictureCropController
 *
 * @author djoluc
 */
class PictureCropController extends \App\Controller\BaseController {
    private $userDataSource, 
            $picCreator, 
            $userId,
            $picDir, 
            $picName,
            $picLink,
            $miniDir,
            $backLink;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->picCreator = 0;
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->picDir = filter_input(INPUT_POST, "dir");
        $this->picName = filter_input(INPUT_POST, "name");
        //$this->picDir = "testCrop";
        //$this->picName = "1540030855.jpg";
        $this->picLink = $this->picDir."/".$this->picName;
        $this->miniDir = filter_input(INPUT_POST, "miniDir");
        $this->backLink = filter_input(INPUT_POST, "back");
        //$this->backLink = ".";
    }
    
    
    
    public function cropPicAction($dir, $file_name, $save, $ratio, $cropWidth, $cropHeight, $cropX, $cropY){
        if(!is_dir($save)) mkdir($save);
		// récupération de la taille de l'image
		if(is_file(''.$dir.'/'.$file_name)){
		    $pixel=getimagesize(''.$dir.'/'.$file_name);
			$width=$pixel[0];
			$height=$pixel[1];
			// echo $width;
			// jpeg
			if($pixel[2] == 2){
			    $new_image=imagecreatefromjpeg(''.$dir.'/'.$file_name);
                            $im=imagecreatetruecolor($ratio, $ratio);
                            imagecopyresampled($im,$new_image,0,0,$cropX,$cropY,$ratio,$ratio,$cropWidth,$cropHeight);
				
                           
				imagejpeg($im,$save.'/crop_'.$file_name);	
                                
                                
                                
			}else if($pixel[2] == 3){//png
                            $new_image=imagecreatefrompng(''.$dir.'/'.$file_name);
                            $im=imagecreatetruecolor($ratio, $ratio);
                            imagecopyresampled($im,$new_image,0,0,$cropX,$cropY,$ratio,$ratio,$cropWidth,$cropHeight);
				
                            imagepng($im,$save.'/crop_'.$file_name);	
                                
                                
                                
			}else if($pixel[2] == 1){// gif
			    $new_image= imagecreatefromgif(''.$dir.'/'.$file_name);
                            $im=imagecreatetruecolor($ratio, $ratio);
                            imagecopyresampled($im,$new_image,0,0,$cropX,$cropY,$ratio,$ratio,$cropWidth,$cropHeight);
				
                            imagegif($im,$save.'/crop_'.$file_name);	
                                
                                
                                
			}	
		}
    }
    
    
    public function cropingAction(){
        
        
        $this->cropPicAction($this->picDir, $this->picName, $this->picDir, 200, filter_input(INPUT_POST, "w"), filter_input(INPUT_POST, "h"), filter_input(INPUT_POST, "x"), filter_input(INPUT_POST, "y"));
        
        $userProfilPicDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ProfilPictureDataSource();
        $userProfilPicDataSource->addUserProfilPicture($this->userId, "crop_".$this->picName);
        
        
        if(!empty($this->miniDir)){
            require_once 'DJOLUC/Helper/fonct.php';
            
            miniature($this->picDir, 150, $this->miniDir, "crop_".$this->picName);
        }
        
        header("Location: ".$this->backLink."");
    }
    
    
    
    public function displayPageAction() {
        parent::displayPageAction();
        
        
         return $this->renderView([
            "userId"=>$this->userId, 
            "header"=> MainController::populateMainHeader(),
            "footer"=> MainController::populateFooter(),
            "picName"=>$this->picName, 
            "picDir"=>$this->picDir,
            "picLink"=>$this->picLink,
             "miniDir"=>$this->miniDir,
             "backLink"=>$this->backLink
        ], 
                'DJOLUC/MainBundle/Views/Frontend/pictureCropView.php');
    }
    
    

    public static function rooter() {
        parent::rooter();
        
        $thisClass = new PictureCropController();
        
        if(array_key_exists("crop", $_GET)){
            $thisClass->cropingAction();
        }else{
           print $thisClass->displayPageAction(); 
        }
    }
}
