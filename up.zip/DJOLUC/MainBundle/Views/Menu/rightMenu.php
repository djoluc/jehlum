<ul id="right_m_menu">
            <li>
                <div onclick="menuClick();">
                    <a class="top"></a>
                    <a class="middle"></a>
                    <a class="bottom"></a>
                </div>
                <ul>
        <?php if($data["userId"] > 0): ?>
        
        <?php endif; ?>
                    
        <?php if($data["userId"] <= 0): ?>
            <a href="."><li>
                    <i class="fa fa-home"></i>
                </li></a>
            <a href="?a=authenticate"><li>
                    <i class="fa fa-sign-in-alt"></i>
                </li></a>
            <a href="?a=register"><li>
                    <i class="fa fa-user-plus"></i>
            </li></a>
            
        <?php endif; ?>
            <a href="?a=userFavArtisan">
                <li>
                    <i class="fa fa-star"></i>
                </li>
            </a>
            <a href="?a=shoppingCartContent"><li>
                    <i class="fa fa-shopping-cart"><b style="font-size: 10px; color: #ffffff;" id="shopping_cart_content_numb"><?= $data["sCartContentNumb"]; ?></b></i>
            </li></a>
                </ul>
            </li>
</ul>
