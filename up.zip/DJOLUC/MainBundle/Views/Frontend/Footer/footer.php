<div id="footer_div">
    <div class="content">
        <div class="item">
            <span>Social media</span>
            <ul class="point">
                <li>Connect with us :</li>
                <li>
                    <a target="_blank" href="http://facebook.com/Jehlumjk"><button class="round_button"><i class="fab fa-facebook-f"></i></button></a> &nbsp;&nbsp;
                    <a target="_blank" href="http://instagram.com/Jehlumjk"><button class="round_button"><i class="fab fa-instagram"></i></button></a> &nbsp;&nbsp;
                    <a target="_blank" href="https://www.linkedin.com/company/jehlum"><button class="round_button"><i class="fab fa-linkedin"></i></button></a> &nbsp;&nbsp;
                    <a target="_blank" href="<?= SITE_URL ?>/pendingAdsRssFeed"><button class="round_button"><i class="fa fa-rss"></i></button></a>
                </li>
            </ul>
        </div>
        
        <div class="item">
            <span>Quick lnk</span>
            <ul class="point">
                <li><a target="_blank" href="/about" style="color: rgba(255, 255, 255, 0.7);">About us</a></li>
                <li><a target="_blank" href="/faq" style="color: rgba(255, 255, 255, 0.7);">FAQ</a></li>
            </ul>
        </div>
        
        <div class="item">
            <span>&nbsp;</span>
            <ul class="point">
                <li><a target="_blank" href="/terms" style="color: rgba(255, 255, 255, 0.7);">Terms and conditions</a></li>
                <li><a target="_blank" href="/privacy" style="color: rgba(255, 255, 255, 0.7);">Privacy policy</a></li>
            </ul>
        </div>
        
        <div class="item">
            <span>Contact us:</span>
            <ul class="point">
                <li><i class="fa fa-mars"></i> &nbsp; <a href="mailto:info@jehlum.org" style="color: #ffffff;"> info@jehlum.org</a></li>
                <li><i class="fa fa-mars"></i> &nbsp; <a href="mailto:info@jehlum.org" style="color: #ffffff;"> support@jehlum.org</a></li>
            </ul>
        </div>
    </div>
    <div class="bottom_bar">
        Copyright© 2019 Jehlum
    </div>
</div>