<?php $title = "Page d'accueil";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="/App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="/DJOLUC/MainBundle/Public/Theme/Default/css/general.css" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="/DJOLUC/MainBundle/Public/Theme/Default/css/main.css" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="/DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="/DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css" media="all" />
         <link rel="stylesheet" title="Design" type="text/css" href="/DJOLUC/MainBundle/Public/Theme/Default/css/horizontalScrollView.css" media="all" />
         <link rel="stylesheet" title="Design" type="text/css" href="/DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="/DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="/DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="/DJOLUC/MainBundle/Public/Theme/Default/js/main.js"></script>
        <script type="text/javascript" src="/DJOLUC/MainBundle/Public/Theme/Default/js/register.js"></script>
        <!--<script type="text/javascript" src="DJOLUC/PaymentBundle/Public/Theme/Default/js/MtnMobileMoney.js"></script>-->
        
        <style>
.buttonload {
    background-color: #4CAF50; /* Green background */
    border: none; /* Remove borders */
    color: white; /* White text */
    padding: 12px 24px; /* Some padding */
    font-size: 16px; /* Set a font-size */
}

/* Add a right margin to each icon */
/*.fa {
    margin-left: -12px;
    margin-right: 8px;
}*/
</style>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
<div id="page_div">
    <br/>
    <!--<h3 style="text-align: center;">Vous ếtes sur la page d'erreur de Artisan D'ici</h3>-->
    <br/><br/><br/><br/>
    <p style="text-align: center; font-size: 30px; margin-top: 150px;"><?= $data["message"]; ?></p>
    
</div>


    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>