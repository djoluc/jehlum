<?php $title = "Jehlum home";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT; ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/miniCard.css?version=1.0" media="all" />
        <!--<link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/main_actuality_box.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css?version=1.0" media="all" /
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/horizontalScrollView.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />-->
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
        <script src="http://www.openlayers.org/api/OpenLayers.js"></script>
        <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/RegisterBundle/Public/Theme/Default/js/searchBar.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/LocationBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/ProductBundle/Public/Theme/Default/js/ProductLike.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/ProductBundle/Public/Theme/Default/js/UserShoppingCart.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/searchMap.js?version=1.0"></script>
        <!--<script type="text/javascript" src="DJOLUC/PaymentBundle/Public/Theme/Default/js/MtnMobileMoney.js"></script>-->
        
        <style>
.buttonload {
    background-color: #4CAF50; /* Green background */
    border: none; /* Remove borders */
    color: white; /* White text */
    padding: 12px 24px; /* Some padding */
    font-size: 16px; /* Set a font-size */
}
</style>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>



<div id="page_div" style="color: #000000;">
    <div class="about_box" style="border-radius: 10px;">
        
        <button style=" display: block; font-style: italic; font-weight: bold; width: calc(100% - 20px); height: 100px; border-radius: 0px; margin: auto; font-size: 30px;">
            Terms & conditions
        </button>
        <ol style="list-style: none;">
            <li style="font-weight: bold;">
                Terms & conditions
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            Welcome to the Jehlum Website (“we” or “Jehlum”) own and operate this as proprietary  
                            to provide its users an online employment information service . The following is a legal 
                            agreement ("Agreement") between Jehlum and you. By accessing or using this Site you acknowledge
                            that you have read, understood, and agreed to be bound by this Agreement. Please read this 
                            Agreement carefully because the terms are binding upon you. If you are a regular user of this 
                            Site, please check this Agreement for updates. It governs your use of the Site and Service. 
                            We may also post additional terms and conditions that apply to specific Site areas. 
                            These area-specific terms and conditions are incorporated into the Agreement. We may change 
                            this Agreement at any time by posting the amended Agreement on the Site. Certain provisions 
                            of these Terms may be superseded by expressly designated legal notices or terms located on 
                            particular pages at this Site. Please read this Policy carefully and be aware that we may 
                            change it at any time. As a result, we suggest you check back regularly to this page to be 
                            apprised of any updates or changes. We last revised this Agreement on August 16 2017. You 
                            may print out from the Site two copies of pages of content from the Site for your own personal 
                            or business use, provided you do not publish, copy, or otherwise re-transmit what you have 
                            printed out from the Site – see Copyright below for full details. 
                        </p>
                    </li>
                </ul>
            </li><br><br>
            
            
            <li style="font-weight: bold;">
                Eligibility
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            This Site includes the online centralized job center for the Human Resources Consultant 
                            Companies that associate themselves with Jehlum and is not available to minors. It is 
                            intended for use only by adults. You must be at least 18 years of age and possess the 
                            legal authority to form legally binding contracts under applicable law to use the Services. 
                        </p>
                    </li>
                </ul>
            </li><br><br>
            
            
            <li style="font-weight: bold;">
                No Unlawful or Prohibited Use
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            You agree not to use the Services for any purpose that is unlawful or prohibited by this Agreement. You agree not to post or submit on this Site, any material that:<br><br>
                            * Infringes or may infringe on anyone else’s copyright, trade secret, trademark, or other intellectual property rights;<br>
                            * violates or may violate others’ privacy or publicity rights;<br>
                            * is obscene, defamatory, threatening, harassing, abusive, hateful, or embarrassing to another party;<br>
                            * impersonates another person; or<br>
                            * breaches any obligations of confidentiality or any other contractual obligation you may owe to any third parties. <br>
                        </p>
                        
                        <p>
                            You further agree not to submit any materials that contain viruses, Trojan horses, worms, 
                            time bombs, cancel bots, or other computer programming routines or engines that are intended 
                            to damage, detrimentally interfere with, surreptitiously intercept, or expropriate any system, 
                            data, or information. You may not try to gain unauthorized access to the Service, other 
                            accounts, computer systems or networks connected to the Service through hacking, password 
                            mining, or any other means. You agree that you will not use any robot, spider, other 
                            automatic device, or manual process to monitor or copy pages of this Site or the content 
                            contained on it without our express prior written permission.We may (but need not) monitor, 
                            edit, or remove any content from this Site that violates this Agreement.
                        </p>
                    </li>
                </ul>
            </li><br><br>
            
            
            
            <li style="font-weight: bold;">
                Disclaimer of Warranties
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            This site may contain inaccuracies or typographical errors. You agree that your use of the 
                            services is at your sole risk. We provide this site and the service “as is” and “as available” 
                            and without any warranty or condition, express, implied, or statutory, as to the operation 
                            of the services; the accuracy, reliability, completeness, or timeliness of the content or 
                            materials included on the site or this service; or otherwise. We specifically disclaim any 
                            implied warranties of title, merchantability, fitness for a particular purpose, or 
                            non-infringement.
                        </p>
                        <p>
                            We do not warrant:<br><br>
                            * that the service will be uninterrupted, timely, secure, or error-free,<br>
                            * the quality of any services, information, or other material obtained by you through the service, or<br>
                            * that any errors in the services will be corrected.<br>
                        </p>
                        
                        <p>
                            You agree that Jehlum shall not be responsible for unauthorized access to or alteration of 
                            your transmissions or data, any material or data sent or received or not sent or received, 
                            or any transactions entered into through this site.
                        </p>
                        
                        <p>
                             You agree that Jehlum is not responsible or liable for any threatening, defamatory, 
                             offensive, or illegal content or conduct of any other party or any infringement of 
                             another's rights, including intellectual property rights. Jehlum does not warrant that 
                             this site, its servers, or e-mail sent from this site are free of viruses or other harmful 
                             components. You download any material through the use of the service at your own risk, and 
                             you will be solely responsible for any damage to your computer system or loss of data that 
                             results from the download of any such material. No advice or information, whether oral or 
                             written, obtained by you from Jehlum or through or from the service, shall create any 
                             warranty not expressly stated in this agreement.
                        </p>
                    </li>
                </ul>
            </li><br><br>


            <li style="font-weight: bold;">
                Limitation of Liability 
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            Jehlum shall not be liable for any direct, indirect, punitive, incidental, special, 
                            consequential, exemplary, or other damages, including but not limited to damages for loss 
                            of profits, goodwill, use, data, or other intangible losses (even if Jehlum has been advised 
                            of the possibility of such damages), arising out of, resulting from or in any way connected 
                            with:
                        </p>
                        <p>
                            * the use or the inability to use, any delay in, or the performance of the service;<br>
                            * the cost of procuring substitute services resulting from any data, information, or services 
                                obtained, or messages received or transactions entered into through or from, the service;<br>
                            * unauthorized access to or alteration of your transmissions or data;<br>
                            * statements or conduct of any third party on the service; or<br>
                            * any other matter relating to the service or this agreement, whether based on contract, tort, 
                            negligence, strict liability, or otherwise. Some jurisdictions do not allow the exclusion 
                            of certain warranties or the limitation or exclusion of liability for special, incidental or 
                            consequentail damages. Accordingly some of the above limitations may not apply to you. 
                            If you are dissatisfied with any portion of the service or of this agreement, your 
                            exclusive remedy is to stop using the service.<br>
                        </p>
                    </li>
                </ul>
            </li><br><br>
            
            
            <li style="font-weight: bold;">
                Termination
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            YYou agree that Jehlum, in its sole discretion and without notice, may terminate your password, 
                            account (or any part thereof), or access to or use of the Service or any portion thereof, 
                            and remove and discard any content within the Service, at any time and for any reason, 
                            including, without limitation, if Jehlum believes that you have violated or acted 
                            inconsistently with this Agreement. Jehlum may prohibit or restrict access to the 
                            Service to anyone at any time, with or without cause. Jehlum may also in its sole discretion 
                            and at any time discontinue providing the Service, or any part of it, temporarily or permanently.
                            Jehlum will make reasonable commercial efforts to provide notice of any such discontinuation 
                            to you. You agree that Jehlum shall not be liable to you or any third party for any termination 
                            of your access to the Service or for any modification, suspension, or discontinuation of 
                            the Service. 
                        </p>
                    </li>
                </ul>
            </li><br><br>
            
            
            
            <li style="font-weight: bold;">
                Hypertext Links
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            This site contains links to other sites. The policies at other sites, which are owned and 
                            operated by third parties, may be different from this policy. Those third party sites’ 
                            policies will govern the use of information you provide to them. Jehlum makes no 
                            representations whatsoever about any other Web site that you may access through this one. 
                            Links imply neither that Jehlum is affiliated with or otherwise endorses any third parties 
                            nor that it is legally authorized to use any trademark, trade name, logo, or copyright symbol 
                            displayed in or accessible through the links, or that any linked site is authorized to use 
                            any trademark, trade name, logo, or copyright symbol of Jehlum.
                        </p>
                    </li>
                </ul>
            </li><br><br>

            
            
            <li style="font-weight: bold;">
                Copyright
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            US, India and international copyright laws and treaties protect this Site and its content. 
                            You agree to comply with all copyright laws in your use of this Site and to prevent any 
                            unauthorized copying of this Site and its contents. The copyright in all material provided 
                            on this Site is held by Jehlum. You may print out from the Site two copies of pages of 
                            content from the Site for your own personal or business use, provided you do not publish, 
                            copy, or otherwise re-transmit what you have printed out from the Site. Beyond this 
                            limited permission to print content, you may not copy, reproduce, distribute, republish, 
                            download, display, post, or transmit any Site content or software in any form or by any 
                            means, including, but not limited to, electronic, mechanical, photocopying, recording, or 
                            otherwise, without the express prior written permission of Jehlum. You may not “mirror” or 
                            “frame” any material contained on this Site or on any other Jehlum server without Jehlum's 
                            express prior written permission. Except as expressly provided in this Agreement, Jehlum 
                            does not grant any express or implied right to you under any patents, trademarks, copyrights, 
                            or other similar rights. 
                        </p>
                    </li>
                </ul>
            </li><br><br>
            
            
            <li style="font-weight: bold;">
                Copyright Agent
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;">
                        <p>
                            Jehlum's Copyright Agent for Notice of claims of copyright infringement can be reached at: 
                            arifbinashraf101@gmail.com you can also reach us by telephone at +91-8494061524.
                        </p>
                        
                        
                        <p>
                           If you believe that there is any content on the Site that infringes your copyrighted work, please provide the following information to Jehlum's Copyright Agent:<br><br>
                            * an electronic  signature of the person authorized to act on behalf of the owner of the copyright interest;<br>
                            * a description of the copyrighted work that you claim has been infringed;<br>
                            * a description of where the material that you claim is infringing is located on this Site;<br>
                            * your address, telephone number, and email address;<br>
                            * a statement by you that you have a good faith belief that the disputed use is not authorized by the copyright owner, its agent,or the law; and <br>
                            * a statement by you, made under penalty of perjury, that the above information in your Notice 
                            is accurate and that you are the copyright owner or authorized to act on the copyright owner's 
                            behalf.Trademarks The Jehlum name, the Jehlum logo, Jehlum Evalue Framework®, Jehlum  
                            HR Metrics™, and other trademarks, service marks, and logos (the "Trademarks") used and 
                            displayed on this Site are registered and unregistered Trademarks of Jehlum, or an affiliate 
                            of Jehlum. Nothing on this Site shall be construed as granting, by implication, estoppels, 
                            or otherwise, any license or right to use any Trademark displayed on the site without our 
                            express prior written permission. Jehlum prohibits the use of the Jehlum name, any of its 
                            registered domain names and any of its other trademarks as part of a link to or from any
                            site unless approved in advance by Jehlum in writing. You may not use any meta tags or any 
                            other hidden text utilizing any Jehlum Company domains, Jehlum, or other Trademarks without 
                            our express prior written consent.
                        </p>
                    </li>
                </ul>
            </li><br><br>

        </ol>
    </div>
</div>

    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>