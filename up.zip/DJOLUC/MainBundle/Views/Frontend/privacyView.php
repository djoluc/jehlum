<?php $title = "Jehlum home";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT; ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/miniCard.css?version=1.0" media="all" />
        <!--<link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/main_actuality_box.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css?version=1.0" media="all" /
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/horizontalScrollView.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />-->
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
        <script src="http://www.openlayers.org/api/OpenLayers.js"></script>
        <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/RegisterBundle/Public/Theme/Default/js/searchBar.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/LocationBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/ProductBundle/Public/Theme/Default/js/ProductLike.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/ProductBundle/Public/Theme/Default/js/UserShoppingCart.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/searchMap.js?version=1.0"></script>
        <!--<script type="text/javascript" src="DJOLUC/PaymentBundle/Public/Theme/Default/js/MtnMobileMoney.js"></script>-->
        
        <style>
.buttonload {
    background-color: #4CAF50; /* Green background */
    border: none; /* Remove borders */
    color: white; /* White text */
    padding: 12px 24px; /* Some padding */
    font-size: 16px; /* Set a font-size */
}
</style>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>



<div id="page_div" style="color: #000000;">
    <div class="about_box" style="border-radius: 10px;">
        
        <button style=" display: block; font-style: italic; font-weight: bold; width: calc(100% - 20px); height: 100px; border-radius: 0px; margin: auto; font-size: 30px;">
            Jehlum Privacy Policy (updated July 9, 2017)
        </button>
        <p style="font-style: italic;">
            &nbsp;&nbsp;&nbsp;This policy details how data about you is used when you access our websites and services or interact with us. 
            If we update it, we will revise the date, place notices on Jehlum if changes are material, and/or obtain your 
            consent as required by law.
        </p>
        
        <ol>
            <li style="font-weight: bold;">
                Protecting your privacy
                <ul style="font-weight: normal; font-size: 18px;">
                    <li>We take precautions to prevent unauthorized access to or misuse of data about you.</li>
                    <li>We do not engage in cross-marketing or link-referral programs.</li>
                    <li>We do not employ tracking devices for marketing purposes.</li>
                    <li>We do not send you unsolicited communications for marketing purposes.</li>
                    <li>We do not engage in affiliate marketing (and prohibit it on Jehlum).</li>
                    <li>We do provide email proxy & relay services to reduce unwanted email.</li>
                    <li>Please review privacy policies of any third party sites linked to from Jehlum.</li>
                </ul>
            </li><br><br>
            
            <li style="font-weight: bold;">
                Data we use to provide/improve our services and/or combat fraud/abuse:
                <ul style="font-weight: normal; font-size: 18px;">
                    <li style="list-style: none;"><p>
                        data you post on or send via Jehlum, and/or send us directly or via other sites
                        credit card data, which is transmitted to payment processors via a security protocol (e.g. SSL).
                        data you submit or provide (e.g. name, address, email, phone, fax, photos, tax ID).
                        web log data (e.g. web pages viewed, access times, IP address, HTTP headers).
                        data collected via cookies (e.g. search data and "favorites" lists).
                        data about your device(s) (e.g. screen size, DOM local storage, plugins).
                        data from 3rd parties (e.g. phone type, geo-location via IP address).
                    </p></li>
                </ul>
            </li><br><br>
            
            
            <li style="font-weight: bold;">
                Data we store
                <ul style="font-weight: normal; font-size: 18px;">
                    <li>We retain data as needed for our business purposes and/or as required by law.</li>
                    <li>We make good faith efforts to store data securely, but can make no guarantees.</li>
                    <li>You may access and update certain data about you via your account login.</li>
                </ul>
            </li><br><br>
            
            
            <li style="font-weight: bold;">
                Circumstances in which we may disclose user data:
                <ul style="font-weight: normal; font-size: 18px;">
                    <li>to vendors and service providers (e.g. payment processors) working on our behalf.</li>
                    <li>to respond to subpoenas, search warrants, court orders, or other legal process.</li>
                    <li>to protect our rights, property, or safety, or that of users of Jehlum or the general public.</li>
                    <li>with your consent (e.g. if you authorize us to share data with other users).</li>
                    <li>in connection with a merger, bankruptcy, or sale/transfer of assets.</li>
                    <li>in aggregate/summary form, where it cannot reasonably be used to identify you.</li>
                </ul>
            </li><br><br>
        </ol>
        
        <p>
            International Users - By accessing Jehlum or providing us data, you agree we may use and disclose data we 
            collect as described here or as communicated to you, transmit it outside your resident jurisdiction, and 
            store it on servers in the United States. For more information please contact our privacy officer at privacy@Jehlum.org
        </p>
    </div>
</div>

    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>