<div id="left_menu_content">
    <a class="left_menu_button" href="."><span class="logo" alt="A"><text>rtisan D'ici</text></span></a>
    <ul class="horizontal_header_menu">
        <?php if($data["userId"] > 0): ?>
                <a href="?a=shoppingCartContent"><li>Mon panier</li></a> 
                <a href="?a=userFavArtisan"><li>Favori</li></a>
                <a href="?a=profil"><li>Profil</li></a> 
        <?php endif; ?>
        <?php if($data["userId"] <= 0): ?>
             <a href="?a=authenticate"><li>Me connecter</li></a> 
             <a href="?a=register"><li>M'inscrire</li></a> 
        <?php endif; ?> 
    </ul>
</div>