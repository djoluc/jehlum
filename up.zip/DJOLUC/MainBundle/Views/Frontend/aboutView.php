<?php $title = "Jehlum home";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT; ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/Helper/css/miniCard.css?version=1.0" media="all" />
        <!--<link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/main_actuality_box.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css?version=1.0" media="all" /
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/horizontalScrollView.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />-->
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
        <script src="http://www.openlayers.org/api/OpenLayers.js"></script>
        <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/RegisterBundle/Public/Theme/Default/js/searchBar.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/LocationBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/ProductBundle/Public/Theme/Default/js/ProductLike.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/ProductBundle/Public/Theme/Default/js/UserShoppingCart.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/searchMap.js?version=1.0"></script>
        <!--<script type="text/javascript" src="DJOLUC/PaymentBundle/Public/Theme/Default/js/MtnMobileMoney.js"></script>-->
        
        <style>
.buttonload {
    background-color: #4CAF50; /* Green background */
    border: none; /* Remove borders */
    color: white; /* White text */
    padding: 12px 24px; /* Some padding */
    font-size: 16px; /* Set a font-size */
}
</style>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>



<div id="page_div" style="color: #000000;">
    <div class="about_box" style="border-radius: 10px;">
        
        <button style=" display: block; font-style: italic; width: 150px; height: 150px; border-radius: 150px; margin: auto; font-size: 100px;">
            <i class="fa fa-info"></i>
        </button>
        <p>
            &nbsp; &nbsp;Jehlum is your neighborhood classified and jobs ad posting site that aims at making life simpler for its users. 
             Jehlum is the easy way to search, buy or sell, to exchange, to interact for common or complementary interests 
             within or across local communities in Jammu and Kashmir.
        </p>
        
        <p>
            &nbsp; &nbsp;Our advertisers have always laid emphasis on simple processes. Driven by this preference, we have built the 
            website on key pillars of simplicity & smart applications for advertisements. Jehlum is a classified 
            advertisements website with sections devoted to jobs, personals, for sale,  business listing, communities, 
            news updates and more. If you are looking for a job, if you are interested in e commerce, Want to sell or buy 
            products, need manpower for your company, Jehlum is the place to be. With the help of smart application Jehlum 
            helps you find the best of the human resource in the neighbourhood apart from providing audience to your 
            localized business ads across jammu and kashmir.
        </p>
    </div>
</div>

    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>