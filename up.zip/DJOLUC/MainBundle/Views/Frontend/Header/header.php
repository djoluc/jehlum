<!-- <div id="top_bar">
            <span class="logo">
                    artisan d'ici
            </span>
            <!--<form>
                <select>
                    <option>Par pays</option>
                    <option>Par métier</option>
                </select>
                <input type="text" placeholder="recherche..."/>
                <button type="submit">RECHERCHE</button>
            </form>
</div>-->
            
 <?php if($data["isAdminUser"]): ?>           
<div class="admin_bar">
            <ul id="admin_menu">
                
                <?php if($data["isAdm"]): ?>
                
                <li><a href="<?= SITE_ROOT ?>useradmin">Users(<?= $data["userNumb"]; ?>)</a></li>
                    
                <?php endif; ?>
                <li><a href="<?= SITE_ROOT ?>pendingAds">Pending ads(<?= $data["pendingAdsNumb"]; ?>)</a></li>
                    
                <li><a href="<?= SITE_ROOT ?>adsCategory">Category(<?= $data["categoryNumb"]; ?>)</a></li>
                <li><a href="<?= SITE_ROOT ?>adsLocation">Location(<?= $data["locationNumb"]; ?>)</a></li>
                <li><a href="<?= SITE_ROOT ?>blackList">BlackList</a></li>
                <li><a href="<?= SITE_ROOT ?>linkedin">Linkedin</a></li>
            </ul>
</div>
<?php endif; ?>
<div id="menu_bar_contener">
        <div class="menu_bar"> 
            <ul class="menu_top_ul">
                <a href="/"><li class="logo"></li></a>
                <li class="menu">
                    <button class="bars"><i class="fa fa-bars"></i></button>
                    <ul>
                        <a href="<?= SITE_ROOT ?>" ><li>Home</li></a>
                        <!--<a href="<?= SITE_ROOT ?>category" ><li>Category</li></a>
                        <a href="<?= SITE_ROOT ?>location"><li>Location</li></a>
                        <a href="<?= SITE_ROOT ?>about" ><li>About us</li></a>-->
                        <a href="<?= SITE_ROOT ?>ads/newAds"><li>New Ad</li></a> 
                    </ul>
                </li>
                <a href="/ads/newAds"><button class="mobile_new_add" style="background: red; border-radius: 10px; color: #ffffff;"><i class="fa fa-plus"></i> New Ad</button></a>
                <a href="/ads/newAds"><button class="mobile_new_add mobile-search" style="background: transparent; border: 1px solid rgba(0, 0, 0, 0.1); border-radius: 10px; color: rgba(0, 0, 0, 0.4);"><i class="fa fa-search"></i></button></a>
            </ul>
                <?php //$data["leftMenu"]; ?>
            <?php if($data["displaySearchBar"]): ?>
                <form method="GET" action="" class="search_bar">
                    <?= $data["searchData"]; ?>
                    <input type="text" value="<?= $data["searchValue"]; ?>" placeholder="Recherche..." name="search" class=""/><button type="submit"><i class="fa fa-search"></i></button>
                </form>
            <?php endif; ?>
            <?php //$data["rightMenu"]; ?>
            <?= $data["authMenu"]; ?>
        </div>
    <?php if($data["displayAfterMenuArea"]): ?>
    <div class="header_after_menu" >
        <?php 
        $search = array_key_exists("search", $_GET)?stripslashes(htmlspecialchars($_GET["search"])):"";
        $locationOptions = ""; if(array_key_exists("locationAsOptions", $data)){ $locationOptions = $data["locationAsOptions"];} 
        ?>
        <div class="search_form_div">
            <form id="searchForm" method="get" action="/">
                <input type="hidden" value="search" name="a" />
                <i class="fa fa-location-arrow field_arrow"></i><select name="location"><?= $locationOptions ?></select><i class="fa fa-search field_arrow"></i><input autocomplete="off" type="text" name="search" value="<?= $search; ?>" placeholder="Search..." /><button type="submit">Search <i style="display: none;" class="fa fa-spinner fa-pulse"></i></button>
                 <ul class="autocompleteUl">
                    <!--<li>Example 1</li>
                    <li>Example 1</li>
                    <li>Example 1</li>
                    <li>Example 1</li>-->
                </ul>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

