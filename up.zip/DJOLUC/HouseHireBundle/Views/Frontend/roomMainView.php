<?php $title = $data["title"];  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT; ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.2" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/HouseHireBundle/Helper/css/leftSideBar.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/HouseHireBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/formBase.css?version=1.0" media="all" />
        
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/HouseHireBundle/Helper/js/searchBar.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/HouseHireBundle/Public/Theme/Default/js/roomMediaAdd.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/Helper/js/FileUploader.js?version=1.0"></script>
        
        
        <script type="text/javascript">
            var siteRoot = <?= SITE_ROOT; ?>
        </script>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>

        

<div id="page_div">
    <div id="side_box">
        <div class="left">
            left
        </div>
        <div class="right">
            <div id="house_pictures" class="box">
                    <div class="pictures">
                       <?php $roomPictures = $data["currentRoom"]->getRoomPictures();
                        foreach ($roomPictures AS $picture): //$picture = new DJOLUC\HouseHireBundle\Model\HouseMedia(0, 0, "", FALSE, "", 0, FALSE, 0);
                       ?>
                        <div class="picture">
                            <?php if(!empty($picture->getMediaLegend())): ?>
                            <span title="<?= $picture->getMediaLegend(); ?>"><?= $picture->getMediaLegend(); ?></span>
                            <?php endif; ?>
                            <div class="image_div">
                                <a href='<?= "".SITE_ROOT."runningData/RoomMedia/Image/".$picture->getMediaName(); ?>'><img src='<?= "".SITE_ROOT."runningData/RoomMedia/Image/mini/".$picture->getMediaName(); ?>' /></a>
                            </div>
                            <?php if($data["isMiniAdmOrMore"]): ?>
                            <div class="button_box">
                                <a href="<?= SITE_ROOT."roomMedia/delete/".$data["currentRoom"]->getRoomId()."/".$picture->getMediaAddTime().""; ?>"><button><i class="fas fa-trash"></i></button></a>
                                <a href="<?= SITE_ROOT."roomMedia/setCurrent/".$data["currentRoom"]->getRoomId()."/".$picture->getMediaAddTime().""; ?>"><button><?= SET; ?></button></a>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if($data["isModoOrMore"]): ?>
                    <form id="picture_send_form" method="POST" action="<?= SITE_ROOT ?>roomMedia/addImage" enctype="multipart/form-data">
                        <h3><?= SELECT_PICTURE ?></h3>
                        <div class="preview"></div>
                        <label>
                            <input type="file" name="image" required />
                        </label>
                        <label>
                            <input type="text" value="" placeholder="<?= LEGEND ?>" name="legend" />
                        </label>
                        <input type="hidden" value="<?= $data["currentRoom"]->getRoomId(); ?>" name="roomId" />
                        <progress max="1" value="0" style="display: none"></progress>
                        <p class="message"></p>
                        <input type="hidden" value=""  name="sent"/>
                        <button type="submit"><?= ADD; ?></button>
                    </form><br/><br/>
                    <?php endif; ?>
                </div><br/>
            
                
            <div id="house_videos" class="box">
                    <div class="videos">
                        <?php $roomVideos = $data["currentRoom"]->getRoomVideos();
                        foreach ($roomVideos AS $video): //$video = new DJOLUC\HouseHireBundle\Model\HouseMedia(0, 0, "", FALSE, "", 0, FALSE, 0);
                       ?>
                        
                        <div class="video">
                            <?php if(!empty($video->getLegend())): ?>
                            <span title="<?= $video->getLegend(); ?>"><?= $video->getLegend(); ?></span>
                            <?php endif; ?>
                            <div class="video_div">
                                <a href='<?= "".SITE_ROOT."runningData/RoomMedia/Video/".$video->getMediaName(); ?>'>
                                    <video controls >
                                        <source src="<?= "".SITE_ROOT."runningData/RoomMedia/Video/".$video->getMediaName(); ?>" />
                                    </video>
                                </a>
                            </div>
                            <?php if($data["isMiniAdmOrMore"]): ?>
                            <div class="button_box">
                                <a href="<?= SITE_ROOT."roomMedia/delete/".$data["currentRoom"]->getRoomId()."/".$video->getMediaAddTime().""; ?>"><button><i class="fas fa-trash"></i></button></a>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if($data["isModoOrMore"]): ?>
                    <form id="video_send_form" method="POST" action="<?= SITE_ROOT ?>houseMedia/addVideo" enctype="multipart/form-data">
                        <h3><?= SELECT_VIDEO ?></h3>
                        <div class="preview"></div>
                        <label>
                            <input type="file" accept=".mp4,.ogg" name="video" required />
                        </label>
                        <label>
                            <input type="text" value="" placeholder="<?= LEGEND ?>" name="legend" />
                        </label>
                        <input type="hidden" value="<?= $data["currentRoom"]->getRoomId(); ?>" name="roomId" />
                        <progress max="1" value="0" style="display: none;"></progress>
                        <p class="message"></p>
                        <input type="hidden" value=""  name="sent"/>
                        <button type="submit"><?= ADD ?></button>
                    </form><br/><br>
                    <?php endif; ?>
                </div><br>
        </div>
    </div>
</div>

    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>
