<?php $title = $data["title"];  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT; ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.2" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/HouseHireBundle/Helper/css/leftSideBar.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/HouseHireBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/formBase.css?version=1.0" media="all" />
        <!--<link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/horizontalScrollView.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />-->
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/HouseHireBundle/Helper/js/searchBar.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/HouseHireBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/Helper/js/FileUploader.js?version=1.0"></script>
        <!--<script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/ProductBundle/Public/Theme/Default/js/ProductLike.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/ProductBundle/Public/Theme/Default/js/UserShoppingCart.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/searchMap.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/PaymentBundle/Public/Theme/Default/js/MtnMobileMoney.js"></script>-->
        
        <script type="text/javascript">
            var siteRoot = <?= SITE_ROOT; ?>
        </script>
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>

        

    <div id="page_div">
        <div id="side_box">
            <div class="left">
                <button class="mobile-menu"><i class="fa fa-bars"></i></button>
                <div class="search">
                    <form id="searchForm">
                        <input type="text" value="" placeholder="<?= SEARCH ?>..." autocomplete="off" name="search" /><button type="submit"><i class="fa fa-search"></i></button>
                        <ul class="autocompleteUl">
                            <!--<li>Example 1</li>
                            <li>Example 1</li>
                            <li>Example 1</li>
                            <li>Example 1</li>-->
                        </ul>
                    </form>
                </div>
                
                <div class="loading" style="display: none"><i class="fa fa-spinner fa-pulse"></i></div>
                <div class="items">
                    <?php foreach ($data["houses"] AS $house): //$house = new \DJOLUC\HouseHireBundle\Model\House(0, "", "", 0, 1, 0, 0, 0, FALSE, 0); ?>
                    <div class="item" id="<?= $house->getHouseId(); ?>">
                        <ul class="data">
                            <a href="<?= SITE_ROOT ?>houses/<?= $house->getHouseId(); ?>"><li class="picture"><?= empty($house->getPrincipalPictureMini())?"":"<img src='".SITE_ROOT."".$house->getPrincipalPictureMini()."' />"; ?></li></a>
                            <li class="info">
                                <span><?= $house->getName(); ?></span>
                                <a><?= $house->getTimeReference(); ?></a>
                            </li>
                        </ul>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>    
                
            <div class="right">
                <?php if($data["isCurrentHouseExist"]): ?>
                <div class="title"><?= $data["currentHouse"]->getName(); ?></div>
                <div id="house_info_box">
                    <div class="owner box">
                        <h3>Propriétaire</h3>
                        <span class="image"></span>
                        <button>Changer</button>
                    </div>
                    <div class="description"><?= $data["currentHouse"]->getDescription(); ?></div>
                </div>
                
                
                <div id="house_pictures" class="box">
                    <div class="pictures">
                       <?php $housePictures = $data["currentHouse"]->getHousePictures();
                        foreach ($housePictures AS $picture): //$picture = new DJOLUC\HouseHireBundle\Model\HouseMedia(0, 0, "", FALSE, "", 0, FALSE, 0);
                       ?>
                        <div class="picture">
                            <?php if(!empty($picture->getLegend())): ?>
                            <span title="<?= $picture->getLegend(); ?>"><?= $picture->getLegend(); ?></span>
                            <?php endif; ?>
                            <div class="image_div">
                                <a href='<?= "".SITE_ROOT."runningData/HouseMedia/Image/".$picture->getMediaName(); ?>'><img src='<?= "".SITE_ROOT."runningData/HouseMedia/Image/mini/".$picture->getMediaName(); ?>' /></a>
                            </div>
                            <?php if($data["isMiniAdmOrMore"]): ?>
                            <div class="button_box">
                                <a href="<?= SITE_ROOT."houseMedia/delete/".$data["currentHouse"]->getHouseId()."/".$picture->getMediaAddTime().""; ?>"><button><i class="fas fa-trash"></i></button></a>
                                <a href="<?= SITE_ROOT."houseMedia/setCurrent/".$data["currentHouse"]->getHouseId()."/".$picture->getMediaAddTime().""; ?>"><button><?= SET; ?></button></a>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if($data["isModoOrMore"]): ?>
                    <form id="picture_send_form" method="POST" action="<?= SITE_ROOT ?>houseMedia/addImage" enctype="multipart/form-data">
                        <h3><?= SELECT_PICTURE ?></h3>
                        <div class="preview"></div>
                        <label>
                            <input type="file" name="image" required />
                        </label>
                        <label>
                            <input type="text" value="" placeholder="<?= LEGEND ?>" name="legend" />
                        </label>
                        <input type="hidden" value="<?= $data["currentHouse"]->getHouseId(); ?>" name="houseId" />
                        <progress max="1" value="0" style="display: none"></progress>
                        <p class="message"></p>
                        <input type="hidden" value=""  name="sent"/>
                        <button type="submit"><?= ADD; ?></button>
                    </form><br/><br/>
                    <?php endif; ?>
                </div><br/>
                
                
                <div id="house_videos" class="box">
                    <div class="videos">
                        <?php $houseVideos = $data["currentHouse"]->getHouseVideos();
                        foreach ($houseVideos AS $video): //$video = new DJOLUC\HouseHireBundle\Model\HouseMedia(0, 0, "", FALSE, "", 0, FALSE, 0);
                       ?>
                        
                        <div class="video">
                            <?php if(!empty($video->getLegend())): ?>
                            <span title="<?= $video->getLegend(); ?>"><?= $video->getLegend(); ?></span>
                            <?php endif; ?>
                            <div class="video_div">
                                <a href='<?= "".SITE_ROOT."runningData/HouseMedia/Video/".$video->getMediaName(); ?>'>
                                    <video controls >
                                        <source src="<?= "".SITE_ROOT."runningData/HouseMedia/Video/".$video->getMediaName(); ?>" />
                                    </video>
                                </a>
                            </div>
                            <?php if($data["isMiniAdmOrMore"]): ?>
                            <div class="button_box">
                                <a href="<?= SITE_ROOT."houseMedia/delete/".$data["currentHouse"]->getHouseId()."/".$video->getMediaAddTime().""; ?>"><button><i class="fas fa-trash"></i></button></a>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if($data["isModoOrMore"]): ?>
                    <form id="video_send_form" method="POST" action="<?= SITE_ROOT ?>houseMedia/addVideo" enctype="multipart/form-data">
                        <h3><?= SELECT_VIDEO ?></h3>
                        <div class="preview"></div>
                        <label>
                            <input type="file" accept=".mp4,.ogg" name="video" required />
                        </label>
                        <label>
                            <input type="text" value="" placeholder="<?= LEGEND ?>" name="legend" />
                        </label>
                        <input type="hidden" value="<?= $data["currentHouse"]->getHouseId(); ?>" name="houseId" />
                        <progress max="1" value="0" style="display: none;"></progress>
                        <p class="message"></p>
                        <input type="hidden" value=""  name="sent"/>
                        <button type="submit"><?= ADD ?></button>
                    </form><br/><br>
                    <?php endif; ?>
                </div><br>
                
                <?php if(!$data["currentHouse"]->isHireAllType()): ?>
                <div id="house_rooms" class="box">
                    <span>Les chanbre a louer</span>
                    
                    <div class="rooms">
                        <?php 
                        $rooms = $data["currentHouse"]->getHouseRooms();
                        foreach ($rooms AS $room):
                        ?>
                        <div class="room">
                            <div class="image_div">
                                
                            </div>
                            <a href="<?= SITE_ROOT ?>room/<?= $room->getRoomId(); ?>"><span>Name</span></a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if($data["isModoOrMore"]): ?>
                    <form id="room_add_form" method="POST" action="<?= SITE_ROOT ?>roomAdmin/addRoom" enctype="multipart/form-data">
                        <h3><?= ADD_ROOM ?></h3>
                        <div class="preview"></div>
                        <label>
                            <input type="text" name="name" placeholder="<?= ROOM_NAME ?>" required />
                        </label>
                        <label>
                            <textarea name="description" placeholder="<?= ROOM_DESCRIPTION ?>"></textarea>
                        </label>
                         <label>
                             <?= ROOM_NUMB ?>:
                             <input name="room_numb" type="number" step="any" value="1" min="0" />
                        </label>
                        <label>
                            <?= PRICE; ?>:
                            <input type="number" style="padding: 8px;" value="1" step="any" name="price" />
                            <select name="price_unit">
                                <option value="1">FCFA</option>
                                <option value="2">DOLLAR</option>
                            </select>
                        </label>
                        <label>
                            <?= PAYMENE_POLICY ?>:
                            <select name="payment_policy">
                                <option value="1"><?= MOUTHLY ?></option>
                                <option value="2"><?= YEARLY ?></option>
                            </select>
                        </label>
                        <label>
                            <?= MOUTH_OR_YEAR_ADVANCE_NUM ?>:
                            <select name="advance_numb">
                                <?php $i = 1; while($i <= 100):  ?>
                                <option value="<?= $i ?>"><?= $i++ ?></option>
                                <?php endwhile; ?>
                            </select>
                        </label>
                        <input type="hidden" value="<?= $data["currentHouse"]->getHouseId(); ?>" name="houseId" />
                        <progress max="1" value="0" style="display: none;"></progress>
                        <p class="message"></p>
                        <input type="hidden" value=""  name="sent"/>
                        <button type="submit"><?= ADD; ?></button>
                    </form><br/><br>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
</div>

    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>
