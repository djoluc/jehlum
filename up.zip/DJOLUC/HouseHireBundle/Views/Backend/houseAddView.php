<?php $title = $data["title"];  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.2" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/formBase.css?version=1.0" media="all" />
        <!--<link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css?version=1.0" media="all" /
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/horizontalScrollView.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />-->
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/LocationBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/HouseHireBundle/Public/Theme/Default/js/houseAdd.js?version=1.0"></script>
        
        <!--<script type="text/javascript" src="DJOLUC/PaymentBundle/Public/Theme/Default/js/MtnMobileMoney.js"></script>-->
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>


    <div id="page_div">
        <h3><?= ADD_HOUSE; ?></h3>
        <div id="form_div">
            <form class="form" name="house_add_form" method="POST" action="./houseAdd/add" enctype="multipart/form-data">
                <label>
                    <?= HOUSE_NAME.":" ?>
                    <input type="text" name="name" value="" placeholder="<?= HOUSE_NAME; ?>" required />
                </label>
                <label>
                    <?= HOUSE_DESCRIPTION.":"; ?>
                    <textarea name="description" placeholder="<?= HOUSE_DESCRIPTION; ?>" required></textarea>
                </label>
                <label>
                    <?= HOUSE_OWNER."(".EMAIL." ".OR_LITERAL." ".PHONE."):"; ?>
                    <input type="text" name="owner" value="" placeholder="<?= HOUSE_OWNER; ?>" required />
                </label>
                <label>
                    <?= LONGITUDE.":"; ?>
                    <input type="number" name="longitude" value="" placeholder="<?= LONGITUDE; ?>" required />
                </label>
                <label>
                    <?= LATITUDE.":"; ?>
                    <input type="number" name="latitude" value="" placeholder="<?= LATITUDE; ?>"  required />
                </label>
                <label>
                    <?= HOUSE_HIRE_TYPE; ?>
                    <select name="hireType">
                        <option value="1"><?= ALL_HOUSE; ?></option>
                        <option value="2"><?= ROOM_HIRE; ?></option>
                    </select>
                </label>
                <input type="hidden" value="" name="sent" />
                <p><?= $data["message"]; ?></p>
                <button type="submit"><?= ADD; ?></button>
            </form>
        </div>
    </div>

    <?php $body_content = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>
