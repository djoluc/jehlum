<?php

\define("ADD", "Ajouter");
\define("ADD_HOUSE", "Ajouter une maison");
\define("HOUSE_NAME", "Nom de la maison");
\define("HOUSE_DESCRIPTION", "Description de la maison");
\define("HOUSE_OWNER", "Propriétaire de la maison");
\define("LONGITUDE", "Longitude");
\define("LATITUDE", "Latitude");
\define("EMAIL", "email");
\define("PHONE", "Téléphone");
\define("OR_LITERAL", "ou");
\define("INVALID_USER", "Utilisateur n'est pas valide");
\define("NOT_ALOWED_ACTION", "Vous n'avez pas l'authotisation d'effectuer cette action.");
\define("HOUSE_HIRE_TYPE", "Type de location");
\define("ALL_HOUSE", "Toute la maison");
\define("ROOM_HIRE", "Location des chambres");
\define("ACTION_ERROR", "Une erreur s'est produit lors de cette action");
\define("HOUSES", "Les maisons");
\define("SEARCH", "Recherche");
\define("SELECT_PICTURE", "Sélectionnez une photo");
\define("SELECT_VIDEO", "Sélectionnez une vidéo");
\define("ROLE_ERROR", "Vous n'avez pas le droit d'effectuer cette action");
\define("LE_TYPE_ERROR", "Le type du fichier ne correspond pas");
\define("UNKNOW_ERROR", "Erreur inconnue");
\define("SUCCESS", "Réussit!");
\define("LEGEND", "Légende");
\define("SET", "Définir");
\define("ADD_ROOM", "Ajouter une chambre");
\define("ROOM_NAME", "Nom de la chambre");
\define("ROOM_DESCRIPTION", "Description de la chambre");
\define("ROOM_NUMB", "Nombre de chambre");
\define("PRICE", "Prix");
\define("MOUTHLY", "Par mois");
\define("YEARLY", "Par an");
\define("PAYMENE_POLICY", "Politique de payement");
\define("MOUTH_OR_YEAR_ADVANCE_NUM", "Nombre d'avance");

