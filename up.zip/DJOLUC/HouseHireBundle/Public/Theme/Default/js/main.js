var searchBar = null;
var houseManage = null;
$(document).ready(function(){
    searchBar = new SearchBar(function(text){
        if(text !== ""){
            loadHouseSearchProposition(text);
        }else{
            searchBar.clearAutoComplete();
        }
    }, 
    function(text){
        $(".left > .loading").attr("style", "display: inline-block");
        loadSearchedHouses(text);
    }, true);
    
    //searchBar.fillAutoComplete(["ok", "ol", "al"]);
    
    
    $(".item").click(function(e){
        //e.preventDefault();
        /*houseManage = new HouseManage();
        houseManage.setCurrentHouse($(this).attr("id"));*/
        //window.location = "./houses/"+$(this).attr("id")+"";
    });
    
    
    
    var pictureAddFileUploader = new FileUploader(siteRoot+"houseMedia/addImage/ajax", "picture_send_form", function(result){
        //alert(result);
        result = JSON.parse(result);
        if(result.result){
            window.location.reload();
        }else{
           $("#picture_send_form > .message").html(result.message); 
        }
    }, function(){
        
    });
    
    
    var videoAddFileUpload = new FileUploader(siteRoot+"houseMedia/addVideo/ajax", "video_send_form", function(result){
        //alert(result);
        result = JSON.parse(result);
        if(result.result){
            window.location.reload();
        }else{
           $("#picture_send_form > .message").html(result.message); 
        }
    }, function(){
        
    });
    
    
    
    
    var footer_offsetTop = $("#footer_div").offset().top;
    if(window.pageYOffset > footer_offsetTop-500){
        var footer_height = $("#footer_div").css("height");
        $("#side_box .left").attr("style", "top: -"+footer_height);
    }else{
        $("#side_box .left").attr("style", "");
    }
    
    $(window).scroll(function(){
        if(window.pageYOffset > footer_offsetTop-500){
            var footer_height = $("#footer_div").css("height");
            $("#side_box .left").attr("style", "top: -"+footer_height);
        }else{
            $("#side_box .left").attr("style", "");
        }
    });
});


function loadHouseSearchProposition(search){
    var formData = new FormData();
        formData.append("search", search);
        formData.append("sent", "");
        
        $.ajax({
            method: 'POST',
            enctype: 'multipart/form-data',
            url: siteRoot+"houses/loadHouseSearchProposition",
            data: formData,
            processData: false,
            contentType: false,
            timeout: 60000,
            xhr: function(){
                var xhr = $.ajaxSettings.xhr();
        
                xhr.onprogress = function(e){
                    //
                };
        
                xhr.upload.onprogress = function(e){
                  /*$("#avatar_progress").attr("max", e.total);
                    $("#avatar_progress").attr("value", e.loaded);*/
                };
        
                return xhr;
            }
        }).done(function(result){ 
            //alert(result);
            var rep = JSON.parse(result);
            searchBar.fillAutoComplete(rep);
            
        }).fail(function(){
            //alert("failed");
        });
}


function loadSearchedHouses(search){
    var formData = new FormData();
        formData.append("search", search);
        formData.append("sent", "");
        
        
        $.ajax({
            method: 'POST',
            enctype: 'multipart/form-data',
            url: siteRoot+"houses/loadSearchedHouse",
            data: formData,
            processData: false,
            contentType: false,
            timeout: 60000,
            xhr: function(){
                var xhr = $.ajaxSettings.xhr();
        
                xhr.onprogress = function(e){
                    //
                };
        
                xhr.upload.onprogress = function(e){
                  /*$("#avatar_progress").attr("max", e.total);
                    $("#avatar_progress").attr("value", e.loaded);*/
                };
        
                return xhr;
            }
        }).done(function(result){ 
            //alert(result);
            $(".left > .loading").attr("style", "display: none");
            var rep = JSON.parse(result);
            $(".left > .items").html("");
            putLoadedHousesInContener(rep);
            
        }).fail(function(){
            //alert("failed");
        });
}


function putLoadedHousesInContener(rep){
    for(var i = 0; i < rep.length; i++){
        var item =  '<div class="item">'+
                        '<ul class="data">'+
                            '<li class="picture">'+(rep[i]["principalMiniPicture"] == ""?"":"<img src='"+rep[i]["principalMiniPicture"]+"'/>")+'</li>'+
                            '<li class="info">'+
                                '<span>'+rep[i].name+'</span>'+
                                '<a>'+rep[i].time+'</a>'+
                            '</li>'+
                        '</ul>'+
                    '</div>';
        $(".left > .items").append(item);
    }
}




var HouseManage = function(){
    this.currentHouseId = 0;
};


HouseManage.prototype.setCurrentHouse = function(houseId){
    this.currentHouseId = houseId;
    $(".item").attr("style", "");
    $("#"+houseId+"").attr("style", "background: rgba(250, 240, 235, 1);");
    alert(houseId);
};