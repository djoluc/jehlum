$(document).ready(function(){
    var pictureAddFileUploader = new FileUploader(siteRoot+"roomMedia/addImage/ajax", "picture_send_form", function(result){
        //alert(result);
        result = JSON.parse(result);
        if(result.result){
            window.location.reload();
        }else{
           $("#picture_send_form > .message").html(result.message); 
        }
    }, function(){
        
    });
    
    
    var videoAddFileUpload = new FileUploader(siteRoot+"roomMedia/addVideo/ajax", "video_send_form", function(result){
        //alert(result);
        result = JSON.parse(result);
        if(result.result){
            window.location.reload();
        }else{
           $("#picture_send_form > .message").html(result.message); 
        }
    }, function(){
        
    });
    
    
    var footer_offsetTop = $("#footer_div").offset().top;
    if(window.pageYOffset > footer_offsetTop-500){
        var footer_height = $("#footer_div").css("height");
        $("#side_box .left").attr("style", "top: -"+footer_height);
    }else{
        $("#side_box .left").attr("style", "");
    }
    
    $(window).scroll(function(){
        if(window.pageYOffset > footer_offsetTop-500){
            var footer_height = $("#footer_div").css("height");
            $("#side_box .left").attr("style", "top: -"+footer_height);
        }else{
            $("#side_box .left").attr("style", "");
        }
    });
});