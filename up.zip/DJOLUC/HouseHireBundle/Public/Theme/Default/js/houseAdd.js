$(document).ready(function(){
    var geolocalManager = new GeolocalManager();
    geolocalManager.locate(function(lat, long){
        $("input[name='latitude']").val(lat);
        $("input[name='longitude']").val(long);
    }, function(object){
        alert(object.message);
    }, function(){
        alert("Unset");
    });
});