<?php

namespace DJOLUC\HouseHireBundle\Model\Frontend;

require_once 'App/Model/BaseModel.php';
require_once 'HouseDataSource.php';
require_once 'HousePrice.php';

/**
 * Description of HousePriceDataSource
 *
 * @author djoluc
 */
class HousePriceDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "house_price_table";
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("house_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("house_price", Array(
            Array(
                "name" => $this::REAL_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("price_unit", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_current", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("price_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addRelation($this->columns[0]["name"], HouseDataSource::TABLE_NAME."(".HouseDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        
        $this->createTable($this::TABLE_NAME);
    }
    
    
    
    public function addHousePrice($houseId, $housePrice, $priceUnit, $isCurrent, $time):bool{
        $out = FALSE;
        
        $houseDataSource = new HouseDataSource();
        if($houseDataSource->getHouse($houseId)->getHireType() == HouseDataSource::HIRE_ROOM_TYPE){
            return FALSE;
        }
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(?, ?, ?, ?, ?);
                ");
        $query->bindValue(1, $houseId, \PDO::PARAM_INT);
        $query->bindValue(2, $housePrice);
        $query->bindValue(3, $priceUnit, \PDO::PARAM_STR);
        $query->bindValue(4, $isCurrent, \PDO::PARAM_BOOL);
        $query->bindValue(5, $time, \PDO::PARAM_INT);
        if($query->execute()){
            $out = TRUE;
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    
    public function getHouseCurrentPrice($houseId):HousePrice{
        $out = HousePrice::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[3]["name"]." = ?; 
                ");
        $query->bindValue(1, $houseId, \PDO::PARAM_INT);
        $query->bindValue(2, TRUE, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->queryToHousePrice($query);
        }else{
            $this->throwException($query->errorInfo()[0]);
        }
        
        return $out;
    }
    
    
    
    private function queryToHousePrice(\PDOStatement $query):HousePrice{
        $out = HousePrice::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new HousePrice($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    
    
    private function queryToHousePrices(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new HousePrice($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
}
