<?php

namespace DJOLUC\HouseHireBundle\Model\Frontend;

require_once 'App/Model/BaseModel.php';
require_once 'House.php';

/**
 * house_table datasource
 *
 * @author djoluc
 */
class HouseDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "house_table";
    
    const HIRE_ALL_TYPE = 1;
    const HIRE_ROOM_TYPE = 2;
    
    const IMAGE_DIR = "runningData/HouseMedia/Image/";
    const VIDEO_DIR = "runningData/HouseMedia/Video/";
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("house_id", Array(
            Array(
                "name" => $this::COLUMN_INDEX_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("house_name", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "300", 
                "completers" => ""
            )
        ));
        $this->addColumns("house_description", Array(
            Array(
                "name" => $this::TEXT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("house_owner", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("hire_type", Array(
            Array(
                "name" => $this::INT_ATTR, 
                "param" => "10", 
                "completers" => ""
            )
        ));
        $this->addColumns("house_longitude", Array(
            Array(
                "name" => $this::REAL_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("house_latitude", Array(
            Array(
                "name" => $this::REAL_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("house_register_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_deleted", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::NOT_NULL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::DEFAULT_ATTR, 
                "param" => "", 
                "completers" => "FALSE"
            )
        ));
        $this->addColumns("media_delete_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR,
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addPrimaryKey($this->columns[0]["name"]);
        
        $this->addRelation($this->columns[3]["name"], \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME."(".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID.")", "ON DELETE CASCADE ON UPDATE CASCADE");
        
        $this->createTable($this::TABLE_NAME);
    }
    
    
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new HouseDataSource();
        
        return $thisObject->columns;
    }
    
    
    /**
     * 
     * @param type $name
     * @param type $owner
     * @param type $hireType
     * @param type $longitude
     * @param type $latitude
     * @param type $time
     * @return int
     * @throws \Exception
     */
    public function addHouse($name, $description, $owner, $hireType, $longitude, $latitude, $time, $isDeleted = false, $deleteTime = 0):int{
        $out = 0;
        
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(9).");
                ");
        $query->bindValue(1, $name, \PDO::PARAM_STR);
        $query->bindValue(2, $description, \PDO::PARAM_STR);
        $query->bindValue(3, $owner, \PDO::PARAM_INT);
        $query->bindValue(4, $hireType, \PDO::PARAM_INT);
        $query->bindValue(5, $longitude);
        $query->bindValue(6, $latitude);
        $query->bindValue(7, $time, \PDO::PARAM_INT);
        $query->bindValue(8, $isDeleted, \PDO::PARAM_BOOL);
        $query->bindValue(9, $deleteTime, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->DbPdo->lastInsertId();
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getHouse($houseId):House{
        $out = House::getEmpty();
        
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $houseId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToHouse($query);
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    
    
    public function getHouses($first, $number, $txt, $filter = ""):array{
        $out = Array();
        
        $txt = strtolower($txt);
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE 
                    (
                        lower(".$this->columns[1]["name"].") LIKE ? OR
                        lower(".$this->columns[2]["name"].") LIKE ? OR 
                        ".$this->columns[3]["name"]." IN ( SELECT ".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID." FROM ".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME." WHERE lower(".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_USER_MAIL.") LIKE ?) OR 
                        ".$this->columns[3]["name"]." IN ( SELECT ".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID." FROM ".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME." WHERE lower(".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_USER_NOM.") LIKE ?)
                    )
                    ".$filter." ORDER BY ".$this->columns[7]["name"]." DESC LIMIT ?, ?;
                ");
        $i = 1;
        $query->bindValue($i++, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue($i++, $first, \PDO::PARAM_INT);
        $query->bindValue($i++, $number, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToHouses($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function loadHousePropostionAsArray($txt, $first = 0, $numb = 5){
        $out = Array();
        
        $txt = \strtolower($txt);
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->columns[1]["name"]." FROM ".$this::TABLE_NAME." 
                    WHERE lower(".$this->columns[1]["name"].") LIKE ? OR 
                    ".$this->columns[3]["name"]." IN ( SELECT ".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID." FROM ".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME." WHERE lower(".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_USER_MAIL.") LIKE ?) OR 
                    ".$this->columns[3]["name"]." IN ( SELECT ".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID." FROM ".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME." WHERE lower(".\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_USER_NOM.") LIKE ?)
                    ORDER BY ".$this->columns[7]["name"]." DESC LIMIT ?, ?; 
                ");
        $i = 1;
        $query->bindValue($i++, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue($i++, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue($i++, $first, \PDO::PARAM_INT);
        $query->bindValue($i++, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            while ($data = $query->fetch()){
                $out[\count($out)] = $data[$this->columns[1]["name"]];
            }
        }
        $query->closeCursor();
        
        print $query->errorInfo()[2];
        
        return $out;
    }


    public function queryToHouse(\PDOStatement $query):House{
        $out = House::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new House($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    
    
    public function queryToHouses(\PDOStatement $query):array{
        $out = Array();
        
        
        while($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new House($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
}
