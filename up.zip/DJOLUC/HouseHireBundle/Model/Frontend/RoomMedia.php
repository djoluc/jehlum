<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DJOLUC\HouseHireBundle\Model;

/**
 * Description of RoomMedia
 *
 * @author djoluc
 */
class RoomMedia {
    private $roomId, 
            $mediaType, 
            $mediaName, 
            $isPrincipal,
            $mediaLegend,
            $mediaAddTime, 
            $isDeleted, 
            $mediaDeletedTime;
    
    
    
    
    public function __construct($roomId, $mediaType, $mediaName, $isPrincipal, $mediaLegend, $mediaAddTime, $isDeleted, $mediaDeletedTime) {
        $this->roomId = $roomId;
        $this->mediaType = $mediaType;
        $this->mediaName = $mediaName;
        $this->isPrincipal = $isPrincipal;
        $this->mediaLegend = $mediaLegend;
        $this->mediaAddTime = $mediaAddTime;
        $this->isDeleted = $isDeleted;
        $this->mediaDeletedTime = $mediaDeletedTime;
    }
    
    
    
    
    public function getRoomId() {
        return $this->roomId;
    }

    public function getMediaType() {
        return $this->mediaType;
    }

    public function getMediaName() {
        return $this->mediaName;
    }

    public function getIsPrincipal() {
        return $this->isPrincipal;
    }

    public function getMediaLegend() {
        return $this->mediaLegend;
    }

    public function getMediaAddTime() {
        return $this->mediaAddTime;
    }

    public function getIsDeleted() {
        return $this->isDeleted;
    }

    public function getMediaDeletedTime() {
        return $this->mediaDeletedTime;
    }

    public function setRoomId($roomId) {
        $this->roomId = $roomId;
    }

    public function setMediaType($mediaType) {
        $this->mediaType = $mediaType;
    }

    public function setMediaName($mediaName) {
        $this->mediaName = $mediaName;
    }

    public function setIsPrincipal($isPrincipal) {
        $this->isPrincipal = $isPrincipal;
    }

    public function setMediaLegend($mediaLegend) {
        $this->mediaLegend = $mediaLegend;
    }

    public function setMediaAddTime($mediaAddTime) {
        $this->mediaAddTime = $mediaAddTime;
    }

    public function setIsDeleted($isDeleted) {
        $this->isDeleted = $isDeleted;
    }

    public function setMediaDeletedTime($mediaDeletedTime) {
        $this->mediaDeletedTime = $mediaDeletedTime;
    }

    
    public static function getEmptyt():RoomMedia{
        return new RoomMedia(0, 0, "", FALSE, "", 0, FALSE, 0);
    }

}
