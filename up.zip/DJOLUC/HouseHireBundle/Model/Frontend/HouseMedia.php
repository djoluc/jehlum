<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DJOLUC\HouseHireBundle\Model;

/**
 * Description of HouseMedia
 *
 * @author djoluc
 */
class HouseMedia {
    private $houseId, 
            $mediaType, 
            $mediaName, 
            $isPrincipal,
            $legend,
            $mediaAddTime, 
            $isDeleted, 
            $mediaDeletedTime;
    
    
    
    public function __construct($houseId, $mediaType, $mediaName, $isPrincipal, $legend, $mediaAddTime, $isDeleted, $mediaDeletedTime) {
        $this->houseId = $houseId;
        $this->mediaType = $mediaType;
        $this->mediaName = $mediaName;
        $this->isPrincipal = $isPrincipal;
        $this->legend = $legend;
        $this->mediaAddTime = $mediaAddTime;
        $this->isDeleted = $isDeleted;
        $this->mediaDeletedTime = $mediaDeletedTime;
    }
    
    
    
    public function getHouseId() {
        return $this->houseId;
    }

    public function getMediaType() {
        return $this->mediaType;
    }

    public function getMediaName() {
        return $this->mediaName;
    }

    public function getIsPrincipal() {
        return $this->isPrincipal;
    }

    public function getLegend() {
        return $this->legend;
    }

    public function getMediaAddTime() {
        return $this->mediaAddTime;
    }

    public function getIsDeleted() {
        return $this->isDeleted;
    }

    public function getMediaDeletedTime() {
        return $this->mediaDeletedTime;
    }

    public function setHouseId($houseId) {
        $this->houseId = $houseId;
    }

    public function setMediaType($mediaType) {
        $this->mediaType = $mediaType;
    }

    public function setMediaName($mediaName) {
        $this->mediaName = $mediaName;
    }

    public function setIsPrincipal($isPrincipal) {
        $this->isPrincipal = $isPrincipal;
    }

    public function setLegend($legend) {
        $this->legend = $legend;
    }

    public function setMediaAddTime($mediaAddTime) {
        $this->mediaAddTime = $mediaAddTime;
    }

    public function setIsDeleted($isDeleted) {
        $this->isDeleted = $isDeleted;
    }

    public function setMediaDeletedTime($mediaDeletedTime) {
        $this->mediaDeletedTime = $mediaDeletedTime;
    }
        
    public static function getEmpty():HouseMedia{
        return new HouseMedia(0, 1, "", false, "", 0, FALSE, 0);
    }
    

}
