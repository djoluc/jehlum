<?php

namespace DJOLUC\HouseHireBundle\Model;

/**
 * Description of HouseOccupant
 *
 * @author djoluc
 */
class HouseOccupant {
    private $houseId, 
            $userId, 
            $isCurrentOccupant, 
            $hireTime, 
            $exitTime;
    
    
    public function __construct($houseId, $userId, $isCurrentOccupant, $hireTime, $exitTime) {
        $this->houseId = $houseId;
        $this->userId = $userId;
        $this->isCurrentOccupant = $isCurrentOccupant;
        $this->hireTime = $hireTime;
        $this->exitTime = $exitTime;
    }
    
    
    
    public function getHouseId() {
        return $this->houseId;
    }

    public function getUserId() {
        return $this->userId;
    }

    public function getIsCurrentOccupant() {
        return $this->isCurrentOccupant;
    }

    public function getHireTime() {
        return $this->hireTime;
    }

    public function getExitTime() {
        return $this->exitTime;
    }

    public function setHouseId($houseId) {
        $this->houseId = $houseId;
    }

    public function setUserId($userId) {
        $this->userId = $userId;
    }

    public function setIsCurrentOccupant($isCurrentOccupant) {
        $this->isCurrentOccupant = $isCurrentOccupant;
    }

    public function setHireTime($hireTime) {
        $this->hireTime = $hireTime;
    }

    public function setExitTime($exitTime) {
        $this->exitTime = $exitTime;
    }


    public static function getEmpty():HouseOccupant{
        return new HouseOccupant(0, 0, FALSE, 0, 0);
    }

}
