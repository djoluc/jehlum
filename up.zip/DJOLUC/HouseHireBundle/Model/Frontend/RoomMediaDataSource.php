<?php

namespace DJOLUC\HouseHireBundle\Model\Frontend;

require_once 'App/Model/BaseModel.php';
require_once 'RoomDataSource.php';
require_once 'RoomMedia.php';

/**
 * Description of RoomMediaDataSource
 *
 * @author djoluc
 */
class RoomMediaDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "room_media_table";
    
    const MEDIA_IMAGE_TYPE = 1;
    const MEDIA_VIDEO_TYPE = 2;
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("room_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("media_type", Array(
            Array(
                "name" => $this::INT_ATTR, 
                "param" => "2", 
                "completers" => ""
            )
        ));
        $this->addColumns("media_name", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "300", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_principal", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::NOT_NULL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::DEFAULT_ATTR, 
                "param" => "", 
                "completers" => "FALSE"
            )
        ));
        $this->addColumns("media_legend", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "200", 
                "completers" => ""
            )
        ));
        $this->addColumns("media_add_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR,
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_deleted", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::NOT_NULL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::DEFAULT_ATTR, 
                "param" => "", 
                "completers" => "FALSE"
            )
        ));
        $this->addColumns("media_delete_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR,
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addRelation($this->columns[0]["name"], RoomDataSource::TABLE_NAME."(".RoomDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        
        
        $this->createTable($this::TABLE_NAME);
        
        
        if(!\is_dir("runningData/RoomMedia")){
            \mkdir("runningData/RoomMedia");
        }
        
        if(!\is_dir("runningData/RoomMedia/Image")){
            \mkdir("runningData/RoomMedia/Image");
        }
        
        if(!\is_dir("runningData/RoomMedia/Video")){
            \mkdir("runningData/RoomMedia/Video");
        }
    }
    
    
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new HouseDataSource();
        
        return $thisObject->columns;
    }
    
    
    
    public function addRoomMedia($roomId, $mediaType, $mediaName, $isPrincipal, $mediaLegend, $mediaAddTime, $isDeleted, $mediaDeletedTime):bool{
        $out = false;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns)).")
                ");
        $i = 1;
        $query->bindValue($i++, $roomId, \PDO::PARAM_INT);
        $query->bindValue($i++, $mediaType, \PDO::PARAM_INT);
        $query->bindValue($i++, $mediaName, \PDO::PARAM_STR);
        $query->bindValue($i++, $isPrincipal, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $mediaLegend, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $mediaAddTime, \PDO::PARAM_INT);
        $query->bindValue($i++, $isDeleted, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $mediaDeletedTime, \PDO::PARAM_INT);
        if($query->execute()){
            $out = TRUE;
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    
    public function getCurrentRoomMedia($roomId):HouseMedia{
        $out = HouseMedia::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $roomId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToRoomMedia($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    
    
    
    public function getRoomPictures($roomId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $roomId, \PDO::PARAM_INT);
        $query->bindValue(2, $this::MEDIA_IMAGE_TYPE, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToRoomMedias($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    
    
    
    public function getRoomVideos($roomId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $roomId, \PDO::PARAM_INT);
        $query->bindValue(2, $this::MEDIA_VIDEO_TYPE, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToRoomMedias($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    
    
    public function queryToRoomMedia(\PDOStatement $query):RoomMedia{
        $out = RoomMedia::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new RoomMedia($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        
        return $out;
    }
    
    
    
    public function queryToRoomMedias(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
           $i = 0;
           $out[count($out)] = new RoomMedia($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
}
