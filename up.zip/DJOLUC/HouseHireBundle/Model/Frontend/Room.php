<?php

namespace DJOLUC\HouseHireBundle\Model;

require_once 'DJOLUC/Helper/php/DateManager.php';
require_once 'RoomMediaDataSource.php';

/**
 * Description of Room
 *
 * @author djoluc
 */
class Room {
    private $roomId, 
            $houseId, 
            $roomName,
            $description,
            $roomNumb,
            $hireAdvance, 
            $paymentPolicy,
            $roomTime,
            $isDeleted, 
            $deleteTime;
    
    
    
    
    
    public function __construct($roomId, $houseId, $roomName, $description, $roomNumb, $hireAdvance, $paymentPolicy, $roomTime, $isDeleted, $deleteTime) {
        $this->roomId = $roomId;
        $this->houseId = $houseId;
        $this->roomName = $roomName;
        $this->description = $description;
        $this->roomNumb = $roomNumb;
        $this->hireAdvance = $hireAdvance;
        $this->paymentPolicy = $paymentPolicy;
        $this->roomTime = $roomTime;
        $this->isDeleted = $isDeleted;
        $this->deleteTime = $deleteTime;
    }

    
    
    
    public function getRoomId() {
        return $this->roomId;
    }

    public function getHouseId() {
        return $this->houseId;
    }

    public function getRoomName() {
        return $this->roomName;
    }

    public function getDescription() {
        return $this->description;
    }

    public function getRoomNumb() {
        return $this->roomNumb;
    }

    public function getHireAdvance() {
        return $this->hireAdvance;
    }

    public function getPaymentPolicy() {
        return $this->paymentPolicy;
    }

    public function getRoomTime() {
        return $this->roomTime;
    }

    public function getIsDeleted() {
        return $this->isDeleted;
    }

    public function getDeleteTime() {
        return $this->deleteTime;
    }

    public function setRoomId($roomId) {
        $this->roomId = $roomId;
    }

    public function setHouseId($houseId) {
        $this->houseId = $houseId;
    }

    public function setRoomName($roomName) {
        $this->roomName = $roomName;
    }

    public function setDescription($description) {
        $this->description = $description;
    }

    public function setRoomNumb($roomNumb) {
        $this->roomNumb = $roomNumb;
    }

    public function setHireAdvance($hireAdvance) {
        $this->hireAdvance = $hireAdvance;
    }

    public function setPaymentPolicy($paymentPolicy) {
        $this->paymentPolicy = $paymentPolicy;
    }

    public function setRoomTime($roomTime) {
        $this->roomTime = $roomTime;
    }

    public function setIsDeleted($isDeleted) {
        $this->isDeleted = $isDeleted;
    }

    public function setDeleteTime($deleteTime) {
        $this->deleteTime = $deleteTime;
    }

    
    

    public static function getEmpty():Room{
        return new Room(0, 0, "", "", 0, 0, 0, 0, false, 0);
    }
    
    
    
    public function getRoomPictures():array{
        $roomMediaDataSource = new RoomMediaDataSource();
                
        return $roomMediaDataSource->getRoomPictures($this->houseId);
    }
    
    
    public function getRoomVideos():array{
        $roomMediaDataSource = new RoomMediaDataSource();
                
        return $roomMediaDataSource->getRoomVideos($this->houseId);
    }
}
