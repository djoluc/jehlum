<?php

namespace DJOLUC\HouseHireBundle\Model\Frontend;

require_once 'App/Model/BaseModel.php';
require_once 'DJOLUC/RegisterBundle/Model/UserDataSource.php';
require_once 'HouseDataSource.php';
require_once 'HouseOccupant.php';


/**
 * Description of HouseOccupantDataSource
 *
 * @author djoluc
 */
class HouseOccupantDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "house_occupant_table";
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("house_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("occupant_user_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_current_occupant", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::NOT_NULL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::DEFAULT_ATTR, 
                "param" => "", 
                "completers" => "FALSE"
            )
        ));
        $this->addColumns("hire_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR,
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("exit_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR,
                "param" => "", 
                "completers" => ""
            )
        ));
        
        
        $this->addRelation($this->columns[0]["name"], HouseDataSource::TABLE_NAME."(".HouseDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        
        $this->addRelation($this->columns[1]["name"], \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME."(". \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID.")", "ON DELETE CASCADE ON UPDATE CASCADE");
        
        $this->createTable($this::TABLE_NAME);
    }
    
    
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new HouseDataSource();
        
        return $thisObject->columns;
    }
    
    
    
    public function addHouseOccupant($houseId, $userId, $isCurrentOccupant, $hireTime, $exitTime):bool{
        $out = FALSE;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(5).");
                ");
        $query->bindValue(1, $houseId, \PDO::PARAM_INT);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $query->bindValue(3, $isCurrentOccupant, \PDO::PARAM_BOOL);
        $query->bindValue(4, $hireTime, \PDO::PARAM_INT);
        $query->bindValue(5, $exitTime, \PDO::PARAM_INT);
        if($query->execute()){
            $out = true;
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getHouseCurrentOccupant($houseId):HouseOccupant{
        $out = HouseOccupant::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[2]["name"]." = ?;
                ");
        $query->bindValue(1, $houseId, \PDO::PARAM_INT);
        $query->bindValue(2, FALSE, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->queryToHouseOccupant($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    
    public function getHouseOccupants($houseId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $houseId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToHouseOccupant($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    public function queryToHouseOccupant(\PDOStatement $query):HouseOccupant{
        $out = HouseOccupant::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new HouseOccupant($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    
    
    public function queryToHouseOccupants(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new HouseOccupant($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
}
