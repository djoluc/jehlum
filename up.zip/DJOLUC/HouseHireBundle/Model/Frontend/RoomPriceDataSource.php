<?php

namespace DJOLUC\HouseHireBundle\Model\Frontend;

require_once 'App/Model/BaseModel.php';
require_once 'RoomDataSource.php';
require_once 'RoomPrice.php';

/**
 * Description of RoomPriceDataSource
 *
 * @author djoluc
 */
class RoomPriceDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "room_price_table";
    
    
    public function __construct() {
        parent::__construct();
       
        
        $this->addColumns("room_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("room_price", Array(
            Array(
                "name" => $this::REAL_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("price_unit", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ), 
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_current", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("price_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addRelation($this->columns[0]["name"], RoomDataSource::TABLE_NAME."(".RoomDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        
        
        $this->createTable($this::TABLE_NAME);
    }
    
    
    public function addRoomPrice($roomId, $roomPrice, $priceUnit, $isCurrent, $time):bool{
        $out = FALSE;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(?, ?, ?, ?, ?);
                ");
        $query->bindValue(1, $roomId, \PDO::PARAM_INT);
        $query->bindValue(2, $roomPrice);
        $query->bindValue(3, $priceUnit, \PDO::PARAM_STR);
        $query->bindValue(4, $isCurrent, \PDO::PARAM_BOOL);
        $query->bindValue(5, $time, \PDO::PARAM_INT);
        if($query->execute()){
            $out = TRUE;
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getRoomCurrentPrice($roomId):RoomPrice{
        $out = HousePrice::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ? AND ".$this->columns[3]["name"]." = ?; 
                ");
        $query->bindValue(1, $roomId, \PDO::PARAM_INT);
        $query->bindValue(2, TRUE, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->queryToHousePrice($query);
        }else{
            $this->throwException($query->errorInfo()[0]);
        }
        
        return $out;
    }
    
    
    
    private function queryToRoomPrice(\PDOStatement $query):HousePrice{
        $out = HousePrice::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new HousePrice($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    
    
    private function queryToRoomPrices(\PDOStatement $query):array{
        $out = Array();
        
        while($data = $query->fetch()){
            $i = 0;
            $out[count($out)] = new HousePrice($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
}
