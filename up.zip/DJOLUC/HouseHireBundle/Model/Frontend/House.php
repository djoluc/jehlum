<?php

namespace DJOLUC\HouseHireBundle\Model;

require_once 'DJOLUC/Helper/php/DateManager.php';
require_once 'HouseMediaDataSource.php';
require_once 'RoomDataSource.php';

/**
 * Description of House
 *
 * @author djoluc
 */
class House {
    private $houseId, 
            $name,
            $description,
            $owner, 
            $hireType, 
            $longitude, 
            $latitude, 
            $time, 
            $isDeleted, 
            $deleteTime;
    
    
    
    
    function __construct($houseId, $name, $description, $owner, $hireType, $longitude, $latitude, $time, $isDeleted, $deleteTime) {
        $this->houseId = $houseId;
        $this->name = $name;
        $this->description = $description;
        $this->owner = $owner;
        $this->hireType = $hireType;
        $this->longitude = $longitude;
        $this->latitude = $latitude;
        $this->time = $time;
        $this->isDeleted = $isDeleted;
        $this->deleteTime = $deleteTime;
    }
    
    
    
    public function getHouseId() {
        return $this->houseId;
    }

    public function getName() {
        return $this->name;
    }
    
    public function getDescription() {
        return $this->description;
    }

    public function setDescription($description) {
        $this->description = $description;
    }

    
    public function getOwner() {
        return $this->owner;
    }

    public function getHireType() {
        return $this->hireType;
    }

    public function getLongitude() {
        return $this->longitude;
    }

    public function getLatitude() {
        return $this->latitude;
    }

    public function getTime() {
        return $this->time;
    }

    public function setHouseId($houseId) {
        $this->houseId = $houseId;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function setOwner($owner) {
        $this->owner = $owner;
    }

    public function setHireType($hireType) {
        $this->hireType = $hireType;
    }

    public function setLongitude($longitude) {
        $this->longitude = $longitude;
    }

    public function setLatitude($latitude) {
        $this->latitude = $latitude;
    }

    public function setTime($time) {
        $this->time = $time;
    }
    
    
    public function getIsDeleted() {
        return $this->isDeleted;
    }

    public function getDeleteTime() {
        return $this->deleteTime;
    }

    public function setIsDeleted($isDeleted) {
        $this->isDeleted = $isDeleted;
    }

    public function setDeleteTime($deleteTime) {
        $this->deleteTime = $deleteTime;
    }
    
    
    public function getTimeReference():string{
        $dateManager = new \DJOLUC\Helper\DateManager($this->getTime());
        
        return $dateManager->getShortReference();
    }

    

    public static function getEmpty():House{
        return new House(0, "", "", 0, 0, 0, 0, 0, FALSE, 0);
    }
    
    
    
    public function getPrincipalPictureMini():string{
        $houseMediaDataSource = new HouseMediaDataSource();
        $houseMedia = $houseMediaDataSource->getCurrentHouseMedia($this->houseId);
        
        $out = empty($houseMedia->getMediaName())?"":"runningData/HouseMedia/Image/mini/".$houseMedia->getMediaName()."";
        
        return $out;
    }
    
    
    
    public function getHousePictures():array{
        $houseMediaDataSource = new HouseMediaDataSource();
                
        return $houseMediaDataSource->getHousePictures($this->houseId);
    }
    
    
    public function getHouseVideos():array{
        $houseMediaDataSource = new HouseMediaDataSource();
                
        return $houseMediaDataSource->getHouseVideos($this->houseId);
    }
    
    
    
    public function isHireAllType():bool{
        return ($this->getHireType() == HouseDataSource::HIRE_ALL_TYPE);
    }
    
    
    
    public function getHouseRooms():array{
        $roomDataSource = new RoomDataSource();
        
        return $roomDataSource->getHouseRooms($this->houseId);
    }

}
