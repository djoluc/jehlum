<?php

namespace DJOLUC\HouseHireBundle\Model;

/**
 * Description of RoomPrice
 *
 * @author djoluc
 */
class RoomPrice {
    private $roomId, 
            $roomPrice, 
            $priceUnit, 
            $isCurrent, 
            $time;
    
    
    public function __construct($roomId, $roomPrice, $priceUnit, $isCurrent, $time) {
        $this->roomId = $roomId;
        $this->roomPrice = $roomPrice;
        $this->priceUnit = $priceUnit;
        $this->isCurrent = $isCurrent;
        $this->time = $time;
    }
    
    public function getRoomId() {
        return $this->roomId;
    }

    public function getRoomPrice() {
        return $this->roomPrice;
    }

    public function getPriceUnit() {
        return $this->priceUnit;
    }

    public function getIsCurrent() {
        return $this->isCurrent;
    }

    public function getTime() {
        return $this->time;
    }

    public function setRoomId($roomId) {
        $this->roomId = $roomId;
    }

    public function setRoomPrice($roomPrice) {
        $this->roomPrice = $roomPrice;
    }

    public function setPriceUnit($priceUnit) {
        $this->priceUnit = $priceUnit;
    }

    public function setIsCurrent($isCurrent) {
        $this->isCurrent = $isCurrent;
    }

    public function setTime($time) {
        $this->time = $time;
    }


    public static function getEmpty():RoomPrice{
        return new RoomPrice(0, 0, 0, FALSE, 0);
    }

}
