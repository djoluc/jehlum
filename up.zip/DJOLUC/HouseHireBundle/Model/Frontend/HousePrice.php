<?php

namespace DJOLUC\HouseHireBundle\Model;

/**
 * Description of HousePrice
 *
 * @author djoluc
 */
class HousePrice {
    private $houseId, 
            $housePrice, 
            $priceUnit, 
            $isCurrent, 
            $time;
    
    
    public function __construct($houseId, $housePrice, $priceUnit, $isCurrent, $time) {
        $this->houseId = $houseId;
        $this->housePrice = $housePrice;
        $this->priceUnit = $priceUnit;
        $this->isCurrent = $isCurrent;
        $this->time = $time;
    }
    
    
    public function getHouseId() {
        return $this->houseId;
    }

    public function getHousePrice() {
        return $this->housePrice;
    }

    public function getPriceUnit() {
        return $this->priceUnit;
    }

    public function getIsCurrent() {
        return $this->isCurrent;
    }

    public function getTime() {
        return $this->time;
    }

    public function setHouseId($houseId) {
        $this->houseId = $houseId;
    }

    public function setHousePrice($housePrice) {
        $this->housePrice = $housePrice;
    }

    public function setPriceUnit($priceUnit) {
        $this->priceUnit = $priceUnit;
    }

    public function setIsCurrent($isCurrent) {
        $this->isCurrent = $isCurrent;
    }

    public function setTime($time) {
        $this->time = $time;
    }


    public static function getEmpty():HousePrice{
        return new HousePrice(0, 0, "", FALSE, 0);
    }

}
