<?php

namespace DJOLUC\HouseHireBundle\Model;

/**
 * Description of RoomOccupant
 *
 * @author djoluc
 */
class RoomOccupant {
    private $roomId, 
            $userId, 
            $isCurrentOccupant, 
            $hireTime, 
            $exitTime;
    
    
    
    public function __construct($roomId, $userId, $isCurrentOccupant, $hireTime, $exitTime) {
        $this->roomId = $roomId;
        $this->userId = $userId;
        $this->isCurrentOccupant = $isCurrentOccupant;
        $this->hireTime = $hireTime;
        $this->exitTime = $exitTime;
    }
    
    
    
    
    public function getRoomId() {
        return $this->roomId;
    }

    public function getUserId() {
        return $this->userId;
    }

    public function getIsCurrentOccupant() {
        return $this->isCurrentOccupant;
    }

    public function getHireTime() {
        return $this->hireTime;
    }

    public function getExitTime() {
        return $this->exitTime;
    }

    public function setRoomId($roomId) {
        $this->roomId = $roomId;
    }

    public function setUserId($userId) {
        $this->userId = $userId;
    }

    public function setIsCurrentOccupant($isCurrentOccupant) {
        $this->isCurrentOccupant = $isCurrentOccupant;
    }

    public function setHireTime($hireTime) {
        $this->hireTime = $hireTime;
    }

    public function setExitTime($exitTime) {
        $this->exitTime = $exitTime;
    }
    
    
    public static function getEmpty():RoomOccupant{
        return new RoomOccupant(0, 0, FALSE, 0, 0);
    }

}
