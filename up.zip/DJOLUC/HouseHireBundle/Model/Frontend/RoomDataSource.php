<?php

namespace DJOLUC\HouseHireBundle\Model\Frontend;

require_once 'App/Model/BaseModel.php';
require_once 'HouseDataSource.php';
require_once 'Room.php';

/**
 * Description of RoomDataSource
 *
 * @author djoluc
 */
class RoomDataSource extends \App\Model\BaseModel {
    const TABLE_NAME = "room_table";
    
    const MOUTHLY_PAYMENT_POLICY = 1;
    const YEARLY_PAYMENT_POLICY = 2;
    
    const IMAGE_DIR = "runningData/RoomMedia/Image/";
    const VIDEO_DIR = "runningData/RoomMedia/Video/";
    
    public function __construct() {
        parent::__construct();
        
        $this->addColumns("room_id", Array(
            Array(
                "name" => $this::COLUMN_INDEX_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("cores_house_id", Array(
            Array(
                "name" => $this::BIGINT_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::UNSIGNED_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("room_name", Array(
            Array(
                "name" => $this::VARCHAR_ATTR, 
                "param" => "300", 
                "completers" => ""
            )
        ));
        $this->addColumns("room_description", Array(
            Array(
                "name" => $this::TEXT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("room_numb", Array(
            Array(
                "name" => $this::INT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addColumns("hire_mouth_or_year_advance_numb", Array(
            Array(
                "name" => $this::INT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addColumns("payment_policy", Array(
            Array(
                "name" => $this::INT_ATTR, 
                "param" => "2", 
                "completers" => ""
            )
        ));
        
        $this->addColumns("room_time", Array(
            Array(
                "name" => $this::INT_ATTR, 
                "param" => "", 
                "completers" => ""
            )
        ));
        $this->addColumns("is_deleted", Array(
            Array(
                "name" => $this::BOOL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::NOT_NULL_ATTR, 
                "param" => "", 
                "completers" => ""
            ),
            Array(
                "name" => $this::DEFAULT_ATTR, 
                "param" => "", 
                "completers" => "FALSE"
            )
        ));
        $this->addColumns("media_delete_time", Array(
            Array(
                "name" => $this::BIGINT_ATTR,
                "param" => "", 
                "completers" => ""
            )
        ));
        
        $this->addPrimaryKey($this->columns[0]["name"]);
        
        $this->addRelation($this->columns[1]["name"], HouseDataSource::TABLE_NAME."(".HouseDataSource::getColumns()[0]["name"].")", "ON DELETE CASCADE ON UPDATE CASCADE");
        
        $this->createTable($this::TABLE_NAME);
        
    }
    
    
    
    public static function getColumns(): array {
        parent::getColumns();
        
        $thisObject = new RoomDataSource();
        
        return $thisObject->columns;
    }






    public function addRoom($houseId, $roomName, $description, $roomNumb, $hireAdvance, $paymentPolicy, $roomTime, $isDeleted = false, $deleteTime = 0):int{
        $out = 0;
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->getAllColumnWithoutIndex().") VALUES(".$this->generateParamQuestionMark(count($this->columns)-1).");
                ");
        $i = 1;
        $query->bindValue($i++, $houseId, \PDO::PARAM_INT);
        $query->bindValue($i++, $roomName, \PDO::PARAM_STR);
        $query->bindValue($i++, $description, \PDO::PARAM_STR);
        $query->bindValue($i++, $roomNumb, \PDO::PARAM_INT);
        $query->bindValue($i++, $hireAdvance, \PDO::PARAM_INT);
        $query->bindValue($i++, $paymentPolicy, \PDO::PARAM_INT);
        $query->bindValue($i++, $roomTime, \PDO::PARAM_INT);
        $query->bindValue($i++, $isDeleted, \PDO::PARAM_BOOL);
        $query->bindValue($i++, $deleteTime, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->DbPdo->lastInsertId();
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getRoom($roomId):Room{
        $out = Room::getEmpty();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[0]["name"]." = ?;
                ");
        $query->bindValue(1, $roomId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToRoom($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getHouseRooms($houseId):array{
        $out = Array();
        
        $query = new \PDOStatement();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->columns[0]["name"].", ".$this->getAllColumnWithoutIndex()." FROM ".$this::TABLE_NAME." WHERE ".$this->columns[1]["name"]." = ?;
                ");
        $query->bindValue(1, $houseId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToRooms($query);
        }else{
            $this->throwException($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    
    private function queryToRoom(\PDOStatement $query):Room{
        $out = Room::getEmpty();
        
        if($data = $query->fetch()){
            $i = 0;
            $out = new Room($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
    
    
    
    public function queryToRooms(\PDOStatement $query):array{
        $out = Array();
        
        while ($data = $query->fetch()){
            $i = 0;
            
            $out[count($out)] = new Room($data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]], $data[$this->columns[$i++]["name"]]);
        }
        
        return $out;
    }
    
}
