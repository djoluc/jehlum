<?php

namespace DJOLUC\HouseHireBundle\Controller\Backend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseMediaDataSource.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
require_once 'App/Cache/StaticPageCache/StaticPageCacheManager.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';
require_once 'DJOLUC/Helper/FileUploader.php';
require_once 'DJOLUC/Helper/fonct.php';

/**
 * Description of RoomMediaController
 *
 * @author djoluc
 */
class RoomMediaController extends \App\Controller\BaseController {
    private $userDataSource, 
            $sessionManageController, 
            $houseDataSource, 
            $houseMediaDataSource, 
            $roomMediaDataSource, 
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->sessionManageController = new \DJOLUC\RegisterBundle\Controller\Frontend\SessionManageController();
        $this->houseDataSource = new \DJOLUC\HouseHireBundle\Model\HouseDataSource();
        $this->houseMediaDataSource = new \DJOLUC\HouseHireBundle\Model\HouseMediaDataSource();
        $this->roomMediaDataSource = new \DJOLUC\HouseHireBundle\Model\RoomMediaDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    
    public function addImageAction(){
        $out = Array(
            "result" => FALSE, 
            "message" => UNKNOW_ERROR
        );
        if(array_key_exists("sent", $_POST)){
            $roomId = filter_input(INPUT_POST, "roomId", FILTER_SANITIZE_NUMBER_INT);
            $legend = filter_input(INPUT_POST, "legend", FILTER_SANITIZE_STRING);
            $isAjax = array_key_exists("c", $_GET)&&filter_input(INPUT_GET, "c")=="ajax";
            
            $fileUploader = new \DJOLUC\Helper\FileUploader("image", \DJOLUC\HouseHireBundle\Model\RoomDataSource::IMAGE_DIR, $this->userId, "image", "own_name", "".$this->userId."_".\time()."");
            if($fileUploader->upload(FALSE)){
                miniature($fileUploader->getFileDir(), 200, $fileUploader->getFileDir()."mini", $fileUploader->getFileName());
                
                $this->roomMediaDataSource->addRoomMedia($roomId, \DJOLUC\HouseHireBundle\Model\RoomMediaDataSource::MEDIA_IMAGE_TYPE, $fileUploader->getFileName(), TRUE, $legend, \time(), FALSE, 0);
                
                $this->clearCache($this->getRefererRequestUrlWithoutHttp());
                
                
                $out["result"] = TRUE;
                $out["message"] = SUCCESS;
                if(!$isAjax){
                    \header("Location: ".$this->getRefererRequestUrl()."");
                }else{
                   $this->printPureJson($out); 
                }
            } else {
                if(!$isAjax){
                    \header("Location: ".$this->getRefererRequestUrl()."");
                }else{
                   $this->printPureJson($out); 
                }
            }
        }
    }
    
    
    
    public function addVideoAction(){
        $out = Array(
            "result" => FALSE, 
            "message" => UNKNOW_ERROR
        );
        if(array_key_exists("sent", $_POST)){
            $roomId = filter_input(INPUT_POST, "roomId", FILTER_SANITIZE_NUMBER_INT);
            $legend = filter_input(INPUT_POST, "legend", FILTER_SANITIZE_STRING);
            $isAjax = array_key_exists("c", $_GET)&&filter_input(INPUT_GET, "c")=="ajax";
            
            $fileUploader = new \DJOLUC\Helper\FileUploader("video", \DJOLUC\HouseHireBundle\Model\RoomDataSource::VIDEO_DIR, $this->userId, "video", "own_name", "".$this->userId."_".\time()."");
            if($fileUploader->upload(FALSE)){
                
                $this->roomMediaDataSource->addRoomMedia($roomId, \DJOLUC\HouseHireBundle\Model\RoomMediaDataSource::MEDIA_VIDEO_TYPE, $fileUploader->getFileName(), FALSE, $legend, \time(), FALSE, 0);
                
                $this->clearCache($this->getRefererRequestUrlWithoutHttp());
                
                
                $out["result"] = TRUE;
                $out["message"] = SUCCESS;
                if(!$isAjax){
                    \header("Location: ".$this->getRefererRequestUrl()."");
                }else{
                   $this->printPureJson($out); 
                }
            } else {
                if(!$isAjax){
                    \header("Location: ".$this->getRefererRequestUrl()."");
                }else{
                   $this->printPureJson($out); 
                }
            }
        }
    }
    
    
    
    public function deleteAction(){
        
        if($this->isMiniAdmOrMore){
            $houseId = filter_input(INPUT_GET, "c", FILTER_SANITIZE_NUMBER_INT);
            $mediaAddTime = filter_input(INPUT_GET, "d", FILTER_SANITIZE_NUMBER_INT);
            
            $this->houseMediaDataSource->deleteHouseMedia($houseId, $mediaAddTime);
            
            $this->clearCache($this->getRefererRequestUrlWithoutHttp());
        }
        \header("Location: ".$this->getRefererRequestUrl()."");
    }



    public function setCurrentAction(){
        if($this->isModoOrMore){
            $houseId = filter_input(INPUT_GET, "c", FILTER_SANITIZE_NUMBER_INT);
            $mediaAddTime = filter_input(INPUT_GET, "d", FILTER_SANITIZE_NUMBER_INT);
            
            $this->houseMediaDataSource->setAsCurrent($houseId, $mediaAddTime);
            
            $this->clearCache($this->getRefererRequestUrlWithoutHttp());
            
        }
        \header("Location: ".$this->getRefererRequestUrl()."");
    }
    
    
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
    }

    public static function rooter($lang = "", bool $enableCache = false, $cacheDir = "Cache/") {
        parent::rooter("DJOLUC/HouseHireBundle/Lang/".$lang.".php", $enableCache, $cacheDir);
        
        
        $thisObject = new self();
        
        $thisObject->addPage("addImage", $thisObject, FALSE);
        $thisObject->addPage("addVideo", $thisObject, FALSE);
        $thisObject->addPage("delete", $thisObject, FALSE);
        $thisObject->addPage("setCurrent", $thisObject, FALSE);
        
        
        $thisObject->rooting($cacheDir); 
    }
}
