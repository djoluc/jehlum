<?php

namespace DJOLUC\HouseHireBundle\Controller\Backend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseDataSource.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
require_once 'App/Cache/StaticPageCache/StaticPageCacheManager.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';

/**
 * Description of HouseAddController
 *
 * @author djoluc
 */
class HouseAddController extends \App\Controller\BaseController {
    private $userDataSource, 
            $sessionManageController, 
            $houseDataSource;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->sessionManageController = new \DJOLUC\RegisterBundle\Controller\Frontend\SessionManageController();
        $this->houseDataSource = new \DJOLUC\HouseHireBundle\Model\HouseDataSource();
    }
    
    
    
    
    public function addAction(): string{
        
        $userRang = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang();
        $isModoOrMore = ($userRang >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND);
        
        $out = "";
        
        if($isModoOrMore){
            if(array_key_exists("sent", $_POST)){
                $houseName = filter_input(INPUT_POST, "name");
                $houseDescription = filter_input(INPUT_POST, "description");
                $houseOwnerMailOrPhone = filter_input(INPUT_POST, "owner", FILTER_SANITIZE_STRING);
                $houseLongitude = filter_input(INPUT_POST, "longitude", FILTER_SANITIZE_NUMBER_FLOAT);
                $houseLatitude = filter_input(INPUT_POST, "latitude", FILTER_SANITIZE_NUMBER_FLOAT);
                $hireType = filter_input(INPUT_POST, "hireType", FILTER_SANITIZE_NUMBER_INT);
                
                
                $houseOwnerId = 0;
                if($this->userDataSource->isMailUsed($houseOwnerMailOrPhone)){
                    $houseOwnerId = $this->userDataSource->getUserWithMail($houseOwnerMailOrPhone)->getUserId();
                }else{
                    //
                }
                
                
                if($houseOwnerId == 0){
                    $out = $this->displayPageAction($lang, INVALID_USER);
                }else{
                    if($this->houseDataSource->addHouse($houseName, $houseDescription, $houseOwnerId, $hireType, $houseLongitude, $houseLatitude, \time(), FALSE, 0)){
                        \header("Location: ../houses");
                    } else {
                        $out = $this->displayPageAction($lang, ACTION_ERROR);
                    }
                } 
            }
        }else{
            $this->throwException(NOT_ALOWED_ACTION);
        }
        
        
        return $out;
    }
    
    
    
    
    /**
     * {@ineritDoc}
     */
    public function displayPageAction($lang = "", $message = "") {
        parent::displayPageAction($lang);
        
        return $this->renderView([
            "title" => ADD_HOUSE, 
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", "", $lang), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter($lang), 
            "message" => $message
        ],
                "DJOLUC/HouseHireBundle/Views/Backend/houseAddView.php");
    }

    
    /**
     * {@ineritDoc}
     */
    public static function rooter($lang = "", $cacheDir = "Cache/") {
        parent::rooter($lang, $cacheDir);
        
        
         $thisObject = new self();
        
        if(\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() < \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND){
            $thisObject->throwException(NOT_ALOWED_ACTION);
        }
        
       
        
        $thisObject->addPage("add", $thisObject, FALSE);
        $thisObject->addPage("", $thisObject);
        
        
        
        $thisObject->rooting($cacheDir);
    }

}
