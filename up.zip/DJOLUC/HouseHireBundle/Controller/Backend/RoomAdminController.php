<?php

namespace DJOLUC\HouseHireBundle\Controller\Backend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseMediaDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/RoomDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/RoomPriceDataSource.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
require_once 'App/Cache/StaticPageCache/StaticPageCacheManager.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';
require_once 'DJOLUC/Helper/FileUploader.php';
require_once 'DJOLUC/Helper/fonct.php';

/**
 * Description of RoomAdminController
 *
 * @author djoluc
 */
class RoomAdminController extends \App\Controller\BaseController{
    private $userDataSource, 
            $sessionManageController, 
            $houseDataSource, 
            $houseMediaDataSource, 
            $roomDataSource, 
            $roomPriceDataSource, 
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->sessionManageController = new \DJOLUC\RegisterBundle\Controller\Frontend\SessionManageController();
        $this->houseDataSource = new \DJOLUC\HouseHireBundle\Model\HouseDataSource();
        $this->houseMediaDataSource = new \DJOLUC\HouseHireBundle\Model\HouseMediaDataSource();
        $this->roomDataSource = new \DJOLUC\HouseHireBundle\Model\RoomDataSource();
        $this->roomPriceDataSource = new \DJOLUC\HouseHireBundle\Model\RoomPriceDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    
    
    
    public function addRoomAction(){
        $isAjax = array_key_exists("c", $_GET)&&filter_input(INPUT_GET, "c")=="ajax";
        $out = Array(
            "result" => FALSE, 
            "message" => "".UNKNOW_ERROR.""
        );
        if(array_key_exists("sent", $_POST)){
            $houseId = $this->getPostInt("houseId");
            $roomName = $this->getPostString("name");
            $roomDescription = $this->getPostString("description");
            $roomNumb = $this->getPostInt("room_numb");
            $roomPrice = $this->getPostFloat("price");
            $priceUnit = $this->getPostInt("price_unit");
            $paymentPolicy = $this->getPostInt("payment_policy");
            $advanceNumb = $this->getPostInt("advance_numb");
            
            
            $newRoomId = $this->roomDataSource->addRoom($houseId, $roomName, $roomDescription, $roomNumb, $advanceNumb, $paymentPolicy, \time(), FALSE, 0);
            
            if($newRoomId > 0){
                $this->roomPriceDataSource->addRoomPrice($newRoomId, $roomPrice, $priceUnit, TRUE, \time());
                $out["result"] = TRUE;
            }
        }
        
        if($isAjax){
            $this->printPureJson($out);
        }else{
            \header("Location: ".$this->getRefererRequestUrl()."");
        }
    }
    
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
        
        print "ok";
    }
    
    

    public static function rooter($lang = "", bool $enableCache = false, $cacheDir = "Cache/") {
        parent::rooter("DJOLUC/HouseHireBundle/Lang/".$lang.".php", $enableCache, $cacheDir);
        
        
        $thisObject = new self();
        $thisObject->addPage("", $thisObject);
        $thisObject->addPage("addRoom", $thisObject, FALSE);
        
        
        $thisObject->rooting($cacheDir);
    }

}
