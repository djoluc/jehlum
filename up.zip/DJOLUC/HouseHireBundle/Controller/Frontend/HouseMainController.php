<?php

namespace DJOLUC\HouseHireBundle\Controller\Frontend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseMediaDataSource.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
require_once 'App/Cache/StaticPageCache/StaticPageCacheManager.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';

/**
 * Description of HouseMainController
 *
 * @author djoluc
 */
class HouseMainController extends \App\Controller\BaseController {
    private $userDataSource, 
            $sessionManageController, 
            $houseDataSource,
            $isModoOrMore, 
            $isMiniAdmOrMore;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->sessionManageController = new \DJOLUC\RegisterBundle\Controller\Frontend\SessionManageController();
        $this->houseDataSource = new \DJOLUC\HouseHireBundle\Model\HouseDataSource();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    
    public function loadHouseSearchPropositionAction(){
        if(array_key_exists("sent", $_POST)){
            $txt = filter_input(INPUT_POST, "search", FILTER_SANITIZE_STRING);
            $this->printPureJson($this->houseDataSource->loadHousePropostionAsArray($txt, 0, 10));
        }
    }
    
    
    public function loadSearchedHouseAction(){
        $out = Array();
        if(array_key_exists("sent", $_POST)){
            $txt = filter_input(INPUT_POST, "search", FILTER_SANITIZE_STRING);
            
            $houses = $this->houseDataSource->getHouses(0, 50, $txt);
            
            foreach ($houses AS $house){
                //$house = \DJOLUC\HouseHireBundle\Model\House::getEmpty();
                $out[count($out)] = Array(
                    "name" => $house->getName(), 
                    "houseId" => $house->getHouseId(), 
                    "principalMiniPicture" => $house->getPrincipalPictureMini(), 
                    "time" => $house->getTimeReference()
                );
            }
        }
        
        $this->printPureJson($out);
    }
    
    
    
    public function displayPageAction() {
        parent::displayPageAction();
        
        $currentHouseId = filter_input(INPUT_GET, "b", FILTER_SANITIZE_NUMBER_INT);
        $isCurrentHouseSet = array_key_exists("b", $_GET)&&!empty($_GET["b"]);
        $houseMediaDataSource = new \DJOLUC\HouseHireBundle\Model\HouseMediaDataSource();
        //$houseMediaDataSource->setAsCurrent(1, 1547399419);
        
        
        return $this->renderView([
                    "title" => HOUSES, 
                    "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", ""),
                    "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
                    "houses" => $this->houseDataSource->getHouses(0, 50, ""), 
                    "isCurrentHouseExist" => $isCurrentHouseSet, 
                    "currentHouse" => $this->houseDataSource->getHouse($currentHouseId), 
                    "isModoOrMore" => $this->isModoOrMore, 
                    "isMiniAdmOrMore" => $this->isMiniAdmOrMore
                ], 
                            "DJOLUC/HouseHireBundle/Views/Frontend/houseMainView.php");
    }

    public static function rooter($lang = "", bool $enableCache = false, $cacheDir = "Cache/") {
        parent::rooter("DJOLUC/HouseHireBundle/Lang/".$lang.".php", $enableCache, $cacheDir);
        
        
        $thisObject = new self();
        
        $langLink = "DJOLUC/HouseHireBundle/Lang/".$lang.".php";
        
        $thisObject->addPage("", $thisObject, TRUE, Array());
        $thisObject->addPage("loadHouseSearchProposition", $thisObject, FALSE, Array());
        $thisObject->addPage("loadSearchedHouse", $thisObject, FALSE, Array());
        
        
        $thisObject->rooting($cacheDir);
    }
}
