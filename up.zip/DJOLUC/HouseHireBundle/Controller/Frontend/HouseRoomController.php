<?php

namespace DJOLUC\HouseHireBundle\Controller\Frontend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/HouseMediaDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/RoomDataSource.php';
require_once 'DJOLUC/HouseHireBundle/Model/Frontend/RoomPriceDataSource.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
require_once 'App/Cache/StaticPageCache/StaticPageCacheManager.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';
require_once 'DJOLUC/Helper/FileUploader.php';
require_once 'DJOLUC/Helper/fonct.php';

/**
 * Description of HouseRoomController
 *
 * @author djoluc
 */
class HouseRoomController extends \App\Controller\BaseController {
    private $userDataSource, 
            $sessionManageController, 
            $houseDataSource, 
            $houseMediaDataSource, 
            $roomDataSource, 
            $userId, 
            $isModoOrMore, 
            $isMiniAdmOrMore;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->sessionManageController = new \DJOLUC\RegisterBundle\Controller\Frontend\SessionManageController();
        $this->houseDataSource = new \DJOLUC\HouseHireBundle\Model\HouseDataSource();
        $this->houseMediaDataSource = new \DJOLUC\HouseHireBundle\Model\HouseMediaDataSource();
        $this->roomDataSource = new \DJOLUC\HouseHireBundle\Model\RoomDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isModoOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND;
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    
    
    
    public function displayPageAction($lang = "") {
        parent::displayPageAction($lang);
        
        $currentRoomId = filter_input(INPUT_GET, "b", FILTER_SANITIZE_NUMBER_INT);
        $isCurrentRoomSet = array_key_exists("b", $_GET)&&!empty($_GET["b"]);
        //$roomMediaDataSource = new \DJOLUC\HouseHireBundle\Model\HouseMediaDataSource();
        //$houseMediaDataSource->setAsCurrent(1, 1547399419);
        
        
        return $this->renderView([
                    "title" => HOUSES, 
                    "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", ""),
                    "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
                    "houses" => $this->houseDataSource->getHouses(0, 50, ""), 
                    "isCurrentRoomExist" => $isCurrentRoomSet, 
                    "currentRoom" => $this->roomDataSource->getRoom($currentRoomId), 
                    "isModoOrMore" => $this->isModoOrMore, 
                    "isMiniAdmOrMore" => $this->isMiniAdmOrMore
                ], 
                            "DJOLUC/HouseHireBundle/Views/Frontend/roomMainView.php");
    }
    
    
    
    

    public static function rooter($lang = "", bool $enableCache = false, $cacheDir = "Cache/") {
        parent::rooter("DJOLUC/HouseHireBundle/Lang/".$lang.".php", $enableCache, $cacheDir);
        
        
        
        $thisObject = new self();
        $thisObject->addPage("", $thisObject);
        
        
        
        $thisObject->rooting($cacheDir);
    }

}
