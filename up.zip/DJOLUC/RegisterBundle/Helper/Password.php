<?php 
namespace DJOLUC\RegisterBundle\Helper;

class Password
{
    private $salt = 'zUl8*ryP$_';
	private static $password;
        private $hashPassword;
                function __construct($password = "")
	{
		$this::$password = $this->salt."".$password;
		// $this->hashPassword = password_hash(md5($this::$password), 1);
		$this->hashPassword = \password_hash($this::$password, PASSWORD_DEFAULT);
	}
	public function getHashPassword()
	{
		$this->hashPassword = \password_hash($this::$password, PASSWORD_DEFAULT);
		
		return $this->hashPassword;		
	}
		
	public function isPassMatch($password, $hash)
	{
           return \password_verify($this->salt."".$password, $hash);
	}
	
	public function setPassword($password = ""):Password
	{
            $password = $this->salt."".$password;
		$this::$password = $password;
		
		$this->hashPassword = \password_hash($this::$password, PASSWORD_DEFAULT);
                
           return $this; 
	}
}