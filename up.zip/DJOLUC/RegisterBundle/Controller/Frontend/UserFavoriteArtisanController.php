<?php

namespace DJOLUC\RegisterBundle\Controller\Frontend;
require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserFavoriteArtisanDataSource.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';

/**
 * Description of UserFavoriteArtisanController
 *
 * @author djoluc
 */
class UserFavoriteArtisanController extends \App\Controller\BaseController {
    private $userFavoriteArtisanDataSource, 
            $userDataSource, 
            $userId, 
            $artisanUserId, 
            $first, 
            $numb;
     
    
    
    public function __construct() {
        $this->userFavoriteArtisanDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserFavoriteArtisanDataSource();
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->artisanUserId = array_key_exists("artisanUserId", $_GET)?filter_input(INPUT_GET, "artisanUserId"):0;
        $this->first = array_key_exists("first", $_GET)?filter_input(INPUT_GET, "first"):0;
        $this->numb = array_key_exists("numb", $_GET)?filter_input(INPUT_GET, "numb"):10;
    }
    
    
    
    public function addUserFavoriteArtisan(){
        
        if($this->userId == $this->artisanUserId){
            $this->throwException("Vous ne pouvez pas être votre propre favorie");
        }
        
        $this->userFavoriteArtisanDataSource->addFavorite($this->userId, $this->artisanUserId, \time());
        
        if(array_key_exists("HTTP_REFERER", $_SERVER)){
                header("Location: ".$_SERVER['HTTP_REFERER']."");
            }
    }
    
    public function removeFavorite(){
        
        
        $this->userFavoriteArtisanDataSource->deleteUserFavoriteArtisan($this->userId, $this->artisanUserId);
        
        
        if(array_key_exists("HTTP_REFERER", $_SERVER)){
                header("Location: ".$_SERVER['HTTP_REFERER']."");
            }
    }
    
    
    public function displayPageAction() {
        parent::displayPageAction();
        
        
        $artisanUsers = $this->userFavoriteArtisanDataSource->getUserFavoriteArtisans($this->userId, $this->first, $this->numb);
        
        return $this->renderView([
            "header"=> \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(),
            "artisanUsers"=>$artisanUsers,
            "userTotalNumb"=>$this->userFavoriteArtisanDataSource->getUserFavoriteArtisansNumb($this->userId),
            "numb"=>$this->numb
        ], 
                "DJOLUC/RegisterBundle/Views/Frontend/userFavoriteArtisanView.php");
        
    }
    
    

    public static function rooter() {
        parent::rooter();
        
        $thisClass = new UserFavoriteArtisanController();
        
        if(array_key_exists("add", $_GET)){
            $thisClass->addUserFavoriteArtisan();
        }else if(array_key_exists("delete", $_GET)){
            $thisClass->removeFavorite();
        }else{
            print $thisClass->displayPageAction();
        }
        
    }   
}
