<?php

namespace DJOLUC\RegisterBundle\Controller\Frontend;

/**
 * Description of UserProfilEditController
 *
 * @author djoluc
 */
class UserProfilEditController extends \App\Controller\BaseController {
    private $userDataSource, 
            $artisanUserDataSource, 
            $userProfilPictureDataSource, 
            $userPasswordDataSource, 
            $userId, 
            $isProfilAutor,
            $isModoAdmOrMore, 
            $isMiniAdmOrMore;
    
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->artisanUserDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ArtisanUserDataSource();
        $this->userProfilPictureDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ProfilPictureDataSource();
        $this->userId = array_key_exists("uid", $_GET)?filter_input(INPUT_GET, "uid"):\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isProfilAutor = $this->userId == \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $this->isModoAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $this->userPasswordDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserPasswordDataSource();
    }
    
    
    public function editAction(){
        
        if(!$this->isProfilAutor){
            $this->throwException("Action non authorisé");
        }
        
        $out = Array(
            "result"=>TRUE,
            "message"=>"Profile edited!"
        );
        
        if(array_key_exists("sent", $_POST)){
            $userNom = filter_input(INPUT_POST, "nom");
            $userPrenoms = filter_input(INPUT_POST, "prenom");
            $userBornDate = \DJOLUC\Helper\php\DateManager::getTimestampFromDateUsingDateTime(filter_input(INPUT_POST, "dayNaiss"), filter_input(INPUT_POST, "monthNaiss"), filter_input(INPUT_POST, "yearNaiss"));
            $userLieuNaiss = filter_input(INPUT_POST, "naissLieu");
            $userGenre = filter_input(INPUT_POST, "genre");
            $userPhone = filter_input(INPUT_POST, "phone");
            $userProfession = filter_input(INPUT_POST, "profession");
            $userCountry = filter_input(INPUT_POST, "country");
            $userTown = filter_input(INPUT_POST, "town");
            
            
            //update simple user 
            $result = $this->userDataSource->completeUserProfile($this->userId, $userNom, $userPrenoms, $userBornDate, $userLieuNaiss, $userGenre, $userPhone, $userProfession, $userCountry, $userTown, "");
            if(!$result){
                $out["result"] = false;
            }
        }
        
        if(!$out["result"]){
            $out["message"] = "Error when editing your profile. Please try again.";
        }
        
        if(array_key_exists("ajax", $_GET)){
            $this->printDjolucJson($out);
        }else{
            print $this->displayPageAction($out["message"]);
        }
        
    }
    
    
    public function editPassAction(){
        if(!$this->isProfilAutor){
            $this->throwException("Action non authorisé");
        }
        
        $out = Array(
            "result"=>FALSE,
            "message"=>"Error when editing your password."
        );
        
        if(array_key_exists("sent", $_POST)){
            $newPass = filter_input(INPUT_POST, "newPass");
            $newPassConf = filter_input(INPUT_POST, "newPassConf");
            $currentPass = filter_input(INPUT_POST, "currentPass");
            
            $password = new \DJOLUC\RegisterBundle\Helper\Password($newPass);
            
            if($password->isPassMatch($currentPass, $this->userPasswordDataSource->getUserCurrentPassword($this->userId)->getUserPassword())){
                $userPasswords = $this->userPasswordDataSource->getUserPasswords($this->userId);
                $isOldPass = false;
                foreach ($userPasswords as $userPassword){
                    if($password->isPassMatch($newPass, $userPassword->getUserPassword())){
                        $isOldPass = TRUE;
                    }
                }
            
                if($isOldPass){
                    $out["resutl"] = false;
                    $out["message"] = "You have already use this password. Please choose other password for security purpose.";
                }else{
                    if($newPass == $newPassConf){
                        if($this->userPasswordDataSource->addUserPassword($password->setPassword($newPass)->getHashPassword(), time(), $this->userId)){
                            $out["resutl"] = TRUE;
                            $out["message"] = "Password edited!";
                        }
                    }else{
                        $out["resutl"] = TRUE;
                        $out["message"] = "Passwords don't match!";
                    }
                    
                }
            }else{
                $out["resutl"] = false;
                $out["message"] = "Wrong password. Try again please.";
            } 
        }
        
        
        if(array_key_exists("aja", $_GET)){
            $this->printDjolucJson($out);
        }else{
            print $this->displayPageAction("", $out["message"]);
        }
        
    }

    
    public function displayPageAction($resultMessage = "", $passResultMessage = "") {
        parent::displayPageAction();
        
        $isArtisanUser = $this->userDataSource->isArtisan($this->userId);
        
        require_once 'App/data/CountriesArrayData.php';
        
        return $this->renderView([
            "resultMessage"=>$resultMessage,
            "passResultMessage"=>$passResultMessage,
            "header"=> \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(),
            "user"=>$this->userDataSource->getUser($this->userId), 
            "profilPictures"=>$this->userProfilPictureDataSource->getUserProfilPictures($this->userId), 
            "isArtisanUser"=>$isArtisanUser,
            "artisanUserDataSource"=>$this->artisanUserDataSource, 
            "isProfilAutor"=>$this->isProfilAutor, 
            "isMiniAdminOrMore"=>$this->isMiniAdmOrMore, 
            "userId"=>$this->userId, 
            "isArtisan"=> $this->userDataSource->isArtisan($this->userId), 
            "artisanUser"=>$this->artisanUserDataSource->getArtisanUser($this->userId), 
            "countriesData"=>$CountryArrayData, 
            "countriesWithCode"=>$CountryArrayWithPhoneCode
            
        ], 
                "DJOLUC/RegisterBundle/Views/Frontend/profilEditView.php"); 
    }
    
    

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        
        $thisObject = new self();
        
        $thisObject->addPage("edit", $thisObject, FALSE);
        $thisObject->addPage("editPass", $thisObject, FALSE);
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }
}
