<?php

namespace DJOLUC\RegisterBundle\Controller\Frontend;

/**
 * Description of UserProfilController
 *
 * @author djoluc
 */
class UserProfilController extends \App\Controller\BaseController {
    private $userDataSource, 
            $artisanUserDataSource, 
            $userProfilPictureDataSource, 
            $userId, 
            $isProfilAutor,
            $isModoAdmOrMore, 
            $isMiniAdmOrMore;
    
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->artisanUserDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ArtisanUserDataSource();
        $this->userProfilPictureDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ProfilPictureDataSource();
        $this->userId = array_key_exists("c", $_GET)?$this->getGetInt("c"):\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isProfilAutor = $this->userId == \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $this->isModoAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
    }
    
    
    public function setCurrentPicAction(){
        $this->isProfilAutor = $this->getGetInt("d") == \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        
        if(!$this->isProfilAutor && !$this->isMiniAdmOrMore){
            $this->throwException("Vous ne pouvez pas ajouter des photo à ce profil");
        }
        
        $pictureId = $this->getGetInt("c");
        $this->userId = $this->getGetInt("d");
        
        $this->userProfilPictureDataSource->setAsCurrent($pictureId, $this->userId);
        
        if(array_key_exists("HTTP_REFERER", $_SERVER)){
                header("Location: ".$_SERVER['HTTP_REFERER']."");
            }
    }
    
    
    public function deletePicAction(){
        $this->isProfilAutor = $this->getGetInt("d") == \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        
        if(!$this->isProfilAutor && !$this->isMiniAdmOrMore){
            $this->throwException("Vous ne pouvez pas ajouter des photo à ce profil");
        }
        
        $pictureId = $this->getGetInt("c");
        $this->userId = $this->getGetInt("d");
        
        $this->userProfilPictureDataSource->removePicture($pictureId, $this->userId);
        
        if(array_key_exists("HTTP_REFERER", $_SERVER)){
                header("Location: ".$_SERVER['HTTP_REFERER']."");
            }
    }
    
    
    public function addPicAction(){
        if(!$this->isProfilAutor){
            $this->throwException("Vous ne pouvez pas ajouter des photo à ce profil");
        }
        $out = Array(
            "result"=>TRUE,
            "message"=>"Transfère réussit!"
        );
        
        if(array_key_exists("avatar", $_FILES)){
            require_once 'DJOLUC/Helper/php/fonct.php';
            $fileUploader = new \DJOLUC\Helper\php\FileUploader("avatar", "avatar/".$this->userId."", $this->userId, "image", "own_name", "".time()."");
            
            if($fileUploader->upload(false)){
                miniature($fileUploader->getFileDir(), 150, $fileUploader->getFileDir()."/mini", $fileUploader->getFileName());
                $this->userProfilPictureDataSource->addUserProfilPicture($this->userId, $fileUploader->getFileName());
            } else {
                $out["result"] = FALSE;
            }
            
            
        }else{
            $out["result"] = FALSE;
        }
        
        if(!$out["result"]){
            $out["message"] = "erreur lors de l'envoie du fichier";
        }
        
        if(array_key_exists("ajax", $_GET)){
            $this->printDjolucJson($out);
        }else{
            
        if(array_key_exists("HTTP_REFERER", $_SERVER)){
                header("Location: ".$_SERVER['HTTP_REFERER']."");
            }
        }
    }
    
    
    public function displayPageAction() {
        parent::displayPageAction();
        
        if(array_key_exists("b", $_GET) && $this->getGetInt("b")){
            $this->userId = $this->getGetInt("b");
        }
        
        return $this->renderView([
            "header"=> \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(),
            "user"=>$this->userDataSource->getUser($this->userId), 
            "profilPictures"=>$this->userProfilPictureDataSource->getUserProfilPictures($this->userId), 
            "isProfilAutor"=>$this->isProfilAutor, 
            "isMiniAdminOrMore"=>$this->isMiniAdmOrMore, 
            "userId"=>$this->userId
            
        ], 
                "DJOLUC/RegisterBundle/Views/Frontend/userProfilView.php");
    }
    
    

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("setCurrentPic", $thisObject, FALSE);
        $thisObject->addPage("deletePic", $thisObject, FALSE);
        $thisObject->addPage("addPic", $thisObject, FALSE);
        $thisObject->addPage("", $thisObject);
        
        
        $thisObject->rooting($cacheDir);
        
        /*$thisClass = new \DJOLUC\RegisterBundle\Controller\Frontend\UserProfilController();
        
        if(array_key_exists("setCurrentPic", $_GET)){
            $thisClass->setAsCurrentAction();
        }else if(array_key_exists("deletePic", $_GET)){
            $thisClass->deletePictureAction();
        }else if(array_key_exists("addPic", $_GET)){
            $thisClass->addUserProfilPic();
        }else{
            print $thisClass->displayPageAction();
        }*/
    }

}
