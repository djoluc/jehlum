<?php

namespace DJOLUC\RegisterBundle\Controller\Frontend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/ArtisanUserNoteDataSource.php';

/**
 * Description of ArtisanNoteController
 *
 * @author djoluc
 */
class ArtisanNoteController extends \App\Controller\BaseController {
    private $artisanUserNoteDataSource, 
            $userDataSource, 
            $userId, 
            $artisanUserId, 
            $note;
    
    
    public function __construct() {
        $this->artisanUserNoteDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ArtisanUserNoteDataSource();
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->artisanUserId = array_key_exists("artisanUserId", $_GET)?filter_input(INPUT_GET, "artisanUserId"):0;
        $this->note = array_key_exists("note", $_GET)?filter_input(INPUT_GET, "note"):0;
    }
    
    
    
    public function displayPageAction() {
        parent::displayPageAction();
        
        if($this->userId <= 0){
            $this->throwException("Veillez vous connecter pour noter l'artisans");
        }
        
        if($this->artisanUserId <= 0){
            $this->throwException("Une erreur s'est produit lors de l'opération");
        }
        
        if($this->artisanUserId == $this->userId){
            $this->throwException("Vous ne pourvez pas vous noter vous même");
        }
        
        $this->artisanUserNoteDataSource->addUserNote($this->userId, $this->artisanUserId, $this->note, time());
        
        
        if(array_key_exists("HTTP_REFERER", $_SERVER)){
                header("Location: ".$_SERVER['HTTP_REFERER']."");
            }
    }

    public static function rooter() {
        parent::rooter();
        
        $thisClass = new ArtisanNoteController();
        
        $thisClass->displayPageAction();
    }
}
