<?php

namespace DJOLUC\RegisterBundle\Controller\Frontend;
/**
 * Description of ForgotPasswordController
 *
 * @author djoluc
 */
class ForgotPasswordController extends \App\Controller\BaseController {
    private $userDataSource, 
            $artisanUserDataSource, 
            $userProfilPictureDataSource, 
            $userPasswordDataSource, 
            $userId, 
            $isProfilAutor,
            $isModoAdmOrMore, 
            $isMiniAdmOrMore;
    
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->artisanUserDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ArtisanUserDataSource();
        $this->userProfilPictureDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ProfilPictureDataSource();
        $this->userId = array_key_exists("uid", $_GET)?filter_input(INPUT_GET, "uid"):\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isProfilAutor = $this->userId == \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        $this->isMiniAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $this->isModoAdmOrMore = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() >= \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MINI_ADM_RANG;
        $this->userPasswordDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserPasswordDataSource();
    }
    
    public function sendCodeMailAction($code, $email):bool{
        $nom_site = "Artisan d'ici";
        $adresse_site = "admin@artisandici.com";
        $conf_pass = $code;
        
        $passage_ligne = "\n";
        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $email)) // On filtre les serveurs qui rencontrent des bogues.
	{
            $passage_ligne = "\r\n";
        }else{
            $passage_ligne = "\n";
	}
	//=====Déclaration des messages au format texte et au format HTML.
	$message_txt = "Veuillez utiliser ce code pour changer votre mot de passe: ".$conf_pass."";
	$message_html='<!DOCTYPE html>
			<html>
                            <head>
                                <title>Inscription sur '.$nom_site.'</title>
                            </head>
                            <body style="font-size: 18px; color: rgba(0, 0, 0, 0.7); border: 5px solid cyan; width: 50vw; margin: auto; padding: 10px;">
                                <h1 style="color: cadetblue; text-align: center;">Artisan d\'ici</h1>
                                <div>Vous recevez ce mail suite à vore demande de changement de mot de passe sur '.$nom_site.'<br/><br/>
                                    Pour changer votre mot de passe, veilllez utiliser le code suivant:
                                    <br/><b>'.$conf_pass.'</b> <br/>comme indiqué.</div>
                                <p>Si vous avez des soucies, contactez nous!</p>
                            </body>
                        </html>';
	//==========
				
	//=====Création de la boundary
	$boundary = "-----=".md5(rand());
	//==========
				
	//=====Définition du sujet.
	$sujet = "Inscription sur artisandici.com";
	//=========
				
	//=====Création du header de l'e-mail.
	$header = "From: \"".$nom_site."\"<".$adresse_site.">".$passage_ligne;
	$header.= "Reply-to: \"".$nom_site."\" <".$adresse_site.">".$passage_ligne;
	$header.= "MIME-Version: 1.0".$passage_ligne;
	$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"".$boundary."\" ".$passage_ligne."";
	//==========
				
	//=====Création du message.
	$message = $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format texte.
	$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_txt.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format HTML
	$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_html.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	//==========
				
	//=====Envoi de l'e-mail.
	
        mail($email,$sujet,$message,$header);
        
        return TRUE;
    }
    
    
    public function firstStepAction(){
        $out = array(
            "result"=>false,
            "message"=>"Error"
    );
        if(array_key_exists("sent", $_POST)){
            $email = filter_input(INPUT_POST, "email");
            if($this->userDataSource->isMailUsed($email)){
                
                $confCode = rand(10000000, 99999999)."";
                
                if($this->userDataSource->updateUserConfPass($confCode, $this->userDataSource->getUserWithMail($email)->getUserId())){
                    
                    if($this->sendCodeMailAction($confCode, $email)){
                        $out["result"] = TRUE;
                        $out["message"] = "Réussit!";
                        
                        return $this->secondStepPageAction($email);
                        
                    }
                    
                }else{
                    $out["result"] = FALSE;
                    $out["message"] = "Error";
                }
                
            }else{
                $out["message"] = "There is no account created with this email.";
            }
        }
        
        if(array_key_exists("ajax", $_GET)){
                $this->printDjolucJson($out);
            }

            
        if(!$out["result"]){
            print $this->displayPageAction($out["message"]);
        }
    }
    
    
    
    public function secondStepPageAction($email, $errorInfo = ""){
        
        require_once 'App/data/CountriesArrayData.php';
        
        return $this->renderView([
            "header"=> \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(),
            "errorInfo"=>$errorInfo, 
            "email"=>$email
        ], 
                "DJOLUC/RegisterBundle/Views/Frontend/forgotPassSecondStepView.php"); 
    }
    
    
    public function secondStepAction(){
        
        $out = array(
            "result"=>false,
            "message"=>"Erreur"
        );
        
        if(array_key_exists("sent", $_POST)){
            $email = filter_input(INPUT_POST, "email");
            $code = filter_input(INPUT_POST, "code");
            
            if($this->userDataSource->getUserWithMail($email)->getUserInscriptConfPass() == $code){
                $out["result"] = TRUE;
                $code = $confCode = rand(10000000, 99999999)."";
                $this->userDataSource->updateUserConfPass($code, $this->userDataSource->getUserWithMail($email)->getUserId());
                
                print $this->stepThreePageAction($email, $code, "");
                
            }else{
                $out["message"] = "Le code est incorrect";
            }
        }
        
        if(!$out["result"]){
            print $this->secondStepPageAction($email, $out["message"]);
        }
    }
    
    
    public function stepThreeAction(){
        
        $out = array(
            "result"=>false,
            "message"=>"Erreur"
        );
        
        
        if(array_key_exists("sent", $_POST)){
            $newPass = filter_input(INPUT_POST, "password");
            $newPassConf = filter_input(INPUT_POST, "password_conf");
            $email = filter_input(INPUT_POST, "email");
            $code = filter_input(INPUT_POST, "code");
            
            if(!$this->userDataSource->getUserWithMail($email)->getUserInscriptConfPass() == $code){
                $this->throwException(UNABLE_PAGE);
            }
            
            
            if($newPass == $newPassConf){
                if(strlen($newPass) < 8){
                    $out["message"] = "Password so short. 8 digit at least.";
                }else{
                    
                    $password = new \DJOLUC\RegisterBundle\Helper\Password($newPass);
                    $user = $this->userDataSource->getUserWithMail($email);
            
                    
                    $userPasswords = $this->userPasswordDataSource->getUserPasswords($user->getUserId());
                    $isOldPass = false;
                    foreach ($userPasswords as $userPassword){
                        if($password->isPassMatch($newPass, $userPassword->getUserPassword())){
                            $isOldPass = TRUE;
                        }
                    }
                    
                    if($isOldPass){
                        $out["result"] = false;
                        $out["message"] = "You have already use this password. Please create another password, not an old.";
                    }else{
                        if($this->userPasswordDataSource->addUserPassword($password->setPassword($newPass)->getHashPassword(), time(), $user->getUserId())){
                            $out["resutl"] = TRUE;
                            $out["message"] = "password edited!";
                            header("Location: ".SITE_ROOT."authenticate");
                        }
                    
                    }
                }
                
            }else{
                $out["message"] = "Passwords don't match.";
            }
            
            
            
            if(!$out["result"]){
                return $this->stepThreePageAction($email, $code, $out["message"]);
            }
        }
        
    }
    
    
    public function stepThreePageAction($email, $code, $errorInfo){
        require_once 'App/data/CountriesArrayData.php';
        
        return $this->renderView([
            "header"=> \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(),
            "errorInfo"=>$errorInfo, 
            "email"=>$email, 
            "code"=>$code
        ], 
                "DJOLUC/RegisterBundle/Views/Frontend/forgotPassStepThreeView.php"); 
    }
    
    
    
    public function settingPassForOnlyMailRegisteredUser(){
        $getUserId = $this->getGetInt("c");
        $code = $this->getGetString("d");
        $user = $this->userDataSource->getUser($getUserId);
        
        if(md5($user->getUserInscriptConfPass()) == $code){
            return $this->stepThreePageAction($user->getUserMail(), $code, "");
        }else{
            $this->throwException(UNABLE_ACTION);
        }
    }
    
    
    public function displayPageAction($errorInfo = "") {
        parent::displayPageAction();
        
        
        require_once 'App/data/CountriesArrayData.php';
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(),
            "errorInfo" => $errorInfo           
        ], 
                "DJOLUC/RegisterBundle/Views/Frontend/forgotPasswordView.php"); 
    }
    
    

    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("firstStep", $thisObject, FALSE);
        $thisObject->addPage("secondStep", $thisObject, FALSE);
        $thisObject->addPage("stepThree", $thisObject, FALSE);
        $thisObject->addPage("noPassUserConfirm", $thisObject, FALSE);
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
        
        /*$thisClass = new ForgotPasswordController();
        
        if($thisClass->userId > 0){
            $thisClass->throwException("Vous ne pouvez pas accéder à la page que vous demandez");
        }
        
        if(array_key_exists("firstStep", $_GET)){
            $thisClass->firstStepAction();
        }else if(array_key_exists("secondStep", $_GET)){
            $thisClass->secondStepAction();
        }else if(array_key_exists("stepThree", $_GET)){
            $thisClass->stepThreeAction();
        }else{
            print $thisClass->displayPageAction();
        }*/
    }
}
