<?php

namespace DJOLUC\RegisterBundle\Controller\Frontend;

require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/User.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserPasswordDataSource.php';

use DJOLUC\RegisterBundle\Model\Frontend;

/**
 * Description of SessionManageController
 *
 * @author djoluc
 */
class SessionManageController {
    const SESSION_USER_ID = "user_id";
    const SESSION_USER_MAIL = "user_mail";
    const SESSION_USER_RANG = "user_rang";
    const SESSION_USER_TOKEN = "access_token";
    
    const COOKIE_USER_MAIL = "cookie_user_mail";
    const COOKIE_USER_PASS = "cookie_user_pass";
    
    private $token;
    
    public function __construct() {
        $this->token = filter_input(INPUT_GET, "token");
    }

    
    
    
    public static function createUserMailSession($email, $remember){
        $userDataSource = new Frontend\UserDataSource();
        $user = $userDataSource->getUserWithMail($email);
        if($user->getUserId() == 0){
            $user = $userDataSource->getUserWithPhone($email);
        }
        $_SESSION[SessionManageController::SESSION_USER_ID] = $user->getUserId() ;
        $_SESSION[SessionManageController::SESSION_USER_MAIL] = $email;
        $_SESSION[SessionManageController::SESSION_USER_RANG] = $user->getUserRang();
        $_SESSION[SessionManageController::SESSION_USER_TOKEN] = bin2hex(openssl_random_pseudo_bytes(24));
        
        
        
        if($remember){
            $userPasswordDataSource = new Frontend\UserPasswordDataSource();
            $durecookies=\time()+365*24*60*60;
            \setcookie(SessionManageController::COOKIE_USER_MAIL, $user->getUserMail(), $durecookies, SITE_ROOT);
            \setcookie(SessionManageController::COOKIE_USER_PASS, $userPasswordDataSource->getUserCurrentPassword($user->getUserId())->getUserPassword(), $durecookies, SITE_ROOT);
        }
        
        $userDataSource->updateUserStatus($user->getUserId());
    }
    
    
    
    public static function restoreUserSession(){
        $userMail = \filter_input(INPUT_COOKIE, SessionManageController::COOKIE_USER_MAIL, FILTER_SANITIZE_STRING);
        $userPass = \filter_input(INPUT_COOKIE, SessionManageController::COOKIE_USER_PASS, FILTER_SANITIZE_STRING);
        
        if(!empty($userMail)){
            $userDataSource = new Frontend\UserDataSource();
            $userPasswordDataSource = new Frontend\UserPasswordDataSource();
            $userId = $userDataSource->getUserWithMail($userMail)->getUserId();
            if($userPasswordDataSource->getUserCurrentPassword($userId)->getUserPassword() == $userPass){
                SessionManageController::createUserMailSession($userMail, false);
                $userDataSource->updateUserStatus($userId);
            }
        }
    }
    
    public static function isSessionTokenMatch():bool{
        $str1 = filter_input(INPUT_GET, "c", FILTER_SANITIZE_STRING);
        $str2 = $_SESSION[SessionManageController::SESSION_USER_TOKEN];
        
        if(strlen($str1) != strlen($str2)) {
            
            return false;
            
        } else {
            
            $res = $str1 ^ $str2;
            $ret = 0;
            for($i = strlen($res) - 1; $i >= 0; $i--){
                $ret |= ord($res[$i]);
            }
            
            return !$ret;
        }
    }


    
    public static function deconnectUser($userId, $redirect = false){
        if(!SessionManageController::isSessionTokenMatch()){
            throw new \Exception("Opération impossible");
        }
        
        $userDataSource = new Frontend\UserDataSource();
        $userDataSource->updateUserStatus($userId, FALSE);
        
        $_SESSION = array();
        
        if(\session_destroy()){
            $userMail = \filter_input(INPUT_COOKIE, SessionManageController::COOKIE_USER_MAIL, FILTER_SANITIZE_STRING);
            $userPass = \filter_input(INPUT_COOKIE, SessionManageController::COOKIE_USER_PASS, FILTER_SANITIZE_STRING);
        
            if(!empty($userMail)){
                \setcookie(SessionManageController::COOKIE_USER_MAIL, "", -1, SITE_ROOT);
                \setcookie(SessionManageController::COOKIE_USER_PASS, "", -1, SITE_ROOT);
            }
        }
        
        if($redirect){
            \header('Location: ../../', true);
        }
    }
}
