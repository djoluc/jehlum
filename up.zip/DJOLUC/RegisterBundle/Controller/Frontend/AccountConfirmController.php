<?php

namespace DJOLUC\RegisterBundle\Controller\Frontend;

use App\Controller;

/**
 * Description of AccountConfirmController
 *
 * @author djoluc
 */
class AccountConfirmController extends Controller\BaseController {
    private $answerArray = Array(
        "result"=>false,
        "validCode"=>false,
        "message"=>""
    );
    
    private $resendAswer = Array(
        "result"=>true,
        "message"=>"code sent"
    );
    
    private function checkCodeAndConfirme($code){
        $userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $userId = $_SESSION[SessionManageController::SESSION_USER_ID];
        
        if($userDataSource->getUser($userId)->getUserInscriptConfPass() == $code.""){
            $this->answerArray["validCode"] = true;
            
            if($userDataSource->activateUserAccount($userId)){
                $userDataSource->clearUserConfInscriptPass($userId);
                $this->answerArray["result"] = true;
                if($userDataSource->isArtisan($userId)){
                    $pageDataSource = new \DJOLUC\PageBundle\Model\Frontend\PageDataSource();
                    $pageDataSource->addUserPage($userId, "", "");
                }
            }else{
                $this->answerArray["message"] = "Error when activating your account, please try again.";
            }
        }else{
            $this->answerArray["message"] = "Invalide code. Please try again";
        }
    }
    
    
    
    public function confirmCodeAction(){
        
        $code = filter_input(INPUT_POST, "code");
        
        $this->checkCodeAndConfirme($code);
        
        if(!(array_key_exists("c", $_GET) && $this->getGetString("c") == "ajax")){
            if($this->answerArray["result"]){
                header("Location: ../");
            }else{
                header("Location: ../accountConfirm");
            }
        }else{
           print "|". json_encode($this->answerArray)."|"; 
        }
    }
    
    public function resendAction(){
        $newCode = rand(10000000, 99999999)."";
        $userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $registerUserController = new RegisterUserController();
        $userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
        
        $userDataSource->updateUserConfPass($newCode, $userId);
        $registerUserController->sendCodeMailAction($newCode, $userDataSource->getUser($userId)->getUserMail());
        
        if(!(array_key_exists("c", $_GET) && $this->getGetString("c") == "ajax")){
            header("Location: ../accountConfirm");
        }else{
           print "|". json_encode($this->resendAswer)."|"; 
        }
    }
    
    /**
     * {@inheritdoc}
     */
    public function displayPageAction(){
        
        $userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $userId = $_SESSION[SessionManageController::SESSION_USER_ID];
        
        $userMail = $userDataSource->getUser($userId)->getUserMail();
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(), 
            "userMail" => $userMail
        ], 
                'DJOLUC/RegisterBundle/Views/Frontend/accountConfirmView.php');
    }
    
    /**
     * {@inheritdoc}
     */
    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        if(!isset($_SESSION[SessionManageController::SESSION_USER_ID]) || $_SESSION[SessionManageController::SESSION_USER_ID] <= 0){
            throw new \Exception(UNABLE_PAGE);
        }
        
        $userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $userId = $_SESSION[SessionManageController::SESSION_USER_ID];
        
        if($userDataSource->getUser($userId)->getUserConfInscript()){
            
            throw new \Exception(UNABLE_PAGE);
        }
        
        
        $thisObject = new self();
        
        $thisObject->addPage("confirmCode", $thisObject, FALSE);
        $thisObject->addPage("resend", $thisObject, FALSE);
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }
}
