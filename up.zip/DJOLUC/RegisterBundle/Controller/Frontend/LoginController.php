<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DJOLUC\RegisterBundle\Controller\Frontend;

use DJOLUC\RegisterBundle\Model\Frontend;
use DJOLUC\RegisterBundle\Helper;

/**
 * Description of LoginController
 *
 * @author djoluc
 */
class LoginController extends \App\Controller\BaseController{
    
    private $loginResult = Array(
        "result"=>false,
        "emailExist"=>false,
        "emailMessage"=>"",
        "passwordMatch"=>false,
        "passwordMessage"=>""
    );


    public function loginAction(){
        
        if(isset($_SESSION[SessionManageController::SESSION_USER_ID]) && $_SESSION[SessionManageController::SESSION_USER_ID] > 0){
            throw new \Exception(UNABLE_PAGE);
        }
        
        
        
        $email = filter_input(INPUT_POST, "mail");
        $pass = filter_input(INPUT_POST, "pass");
        $remember = filter_input(INPUT_POST, "remember");
        $userDataSource = new Frontend\UserDataSource();
        $userId = $userDataSource->getUserWithMail($email)->getUserId();
        if($userId == 0){
            $userId = $userDataSource->getUserWithPhone($email)->getUserId();
        }
       
        if($userId != 0){
            $this->loginResult["emailExist"] = TRUE;
        }else{
            $this->loginResult["emailMessage"] = "You don't have an account";
        }
        
        $password = new Helper\Password();
        $userPasswordDataSource = new Frontend\UserPasswordDataSource();
        if($password->isPassMatch($pass, $userPasswordDataSource->getUserCurrentPassword($userId)->getUserPassword())){
            $this->loginResult["passwordMatch"] = TRUE;
        }else{
            $this->loginResult["passwordMessage"] = "Wrong password";
        }
        
        if($this->loginResult["emailExist"] && $this->loginResult["passwordMatch"]){
            
            $sessionManager = new SessionManageController();
            $sessionManager->createUserMailSession($email, $remember);
            $userDataSource->updateUserLastVisite(time(), $userId);
            
            $this->loginResult["result"] = TRUE;
        }
        
        if(array_key_exists("c", $_GET) && $_GET["c"] == "ajax"){
            print "|".json_encode($this->loginResult)."|";
        }else{
            if($this->loginResult["result"]){
                header("Location: .");
            }else{
                header("Location: ".SITE_ROOT."authenticate?message=".$this->loginResult["emailMessage"]."");
            }
        }
        
    }
    
    
    public function logoutAction(){
        
        if(!isset($_SESSION[SessionManageController::SESSION_USER_ID]) || $_SESSION[SessionManageController::SESSION_USER_ID] <= 0){
            throw new \Exception("Vous ne pouvez pas accéder à la page que vous demandez");
        }
        
        
        $sessionManager = new SessionManageController();
        $sessionManager->deconnectUser($_SESSION[SessionManageController::SESSION_USER_ID]);
        
        \header("Location: ../../", TRUE);
    }




    public function displayPageAction(){
        parent::displayPageAction();
        
        if(isset($_SESSION[SessionManageController::SESSION_USER_ID]) && $_SESSION[SessionManageController::SESSION_USER_ID] > 0){
            throw new \Exception(UNABLE_PAGE);
        }
        
        $loginMessage = filter_input(INPUT_GET, "message");
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", "", "", "Authentication"), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "loginMessage" => $loginMessage 
        ], 
                'DJOLUC/RegisterBundle/Views/Frontend/loginView.php');
    }
    
    public static function populateAuthenticationMenu(){
        $authenticated = isset($_SESSION[SessionManageController::SESSION_USER_ID])?TRUE:FALSE;
        $profilPictureDataSource = new Frontend\ProfilPictureDataSource();
        $isProfilPic = false;
        $profilPic = "";
        $token = "";
        if(isset($_SESSION[SessionManageController::SESSION_USER_ID]) && $_SESSION[SessionManageController::SESSION_USER_ID] > 0){
            $profilPic = $profilPictureDataSource->getUserCurrentPicture($_SESSION[SessionManageController::SESSION_USER_ID])->getProfilePictureMiniLink();
            
            if(!empty($profilPic)){
                $isProfilPic = TRUE;
            }
                 
            $token = $_SESSION[SessionManageController::SESSION_USER_TOKEN];
        }
        
        $aweClass = "fas fa-lock";
        
        
        if($isProfilPic){
            $aweClass = "";
        }
        
        ob_start();
        
        require_once 'DJOLUC/RegisterBundle/Views/Frontend/Menu/authenticationMenu.php';
        
        $menu = ob_get_clean();
        
        return $menu;
    }
    
    public static function rooter($langLink = "", $cacheDir = "Cache/") {
        parent::rooter($langLink, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("login", $thisObject, FALSE);
        $thisObject->addPage("logout", $thisObject, FALSE);
        $thisObject->addPage("", $thisObject);
            
            
        $thisObject->rooting($cacheDir);
        
    }
}
