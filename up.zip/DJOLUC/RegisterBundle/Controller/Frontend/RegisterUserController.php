<?php
namespace DJOLUC\RegisterBundle\Controller\Frontend;


use DJOLUC\RegisterBundle\Model\Frontend;

use DJOLUC\RegisterBundle\Helper;

/**
 * Description of RegisterUserController
 *
 * @author djoluc
 */
class RegisterUserController extends \App\Controller\BaseController{
    private $resultAndMessage = Array(
        "result"=>true,
        "userMail"=>true,
        "userMailMessage"=>"",
        "password"=>true,
        "passwordMessage"=>""
    );
    private $userDataSource;
    
    public function __construct() {
        $this->userDataSource = new Frontend\UserDataSource();
    }
    public function testUserFirstData($userMail, $userPassword, $userPasswordConf):bool{
        $out = TRUE;
        if($this->userDataSource->isMailUsed($userMail)){
            $this->resultAndMessage["result"] = false;
            $this->resultAndMessage["userMail"] = false;
            $this->resultAndMessage["userMailMessage"] = "Account already available";
            $out = FALSE;
        }
        return $out;
    }
    
    /*
     * Fonction who register user and print json result
     */
    
    
    
    public function sendCodeMailAction($code, $email):bool{
        
        $nom_site = "Jehlum";
        $adresse_site = "admin@jehlum.org";
        $conf_pass = $code;
        
        $passage_ligne = "\n";
        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $email)) // On filtre les serveurs qui rencontrent des bogues.
	{
            $passage_ligne = "\r\n";
        }else{
            $passage_ligne = "\n";
	}
	//=====Déclaration des messages au format texte et au format HTML.
	$message_txt = "Thanks to your registration on Jehlum. Use this password to confirm your email: ".$conf_pass."";
	$message_html='<!DOCTYPE html>
			<html>
                            <head>
                                <title>Registration on '.$nom_site.'</title>
                            </head>
                            <body style="font-size: 18px; color: rgba(0, 0, 0, 0.7); border: 5px solid cyan; width: 500px; margin: auto; padding: 10px;">
                                <h1 style="color: cadetblue; text-align: center;">Jehlum</h1>
                                <div>This mail will help you to confirm your register on'.$nom_site.'<br/><br/>
                                    To confirm your email, copie and past this code to the confirmation form on Jehlum:
                                    <br/><b>'.$conf_pass.'</b></div>
                                <p>If you have any questions/concerns, please get back to us on info@jehlum.org</p>
                            </body>
                        </html>';
	//==========
				
	//=====Création de la boundary
	$boundary = "-----=".md5(rand());
	//==========
				
	//=====Définition du sujet.
	$sujet = "Registration on Jehlum";
	//=========
				
	//=====Création du header de l'e-mail.
	$header = "From: \"".$nom_site."\"<".$adresse_site.">".$passage_ligne;
	$header.= "Reply-to: \"".$nom_site."\" <".$adresse_site.">".$passage_ligne;
	$header.= "MIME-Version: 1.0".$passage_ligne;
	$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"".$boundary."\" ".$passage_ligne."";
	//==========
				
	//=====Création du message.
	$message = $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format texte.
	$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_txt.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format HTML
	$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_html.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	//==========
				
	//=====Envoi de l'e-mail.
	
        return mail($email,$sujet,$message,$header);
    }
    
    
    
    public function sendCodeMailForOnlyEmailRegisterAction($code, $email, $userId):bool{
        
        $nom_site = "Jehlum";
        $adresse_site = "admin@jehlum.org";
        $conf_pass = $code;
        
        $passage_ligne = "\n";
        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $email)) // On filtre les serveurs qui rencontrent des bogues.
	{
            $passage_ligne = "\r\n";
        }else{
            $passage_ligne = "\n";
	}
	//=====Déclaration des messages au format texte et au format HTML.
	$message_txt = "Thanks to your registration on Jehlum. Use this password to confirm your email: ".$conf_pass."";
	$message_html='<!DOCTYPE html>
			<html>
                            <head>
                                <title>Registration on '.$nom_site.'</title>
                            </head>
                            <body style="font-size: 18px; color: rgba(0, 0, 0, 0.7); border: 5px solid cyan; width: 500px; margin: auto; padding: 10px;">
                                <h1 style="color: cadetblue; text-align: center;">Jehlum</h1>
                                <div>This mail will help you to confirm your register on'.$nom_site.'<br/><br/>
                                    To confirm your email set your password, you just have to click on this button:
                                    <br/><a target="_blank" href="'.SITE_ROOT.'/userForgotPass/noPassUserConfirm/'.$userId.'/'.md5($code).'"><button>Confirm my email</button></a></div>
                                <p>If you have any problem, contact us!</p>
                            </body>
                        </html>';
	//==========
				
	//=====Création de la boundary
	$boundary = "-----=".md5(rand());
	//==========
				
	//=====Définition du sujet.
	$sujet = "Registration on Jehlum";
	//=========
				
	//=====Création du header de l'e-mail.
	$header = "From: \"".$nom_site."\"<".$adresse_site.">".$passage_ligne;
	$header.= "Reply-to: \"".$nom_site."\" <".$adresse_site.">".$passage_ligne;
	$header.= "MIME-Version: 1.0".$passage_ligne;
	$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"".$boundary."\" ".$passage_ligne."";
	//==========
				
	//=====Création du message.
	$message = $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format texte.
	$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_txt.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary.$passage_ligne;
	//=====Ajout du message au format HTML
	$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
	$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
	$message.= $passage_ligne.$message_html.$passage_ligne;
	//==========
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
	//==========
				
	//=====Envoi de l'e-mail.
	
        return mail($email,$sujet,$message,$header);
    }
    
    public function registerAction(){
        
        if(isset($_SESSION[SessionManageController::SESSION_USER_ID]) && $_SESSION[SessionManageController::SESSION_USER_ID] > 0){
            $this->throwException(UNABLE_PAGE);
        }
    
        $userMail = filter_input(INPUT_POST, "user_mail");
        $userPassword = filter_input(INPUT_POST, "user_password");
        $userPasswordConf = filter_input(INPUT_POST, "user_conf_password");
        
        $userPasswordDataSource = new Frontend\UserPasswordDataSource();
        
        if($this->testUserFirstData($userMail, $userPassword, $userPasswordConf)){
            //print json_encode($this->resultAndMessage)."ooooo";
            $confPassword = rand(10000000, 99999999)."";
            
            $password = new Helper\Password($userPassword);
            $userPassword = $password->getHashPassword();
            $newUserId = $this->userDataSource->addUser(Frontend\UserDataSource::NORMAL_USER_TYPE, "", "", 0, "", 0, "", $userMail, "", "", "", "", time(), 0, 1, $confPassword, false, false, TRUE, time());
            
            if($newUserId != 0){
                $userPasswordDataSource->addUserPassword($userPassword, time(), $newUserId);
                
                $this->sendCodeMailAction($confPassword, $userMail);
            }
            
            $sessionManageController = new SessionManageController();
            $sessionManageController->createUserMailSession($userMail, true);
        }
        
        if(!(array_key_exists("c", $_GET) && $this->getGetString("c") == "ajax")){
            if($this->resultAndMessage["result"]){
                \header("Location: .");
            }else{
                print $this->displayPageAction($this->resultAndMessage["userMailMessage"]." ".$this->resultAndMessage["passwordMessage"]);
            }
        }else{
            print "|". json_encode($this->resultAndMessage)."|";
        }
    }
    
    public function uploadRecevedProfilePicture($userId){
        $out = Array(
            "result"=>TRUE,
            "message"=>"Success!"
        );
        
        if(array_key_exists("avatar", $_FILES)){
            require_once 'DJOLUC/Helper/php/fonct.php';
            $profilePictureDataSource = new Frontend\ProfilPictureDataSource();
            //new \DJOLUC\Helper\php\FileUploader($index, $destination, $coId, $type, $newNameType, $ownName);
            $fileUploader = new \DJOLUC\Helper\php\FileUploader("avatar", "./avatar/".$userId."", $userId, "image", "own_name", "".time()."");
            
            if($fileUploader->upload(false)){
                miniature($fileUploader->getFileDir(), 150, $fileUploader->getFileDir()."/mini", $fileUploader->getFileName());
                $profilePictureDataSource->addUserProfilPicture($userId, $fileUploader->getFileName());
            } else {
                $out["result"] = FALSE;
            }
            
            
        }else{
            $out["result"] = FALSE;
        }
        
        if(!$out["result"]){
            $out["message"] = "Error when uploading the file.";
        }
        
        print $this->getGetString("d");
        
        if(!(array_key_exists("d", $_GET) && $this->getGetString("d") == "ajax")){
            if($out["result"]){
                header("Location: .");
            }else{
                $this->completeAction("Error");
            }
        }else{
            return "|".json_encode($out)."|";
        }
    }
    
    
    
    public function generateArtisanMatricule():string{
        //A000000001
        $artisanUserDataSource = new Frontend\ArtisanUserDataSource();
        $artisanNumb = "".($artisanUserDataSource->getArtisanUserNumb())."";
        $length = strlen($artisanNumb);
        
        $leftComplete = "";
        for($i = 0; $i < 9 - $length; $i++){
            $leftComplete = $leftComplete."0";
        }
        
       return "A".$leftComplete."".$artisanNumb.""; 
    }
    
    
    public function completeRequestAction(){
        if(!isset($_SESSION[SessionManageController::SESSION_USER_ID]) || $_SESSION[SessionManageController::SESSION_USER_ID] <= 0){
            $this->throwException(UNABLE_PAGE);
        }
        
        
        
        $userId = $_SESSION[SessionManageController::SESSION_USER_ID];
        
        $out = Array(
            "result"=>TRUE,
            "message"=>"Profile complèté avec succes!"
        );
        
        //photo de profile
        
        if(array_key_exists("c", $_GET) && $this->getGetString("c") == "avatar"){
           
            return $this->uploadRecevedProfilePicture($userId);
        }
        
        if(array_key_exists("sent", $_POST)){
            $userNom = filter_input(INPUT_POST, "nom");
            $userPrenoms = filter_input(INPUT_POST, "prenom");
            $userBornDate = \DJOLUC\Helper\php\DateManager::getTimestampFromDateUsingDateTime(filter_input(INPUT_POST, "dayNaiss"), filter_input(INPUT_POST, "monthNaiss"), filter_input(INPUT_POST, "yearNaiss"));
            $userLieuNaiss = filter_input(INPUT_POST, "naissLieu");
            $userGenre = filter_input(INPUT_POST, "genre");
            $userPhone = filter_input(INPUT_POST, "phone");
            $userProfession = filter_input(INPUT_POST, "profession");
            $userCountry = filter_input(INPUT_POST, "country");
            $userTown = filter_input(INPUT_POST, "town");
            
            
            
            //update simple user 
            $result = $this->userDataSource->completeUserProfile($userId, $userNom, $userPrenoms, $userBornDate, $userLieuNaiss, $userGenre, $userPhone, $userProfession, $userCountry, $userTown, "");
            if(!$result){
                $out["result"] = false;
            }
        }
        
        if(!$out["result"]){
            $out["message"] = "Error when updating your profile.";
        }
        
        
        if(!(array_key_exists("c", $_GET) && $this->getGetString("c") == "ajax")){
            if($out["result"]){
                //\header("Location: ".SITE_ROOT."profil");
            }else{
                return $this->completeAction($message);
            }
        }else{
            print "|".json_encode($out)."|";
        }
    }
    
    public function completeAction($message = ""){
        
        if(!isset($_SESSION[SessionManageController::SESSION_USER_ID]) || $_SESSION[SessionManageController::SESSION_USER_ID] <= 0){
            $this->throwException(UNABLE_PAGE);
        }
        
        $userId = $_SESSION[SessionManageController::SESSION_USER_ID];
        $userDataSource = new Frontend\UserDataSource();
        
        if($this->userDataSource->isCompleteAcount($userId)){
            //header("Location: ../profil");
        }
        
        return $this->renderView([
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(), 
            "message" => $message
        ], 
                'DJOLUC/RegisterBundle/Views/Frontend/accountCompleteView.php');
    }


    /**
     * {@inheritdoc}
     */
    public function displayPageAction($message = ""){
        parent::displayPageAction();
        
        if(isset($_SESSION[SessionManageController::SESSION_USER_ID]) && $_SESSION[SessionManageController::SESSION_USER_ID] > 0){
            $this->throwException(UNABLE_PAGE);
        }
        
        
        return $this->renderView([
            "message" => $message, 
            "header" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(FALSE, "", "", "", "Register"), 
            "footer" => \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter()
        ], 
                'DJOLUC/RegisterBundle/Views/Frontend/registerView.php');
    }
    
    /**
     * {@inheritdoc}
     */
    
    public static function rooter($lang = "", $cacheDir = "Cache/") {
        parent::rooter($lang, $cacheDir);
        
        $thisObject = new self();
        
        $thisObject->addPage("register", $thisObject, FALSE);
        $thisObject->addPage("complete", $thisObject);
        $thisObject->addPage("completeRequest", $thisObject, FALSE);
        $thisObject->addPage("", $thisObject);
        
        $thisObject->rooting($cacheDir);
    }
}
