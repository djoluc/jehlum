<?php

namespace DJOLUC\RegisterBundle\Controller\Backend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/ArtisanUserDataSource.php';
require_once 'DJOLUC/MainBundle/Controller/Frontend/MainController.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/RegisterUserController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserPasswordDataSource.php';
require_once 'DJOLUC/Helper/DateManager.php';
require_once 'DJOLUC/RegisterBundle/Helper/Password.php';
require_once 'DJOLUC/PageBundle/Model/Frontend/PageDataSource.php';

/**
 * Description of UserWrapingController
 *
 * @author djoluc
 */
class UserWrapingController extends \App\Controller\BaseController {
    private $userDataSource,
            $userPasswordDataSource,
            $artisanUserDataSource,
            $pageDataSource,
            $userId;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->userPasswordDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserPasswordDataSource();
        $this->artisanUserDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\ArtisanUserDataSource();
        $this->pageDataSource = new \DJOLUC\PageBundle\Model\Frontend\PageDataSource();
        $userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
    }
    
    
    public function addUserAction(){
        if(array_key_exists("sent", $_POST)){
            
            $out = Array(
                "result"=>TRUE,
                "message"=>"Utilisateur Ajouté"
            );
            
            
            $mail = filter_input(INPUT_POST, "email");
            $userPassword = filter_input(INPUT_POST, "pass");
            $userPasswordConf = filter_input(INPUT_POST, "passConf");
            $userNom = filter_input(INPUT_POST, "nom");
            $userPrenoms = filter_input(INPUT_POST, "prenom");
            $userBornDate = \DJOLUC\Helper\DateManager::getTimestampFromDateUsingDateTime(filter_input(INPUT_POST, "dayNaiss"), filter_input(INPUT_POST, "monthNaiss"), filter_input(INPUT_POST, "yearNaiss"));
            $userLieuNaiss = filter_input(INPUT_POST, "naissLieu");
            $userGenre = filter_input(INPUT_POST, "genre");
            $userPhone = filter_input(INPUT_POST, "phone");
            $userProfession = filter_input(INPUT_POST, "profession");
            $userCountry = filter_input(INPUT_POST, "country");
            $userTown = filter_input(INPUT_POST, "town");
            $userQuartier = filter_input(INPUT_POST, "quartier");
            
            //artisan
            $userCompany = filter_input(INPUT_POST, "company");
            $userJuridic = filter_input(INPUT_POST, "juridic");
            $association = filter_input(INPUT_POST, "association");
            $federation = filter_input(INPUT_POST, "federation");
            $formator = filter_input(INPUT_POST, "formator");
            
            $userType = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::ARTISAN_USER_TYPE;
            
            if($userPassword == $userPasswordConf && !empty($userPhone)){
                if(strlen($userPassword) >= 8){
                    if(!empty($mail) && $this->userDataSource->isMailUsed($mail)){
                        $out["result"] = FALSE;
                        $out["message"] = "Il existe déjà un compte avec cet adresse email.";
                    }else{
                        if($this->userDataSource->isPhoneUsed($userPhone, $userCountry)){
                            $out["result"] = FALSE;
                            $out["message"] = "Il existe déjà un compte avec ce numéro de téléphone.";
                        }else{
                            $password  = new \DJOLUC\RegisterBundle\Helper\Password($userPassword);
                            $userPassword = $password->getHashPassword();
                    
                            $newUserId = $this->userDataSource->addUser($userType, $userNom, $userPrenoms, $userBornDate, $userLieuNaiss, $userGenre, $userPhone, $mail, $userProfession, $userCountry, $userTown, $userQuartier, \time(), \time(), \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::SIMPLE_RANG, "", TRUE, FALSE, TRUE, \time());
                            $registerUserController = new \DJOLUC\RegisterBundle\Controller\Frontend\RegisterUserController();
                            $this->userPasswordDataSource->addUserPassword($userPassword, \time(), $newUserId);
                            
                            if($userType == \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::ARTISAN_USER_TYPE){
                                $this->artisanUserDataSource->addArtisanUser($userCompany, $userJuridic, $association, $federation, $formator, $registerUserController->generateArtisanMatricule(), $newUserId);
                                $this->pageDataSource->addUserPage($newUserId, $userCompany, "");
                            }
                        }
                    }
                }else{
                    $out["result"] = false;
                    $out["message"] = "Veuillez saisir un mot de passe de 8 caratère au moins";
                }
            }else{
               $out["result"] = false;
               $out["message"] = "Mots de passe incompatibles";
            }
            
            if(array_key_exists("ajax", $_GET)){
                $this->printDjolucJson($out);
            }else{
                header("Location: ?a=userWraping&message=".$out["message"]."");
            }
        }
    }


    
    public function displayPageAction() {
        parent::displayPageAction();
        
        return $this->renderView([
            "header"=> \DJOLUC\MainBundle\Controller\Frontend\MainController::populateMainHeader(), 
            "footer"=> \DJOLUC\MainBundle\Controller\Frontend\MainController::populateFooter(),
            "userId"=>$this->userId, 
            "operationMessage"=> filter_input(INPUT_GET, "message")
        ], 
                'DJOLUC/RegisterBundle/Views/Backend/userWrapingView.php');
    }
    
    

    public static function rooter() {
        parent::rooter();
        
        $thisClass = new \DJOLUC\RegisterBundle\Controller\Backend\UserWrapingController();
        
        if(\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurentUserRang() < \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::MODO_RAND){
            $thisClass->throwException("Vous n'avez pas le niveau d'acréditation pour accéder à cette page.");
        }
        
        if(array_key_exists("add", $_GET)){
            $thisClass->addUserAction();
        }else{
            print $thisClass->displayPageAction();
        }
    }


}
