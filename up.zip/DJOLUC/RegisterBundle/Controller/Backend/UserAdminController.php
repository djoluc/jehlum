<?php

namespace DJOLUC\RegisterBundle\Controller\Backend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/ArtisanUserDataSource.php';


use DJOLUC\RegisterBundle\Model\Frontend;
use DJOLUC\RegisterBundle\Controller;

/**
 * Description of UserAdminController
 *
 * @author djoluc
 */
class UserAdminController extends \App\Controller\BaseController {
    
    private $userDataSource, 
            $artisanUserDataSource, 
            $userId;
    
    public function __construct() {
        $this->userDataSource = new Frontend\UserDataSource();
        $this->artisanUserDataSource = new Frontend\ArtisanUserDataSource();
        $this->userId = $_SESSION[Controller\Frontend\SessionManageController::SESSION_USER_ID];
    }
    
    public function shareUserListAsJsonAction(){
        
        $premier = (int)filter_input(INPUT_POST, "premier");
        $nombre = (int)filter_input(INPUT_POST, "nombre");
        $search = filter_input(INPUT_POST, "search");
        
        $userFilter = $this->getGetString("c");
        
        if($userFilter == "artisan"){
            print "|".$this->userDataSource->getAllUserJson($this->userId, $search, $premier, $nombre, "artisan")."|";
        }else if($userFilter == "adm"){
            print "|".$this->userDataSource->getAllUserJson($this->userId, $search, $premier, $nombre, "adm")."|";
        }else{
            print "|".$this->userDataSource->getAllUserJson($this->userId, $search, $premier, $nombre)."|";
        }
    }
    
    public function loadSearchProposition(){
        $text = filter_input(INPUT_POST, "txt");
        
        $userFilter = $this->getGetString("c");
        
        if($userFilter == "artisan"){
            print "|".$this->userDataSource->getUserSearchPropositionAsJson($this->userId, 10, $text, "artisan")."|";
        }else if($userFilter == "adm"){
            print "|".$this->userDataSource->getUserSearchPropositionAsJson($this->userId, 10, $text, "adm")."|";
        }else{
            print "|".$this->userDataSource->getUserSearchPropositionAsJson($this->userId, 10, $text)."|";
        }
    }
    
    
    public function editUserAction(){
        $out = Array(
            "result"=>"true",
            "message"=>""
        );
        
        $userNewRang = filter_input(INPUT_POST, "userRang");
        $userNewActivity = filter_input(INPUT_POST, "userActivity");
        $targetUsetId = filter_input(INPUT_POST, "userId");
        
        if(!$this->userDataSource->updateUserRang($targetUsetId, $userNewRang)){
            $out["result"] = false;
            $out["message"] =  "Erreur lors de la modification du rang";
        }
        if(!$this->userDataSource->updateUserActivity($targetUsetId, $userNewActivity)){
            $out["result"] = false;
            $out["message"] =  "Erreur lors de la modification de l'activité";
        }
        
        print "|".json_encode($out)."|";
    }
    
    
    public function deleteAction(){
        $userId = $this->getGetInt("c");
        
        if($userId > 0){
            $this->userDataSource->deleteUser($userId);
            
            \header("Location: /useradmin");
        }else{
            \header("Location: /useradmin");
        }
        
    }
    
    
    public function displayPageAction() {
        parent::displayPageAction();
        
        
        $users = $this->userDataSource->getAllUser($this->userId);
        
        $userRang = $this->userDataSource->getUser($this->userId)->getUserRang();
        
        $userFilter = "";
        
        /*if(array_key_exists("artisan", $_GET)){
            $userFilter = "artisan";
        }else if(array_key_exists("adm", $_GET)){
            $userFilter = "adm";
        }*/
        
        $userFilter = $this->getGetString("b");
        
        return $this->renderView([
            "users"=>$users, 
            "userRang"=>$userRang, 
            "userFilter"=>$userFilter
        ],
                "DJOLUC/RegisterBundle/Views/Backend/userAdminView.php");
    }
    

    public static function rooter() {
        parent::rooter();
        
        /*if(!isset($_SESSION[Controller\Frontend\SessionManageController::SESSION_USER_ID]) || $_SESSION[Controller\Frontend\SessionManageController::SESSION_USER_ID] <= 0){
            throw new \Exception("Vous ne pouvez pa accéder à la page que vous demandez");
        }*/
        
        $userDataSource = new Frontend\UserDataSource();
        $userId = $_SESSION[Controller\Frontend\SessionManageController::SESSION_USER_ID];
        $userRang = $userDataSource->getUser($userId)->getUserRang();
        
        /*if($userRang < Frontend\UserDataSource::ADM_RANG){
            throw new \Exception("Vous le niveau d'accréditation necessaire pour accéder à la page que vous demandez");
        }*/
        
        $userAdminController = new UserAdminController();
        
        if($userAdminController->getGetString("b") == "ajaxusers"){
            print $userAdminController->shareUserListAsJsonAction();
        }else if($userAdminController->getGetString("b") == "ajaxNameSearchProposition"){
            $userAdminController->loadSearchProposition();
        }else if($userAdminController->getGetString("b") == "editUserRequest"){
            $userAdminController->editUserAction();
        }else if($userAdminController->getGetString("b") == "delete"){
            $userAdminController->deleteAction();
        }else if($userAdminController->getGetString("c") == ""){
            print $userAdminController->displayPageAction();
        }
        
        
  
    }

}
