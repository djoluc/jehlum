<div id="register_header">
    <a href="."><button><i class="fa fa-arrow-left fa-fw"></i>Accueil</button></a>
    <?= $authenticationMenu; ?>
    <h2>Complètez votre profile</h2>
</div>