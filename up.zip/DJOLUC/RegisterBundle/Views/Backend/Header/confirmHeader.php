<div id="register_header">
    <ul>
        <li><i style="font-weight: bold;" class="fa far fa-sign-out-alt"></i>Deconnexion</li>
    </ul>
</div>