<?php $title = "Ajouter un artisan";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/main_actuality_box.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/horizontalScrollView.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/formBase.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
        <script src="http://www.openlayers.org/api/OpenLayers.js"></script>
        <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/RegisterBundle/Public/Theme/Default/js/searchBar.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/LocationBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <!--<script type="text/javascript" src="DJOLUC/PaymentBundle/Public/Theme/Default/js/MtnMobileMoney.js"></script>-->
        
   
        
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>

        <div id="page_div" style="min-height: 700px; ">
            <br>
            <div id="form_div">
                <h3 style="margin-top: 0px; padding-top: 0px;"><center>Ajouter un artisan:</center></h3>
                <form class="complete_form" method="POST" action="?a=userWraping&add">
                    <label>
                        Adresse email(facultatif):
                        <input type="text" name="email" placeholder="Adresse email"/>
                    </label>
                    <label>
                        Mot de passe(8 caractères au moins)*:
                        <input type="password" name="pass" placeholder="Mot de passe" required/>
                    </label>
                    <label>
                        Confirmez le mot de passe*:
                        <input type="password" name="passConf" placeholder="Confirmez le mot de passe" required/>
                    </label>
                    <label>
                        Nom*:
                        <input type="text" name="nom" placeholder="Nom" required/>
                    </label>
                    <label>
                        Prenom(s)*:
                        <input type="text" name="prenom" placeholder="prénom(s)" required/>
                    </label>
                    <label class="naiss_date_label">
                        Date de naissance(<i>jj/mm/yyyy</i>): 
                        <select name="naiss_day" class="min">
	  
                            <?php for($i = 1; $i <= 31; $i++): ?>
                            
                                <option value="<?= $i; ?>"><?= $i; ?></option>
                            <?php endfor; ?>	 

                        </select>
                        <select name="naiss_month" class="min">
	  
                            <?php for($i = 1; $i <= 12; $i++): ?>
	  
                                <option value="<?= $i; ?>"><?= $i; ?></option>
                                
                            <?php endfor; ?>
                        </select>
                        <select name="naiss_year" class="min">
	  
                            <?php for($i = 1970; $i <= 2016; $i++): ?>
	  
                            <option value="<?= $i; ?>"><?= $i; ?></option>
	   
                            <?php endfor; ?>

                        </select>
                    </label>
                    <label>
                        Lieu de naissance*:
                        <input type="text" name="lieu_naiss" placeholder="Lieux de naissance" required/>
                    </label>
                    <label>
                        Votre genre*:
                        <select name="gender" required>
                            <option value="0">Femme</option>
                            <option value="1">Homme</option>
                        </select>
                    </label>
                    <label>
                        Numéro de téléphone*: 
                        <input type="text" name="phone" placeholder="Numéro de téléphone" required/>
                    </label>
                    <label>
                        Profession*:
                        <input type="text" name="profession" placeholder="Votre profession" required/>
                    </label>
                    <label>
                        Pays: 
                        <?php
                        require_once 'DJOLUC/RegisterBundle/Views/Frontend/Other/countrySelectList.php';
                        ?>
                    </label>
                    <label>
                        Ville*:
                        <input type="text" name="town" placeholder="Votre ville"  required/>
                    </label>
                    <label>
                        Quartier*: 
                        <input type="text" name="quartier" placeholder="Votre quartier"  required/>
                    </label>
                    <?php //if($isArtisan): ?>
                        
                        <fieldset>
                            <legend>Artisan</legend>
                            <label>
                            <input type="text" name="company" placeholder="Votre compagnie" required/>
                        </label>
                        
                        <label>
                            Statut juridique: 
                            <select name="juridique">
                                <option value="1">Informelle</option>
                                <option value="2">PME</option>
                                <option value="3">ETS</option>
                                <option value="4">SARL</option>
                            </select>
                        </label>
                        
                        <label>
                            Association*:
                            <input type="text" value="" name="association" placeholder="Nom de votre association" required/>
                        </label>
                        
                        <label>
                            Fédération*:
                             <input type="text" value="" name="federation" placeholder="Nom de votre fédération" required/>
                        </label>
                        
                        <label>
                            Formateur*:
                             <input type="text" value="" name="formator" placeholder="Nom de votre formateur" required/>
                        </label>
                        </fieldset>
                    <input type="hidden" name="sent" />
                    <?php //endif ?>
                        <p class="error_indicator">
                            <?= $data["operationMessage"]; ?>
                        </p>
                    <button type="submit">Ajouter<i class="fa fa-spinner fa-pulse" style="display: none;"></i></button>
                </form>
            </div>
        </div>
        
    <?php $body_content = ob_get_clean(); ?>

    <?php ob_start(); ?>
        <?= $data["footer"]; ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>