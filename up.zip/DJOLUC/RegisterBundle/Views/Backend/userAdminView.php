<?php $title = "Completion de compte";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <link rel="stylesheet" href="<?= SITE_ROOT ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/tab.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/userAdmin.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/searchBar.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/jquery.Jcrop.css?version=1.0" media="all" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
        <!-- <script type='text/javascript' src='http://www.bing.com/api/maps/mapcontrol?key=AnAm4Fcz1L9Y5krogWfQ4A3ymPzFCqCiYpIPiyjGgwfLPbFeifRjpNaUJ8-aV-36'></script> -->
        <!--<script src="http://www.openlayers.org/api/OpenLayers.js"></script>-->
        <!--<script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>-->
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery.ajax-progress.js?version=1.0"></script>
         <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery.Jcrop.js"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/userAdmin.js?version=1.1"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/searchBar.js?version=1.0"></script>
        
        <style>

/* Add a right margin to each icon */
.fa {
    
}
</style>

<script>
    var siteRoot = <?= SITE_ROOT; ?>
</script>

    <?php $head_include = ob_get_clean(); ?>

    <?php ob_start(); ?>
        <?php //require_once 'Header/completeHeader.php'; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        
        <div id="contener_div">
            <div id="main_tab_box">
                <nav>
                <ul>
                    <li class="<?= $testVisibility=="hight"?"active":""; ?>"><a href="<?= SITE_ROOT ?>"><i class="fa fa-backward"></i></a></li>
                    <li class="<?= $data["userFilter"]==""?"active":""; ?>"><a href="<?= SITE_ROOT ?>useradmin">Users</a></li>
                    <li class="<?= $data["userFilter"]=="adm"?"active":""; ?>"><a href="<?= SITE_ROOT ?>useradmin/adm">Administrators</a></li>
                </ul>
                </nav>
            </div>
            <form id="searchForm">
                <input type="text" placeholder="Search" autocomplete="off" name="search"/><button type="submit"><i class="fa fa-search"></i></button>
                <ul class="autocompleteUl">
                    <!--<li>Example 1</li>
                    <li>Example 1</li>
                    <li>Example 1</li>
                    <li>Example 1</li>-->
                </ul>
            </form>
            <div class="cards_contener">
                <div class="loading_div"></div>
            </div>
            
            <div id="more_button_bar">
                <button class="more_button" style="display: none;"><i class="fa fa-plus"></i> More user</button>
            </div>
            
            
            <input type="hidden" value="<?= $data["userFilter"]; ?>" class="userFilter"/>
        </div>


        
    <?php $body_content = ob_get_clean(); ?>

        

<?php require_once 'Template/withoutFooterTemplate.php'; ?>

<!--


<?php foreach ($data["users"] as $user): ?>
            <div class="thecard">
                <div class="cardcontainer">
                    <div class="thefront">
                        <span class="profil_pic">
                            <img src="<?= $user->getUserProfilPicture(); ?>" />
                        </span>
                        <h1><?= $user->getUserNom()." ".$user->getUserPrenomsJson(); ?></h1>
                        <p><i class="fa fa-map-marker"></i> <?= $user->getUserGeolocal()."(".$user->getUserTown().")";?></p>
                        <p><i class="fa fal fa-clock"></i> Actif <?= $user->getUserLastLoadReference(); ?></p>
                        <?php if($user->isArtisan()): ?>
                        <p><i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></p>
                        <?php endif; ?>
                    </div>

                    <div class="theback">
                        <p><i class="fa fa-envelope"></i> <?= $user->getUserMail(); ?></p>
                        <p><i class="fa fa-phone"></i> <?= $user->getUserPhoneNumber(); ?></p>
                        <h1>Modification</h1>
                        <form>
                            <label>
                                Droit: 
                                <select>
                                    <option value="1" <?php if($user->getUserRang() == "1"){ print "selected"; } ?>>Utilisateur</option>
                                    <option value="2" <?php if($user->getUserRang() == "2"){ print "selected"; } ?>>Modérateur</option>
                                    <option value="3" <?php if($user->getUserRang() == "3"){ print "selected"; } ?>>Mini-Adminstateur</option>
                                    <option value="4" <?php if($user->getUserRang() == "4"){ print "selected"; } ?>>Administrateur</option>
                                </select>
                            </label>
                            <label>
                                Déactiver le compte: 
                                <input type="checkbox" <?php if(!$user->getUserActivity()){ print "checked"; } ?> />
                            </label>
                            <button type="submit">Modifier</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

-->