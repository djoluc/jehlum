<?php $title = "Login";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="<?= SITE_ROOT ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/login.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/login.js?version=1.1"></script>
        <style>

/* Add a right margin to each icon */
.fa {
    
}
</style>
        
    <?php $head_include = ob_get_clean(); ?>

    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        <div id="contener_div">
            <div id="form_contener">
                <h2><?= LOGIN; ?></h2>
                <script>
                document.write('<form method="POST" class="account_confirm_form" action="<?= SITE_ROOT ?>authenticate/login">');
                </script>
                <noscript>
                <form method="POST" action="<?= SITE_ROOT ?>authenticate/login">
                </noscript>
                    <label>
                        <span><i class="fa fa-envelope"></i><input required type="text" name="mail" value="" placeholder="Email"/></span>
                        <p class="email_info">
                            <i class="fa fas fa-exclamation-triangle"></i><a>Put your email in this field.(Important)</a>
                        </p>
                    </label>
                    <label>
                        <span><i class="fa fa-key"></i><input required type="password" name="pass" value="" placeholder="Password"/></span>
                        <p class="pass_info">
                            <i class="fa fas fa-exclamation-triangle"></i><a>Put your password in this field.(Important)</a>
                        </p>
                    </label>
                    <label class="souvenir">
                        Remember me
                        <input type="checkbox" checked name="remember"/>
                    </label>
                    <p>
                        <?= $data["loginMessage"]; ?>
                    </p><br/>
                    <a href="<?= SITE_ROOT ?>userForgotPass">Forgot your password?</a><br/>
                    <button type="submit"><?= LOGIN ?><i class="fa fa-spinner fa-pulse" style="display: none;"></i></button><br/>
                    <!--<fieldset class="social"  style="display: block;">
                        <legend>Login with</legend>
                        <ul>
                            <li><i class="fab fa-facebook"></i></li>
                            <li><i class="fab fa-linkedin"></i></li>
                            <li><i class="fab fa-google"></i></li>
                        </ul>
                    </fieldset>-->
                </form>
                <p>
                    No account? <a href="<?= SITE_ROOT ?>register"><?= SIGNE_UP ?></a>
                </p>
            </div>       
        </div><br><br/><br>
        
    <?php $body_content = ob_get_clean(); ?>
        
    <?php ob_start(); ?>
        <?= $data["footer"] ?>
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>

