Flags
=====

Designer: Mark James (http://www.famfamfam.com/about/)
License: Free for commercial use
