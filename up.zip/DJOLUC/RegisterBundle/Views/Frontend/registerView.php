<?php $title = "Registration";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/register.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/register.js?version=1.0"></script>
        
        <style>

/* Add a right margin to each icon */
.fa {
    
}
</style>
        
    <?php $head_include = ob_get_clean(); ?>

    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
<div id="page_div" style="min-height: 150vh;">      
<div id="inscript_div">
            
            <!--<div id="register_info_div">
                <h2>Bienvenu sur la page d'inscription de <b>Artisandici</b></h2>
                <!--<ul>
                    Inscrivez vous et:
                    <li><i class="fa fa-circle"></i> faites vos commandes en un clic en tant que client,</li>
                    <li><i class="fa fa-circle"></i> localiser des artisan un peu partout dans le monde,</li>
                    <li><i class="fa fa-circle"></i> boustez vos chiffres d'affaires en tant que artisan, </li>
                    <li><i class="fa fa-circle"></i> faites vos commandes en un clic</li>
                    <li><i class="fa fa-circle"></i> faites vos commandes en un clic</li>
                </ul>
            </div>-->
            
            <div id="form_contener">
                <h2>Register</h2>
                <form class="register_form" method="POST" action="./register/register" enctype="multipart/form-data">
                    <label>
                        <span class="input_span"><i class="fa fa-envelope"></i><input type="text" placeholder="E-mail" value="" name="email" required /></span>
                        <p class="email_info">
                            <i class="fa fas fa-exclamation-triangle"></i><a>Saisissez dans ce champs votre adresse email.(Obligatoire)</a>
                        </p>
                    </label>
                    <label>
                        <span class="input_span"><i class="fa fa-key"></i><input type="password" placeholder="Your new password" value="" name="password" required /></span>
                        <p class="pass_info">
                            <i class="fa fas fa-exclamation-triangle"></i><a>Saisissez dans ce champs votre adresse email.(Obligatoire)</a>
                        </p>
                    </label>
                    <label>
                        <span class="input_span"><i class="fa fa-key"></i><input type="password" placeholder="Confirme the password" value="" name="password_conf" required /></span>
                        <p class="pass_conf_info">
                            <i class="fa fas fa-exclamation-triangle"></i><a>Saisissez dans ce champs votre adresse email.(Obligatoire)</a>
                        </p>
                    </label>
                    <label class="chate_label">
                        I have read and agree to the <a target="_blank" href="/terms">Terms & Conditions</a> <input type="checkbox" name="charte_accept" class="charte_check" required />
                    </label>
                    <p style="color: red;"><?= $data["message"]; ?></p>
                    <button class="submit_button" type="submit">Submit <i class="fa fa-spinner fa-pulse fa-fw" style="display: none;"></i></button>
                </form>
            </div>
                    
        </div><br><br><br>
</div>
    <?php $body_content = ob_get_clean(); ?>
     <?php ob_start(); ?>
        <?= $data["footer"] ?>
    <?php $footer = ob_get_clean(); ?>   

<?php require_once 'Template/template.php'; ?>

