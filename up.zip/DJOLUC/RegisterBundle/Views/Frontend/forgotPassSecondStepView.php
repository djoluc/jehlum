<?php $title = "Completion de compte";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <link rel="stylesheet" href="<?= SITE_ROOT ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/forgotPassword.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/jquery.Jcrop.css" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
        <!-- <script type='text/javascript' src='http://www.bing.com/api/maps/mapcontrol?key=AnAm4Fcz1L9Y5krogWfQ4A3ymPzFCqCiYpIPiyjGgwfLPbFeifRjpNaUJ8-aV-36'></script> -->
        <script src="http://www.openlayers.org/api/OpenLayers.js"></script>
        <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/accountComplete.js?version=1.0"></script>
        
        <style>

/* Add a right margin to each icon */
.fa {
    
}
</style>

    <?php $head_include = ob_get_clean(); ?>

    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>

<div id="page_div">
    <div id="form_contener" style="background: #ffffff;">
        <form method="POST" action="<?= SITE_ROOT ?>userForgotPass/secondStep">
            <label>
                <p>
                    Please put the password we sent to <b><?= $data["email"] ?></b>
                </p>
                <input type="text" value="" name="code" placeholder="code " required /><br/>
                <input type="hidden" value="<?= $data["email"] ?>" name="email" />
                <input type="hidden" value="" name="sent" />
                <p class="error_indicator">
                    <?= $data["errorInfo"]; ?>
                </p>
                <button>Submit</button>
            </label>
        </form>
    </div>
</div>
            
            
    <?php $body_content = ob_get_clean(); ?>

        

<?php require_once 'Template/template.php'; ?>
