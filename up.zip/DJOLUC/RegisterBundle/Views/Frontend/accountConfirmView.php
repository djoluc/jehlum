<?php $title = "Confirm your account";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/RegisterBundle/Public/Theme/Default/css/confirm.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/RegisterBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        <script type="text/javascript" src="DJOLUC/RegisterBundle/Public/Theme/Default/js/codeConfirm.js?version=1.0"></script>
        
        <style>

/* Add a right margin to each icon */
.fa {
    
}
</style>
        
    <?php $head_include = ob_get_clean(); ?>

    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        
        <div id="contener_div">
            <div id="form_contener">
                <h2>Confirm your email</h2>
                <form class="account_confirm_form" method="POST" action="../accountConfirm/confirmCode" enctype="multipart/form-data">
                    <p>
                        We sent a mail to :<b><?= "  ".$data["userMail"]; ?></b>   <br/>
                        Please, use the code in the mail to confirm your email.
                    </p>
                    
                    <label>
                        <i class="abs fa fa-key fa-fw"></i><input required type="number" value="" placeholder="Confirmation code"/><button type="submit">Confirm<i class="fa fa-spinner fa-pulse fa-fw" style="display: none;"></i></button>
                        <p class="message">
                            <i class="fa fas fa-exclamation-triangle"></i><a>Put the code in the mail we sent to you.(*)</a>
                        </p>
                    </label>
                </form>
                <p>
                    You did'nt receve the mail?
                </p>
                <button class="resend_button"><i class="fa far fa-sync-alt fa-pulse" style="display: none;"></i>Send again</button>
                <p class="resend_message">
                    <i class="fa fas fa-exclamation-triangle"></i><a>Put the code in the mail we sent to you.(*)</a>
                </p>
            </div>  
        </div>
        
    <?php $body_content = ob_get_clean(); ?>
        

<?php require_once 'Template/withoutFooterTemplate.php'; ?>

