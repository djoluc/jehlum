<?php $title = "Vos artisan favoris" ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <!--<link type="text/css" rel="stylesheet" href="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.css"/>-->
        <link rel="stylesheet" href="App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/main.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/leftMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/ProductBundle/Public/Theme/Default/css/shoppingCardMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/RegisterBundle/Public/Theme/Default/css/userFavoriteArtisan.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="DJOLUC/MainBundle/Public/Theme/Default/css/rightMenu.css?version=1.0" media="all" />
        <!--<script src="https://api.mqcdn.com/sdk/mapquest-js/v1.3.2/mapquest.js"></script>-->
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
       
      
    <?php $head_include = ob_get_clean(); ?>
    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        
<div id="page_div">
    <?php if($data["userTotalNumb"] > 0): ?>
        <h2 style="text-align: center;">Vos artisans favoris</h2>
    <?php endif; ?>
    <?php foreach ($data["artisanUsers"] AS $artisanUser): ?>
        <div id="fav_artisan">
            <p>
                <a class="profil_link" href="?a=profil&uid=<?= $artisanUser->getArtisanUser()->getUserId(); ?>">
                    <?= empty($artisanUser->getUser()->getUserProfilMiniPicture())?"":"<img src='".$artisanUser->getArtisanUser()->getUserProfilMiniPicture()."'/>"; ?>
                </a>
                <?= $artisanUser->getArtisanUser()->getUserNom(); ?>
            </p>
            <a href="?a=userFavArtisan&artisanUserId=<?= $artisanUser->getArtisanUserId(); ?>&delete"><button style="background: red;">Retirer</button></a>
            <a href="?a=page&pid=<?= $artisanUser->getArtisanUserPage()->getPageId(); ?>"><button style="margin-right: 2px;">Page</button></a>

        </div>
    <?php endforeach; ?>
    <br/>
    <?php if($data["userTotalNumb"] > $data["numb"]): ?>
    <a href="?a=userFavArtisan&numb=<?= $data["numb"]*2; ?>"><button>Afficher plus d'artisan favori</button></a>
    <?php endif; ?>
    
    <?php if($data["userTotalNumb"] == 0): ?>
        <p style="text-align: center;">Vous n'avez pas d'artisan favori</p>
    <?php endif; ?>
</div>
        
    <?php $body_content = ob_get_clean(); ?>

    <?php ob_start(); ?>
        foot
        <!--<button class="w3-button w3-display-left w3-black" onclick="plusDivs(-1)">&#10094;</button>
        <button class="w3-button w3-display-right w3-black" onclick="plusDivs(1)">&#10095;</button>-->
    <?php $footer = ob_get_clean(); ?>

<?php require_once 'Template/template.php'; ?>