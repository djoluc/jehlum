<?php $title = "Complete your account";  ?>
<?php ob_start(); ?>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scal=1.5" />
        <link rel="stylesheet" href="<?= SITE_ROOT; ?>App/Framework/fontawesome/css/all.css">
        <!--<link href="http://fonts.googleapis.com/css?family=Fenix" rel="stylesheet" type="text/css" media="all">
        <link href="https://fonts.googleapis.com/css?family=Spectral" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet"/>-->
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/general.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/complete.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/css/jquery.Jcrop.css" media="all" />
                <link rel="stylesheet" title="Design" type="text/css" href="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/css/authenticationMenu.css?version=1.0" media="all" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
        <!-- <script type='text/javascript' src='http://www.bing.com/api/maps/mapcontrol?key=AnAm4Fcz1L9Y5krogWfQ4A3ymPzFCqCiYpIPiyjGgwfLPbFeifRjpNaUJ8-aV-36'></script> -->
        <script src="http://www.openlayers.org/api/OpenLayers.js"></script>
        <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery-3.3.1.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery.ajax-progress.js?version=1.0"></script>
         <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/jquery.Jcrop.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/LocationBundle/Public/Theme/Default/js/GeolocalManager.js?version=1.0"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/RegisterBundle/Public/Theme/Default/js/accountComplete.js?version=1.1"></script>
        <script type="text/javascript" src="<?= SITE_ROOT; ?>DJOLUC/MainBundle/Public/Theme/Default/js/main.js?version=1.0"></script>
        
        <style>

/* Add a right margin to each icon */
.fa {
    
}
</style>

    <?php $head_include = ob_get_clean(); ?>

    <?php ob_start(); ?>
        <?= $data["header"]; ?>
    <?php $header = ob_get_clean(); ?>
    
    <?php ob_start(); ?>
        
        <div id="contener_div">
            
            <div class="other_field">
                
                <h2><?= PROFILE_PICTURE; ?>:</h2>
                <form id="profil_picture_form" method="POST" action="<?= SITE_ROOT ?>register/completeRequest/avatar" enctype="multipart/form-data">
                    <p class="message">comment</p>
                    <div id="image_crop">
                        
                    </div>
                    <input type="file" name="avatar" id="avatar_image" style="display: none;" />
                    <button class="choose_avatar"><?= CHOOSE ?></button> <button type="submit" class="send_avatar" disabled><i class="fa fa-upload"></i><?= SEND ?></button>
                    <progress max="1" value="0" id="avatar_progress"></progress>
                </form>
                
                
                <div class="map_field" id="mapField">
                
                </div>
            </div>
            
            <div id="form_contener">
                <p>Fields with '*' are important. </p>
                <form class="complete_form" method="POST" action="<?= SITE_ROOT ?>register/completeRequest" enctype="multipart/form-data">
                    <label>
                        <input type="text" name="nom" placeholder="<?= LAST_NAME ?>*" required/>
                    </label>
                    <label>
                        <input type="text" name="prenom" placeholder="<?= FIRST_NAME ?>*" required/>
                    </label>
                    <label class="naiss_date_label">
                        <?= BIRTHDAY ?>(<i>dd/mm/yyyy</i>)*: 
                        <select name="naiss_day" class="min">
	  
                            <?php for($i = 1; $i <= 31; $i++): ?>
                            
                                <option value="<?= $i; ?>"><?= $i; ?></option>
                            <?php endfor; ?>	 

                        </select>
                        <select name="naiss_month" class="min">
	  
                            <?php for($i = 1; $i <= 12; $i++): ?>
	  
                                <option value="<?= $i; ?>"><?= $i; ?></option>
                                
                            <?php endfor; ?>
                        </select>
                        <select name="naiss_year" class="min">
	  
                            <?php for($i = 1970; $i <= 2016; $i++): ?>
	  
                            <option value="<?= $i; ?>"><?= $i; ?></option>
	   
                            <?php endfor; ?>

                        </select>
                    </label>
                    <label>
                        <input type="text" name="lieu_naiss" placeholder="<?= PLACE_OF_BIRTH ?>*" required/>
                    </label>
                    <label>
                        <?= GENDER ?>*:
                        <select name="gender" required>
                            <option value="0"><?= MAN ?></option>
                            <option value="1"><?= WOMAN ?></option>
                        </select>
                    </label>
                    <label>
                        <input type="text" name="phone" placeholder="<?= PHONE ?>*" required/>
                    </label>
                    <label>
                        <input type="text" name="profession" placeholder="<?= PROFESSION ?>"/>
                    </label>
                    <label>
                        <?= COUNTRY ?>: 
                        <?php
                        require_once 'Other/countrySelectList.php';
                        ?>
                    </label>
                    <label>
                        <input type="text" name="town" placeholder="<?= TOWN ?>"/>
                    </label>
                    <label>
                        <input type="text" name="quartier" placeholder="<?= DISTRICT ?>"/>
                    </label>
                        <p class="error_indicator">
                            <?= $data["message"]; ?>
                        </p>
                    <button type="submit"><?= COMPLETE ?><i class="fa fa-spinner fa-pulse" style="display: none;"></i></button>
                </form>
            </div>       
        </div>
        
    <?php $body_content = ob_get_clean(); ?>

        

<?php require_once 'Template/withoutFooterTemplate.php'; ?>

