<div id="register_header">
    <a href="."><button><i class="fa fa-arrow-left fa-fw"></i>Home</button></a>
    <ul>
        <a href="?a=authenticate"><li><i style="font-weight: bold;" class="fa far fa-sign-in-alt"></i>Sign in</li></a>
    </ul>
</div>