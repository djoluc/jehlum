<div id="authentic_menu">
    <a style="color: rgba(3, 169, 244, 1);" class="authentic_icon <?= $aweClass; ?>">
        <?php if($isProfilPic):  ?>
            <img src="<?= $profilPic; ?>"/>
        <?php endif; ?>
    </a>
    <ul style="width: fit-content; padding: 0px;">
        <?php if($authenticated): ?>
        <li style="font-size: 17px; display: block;"><a href="<?= SITE_ROOT ?>profil"><i class="fa fa-user-edit"></i>Profile</a></li>
        <li style="font-size: 17px; display: block;"><a href="<?= SITE_ROOT ?>authenticate/logout/<?= $token; ?>"><i class="fa fa-sign-out-alt"></i> Logout</a></li>
        <?php endif; ?>
        <?php if(!$authenticated): ?>
        <li style="font-size: 17px; display: block;"><a href="<?= SITE_ROOT ?>authenticate">Login</a></li>
        <li style="font-size: 17px; display: block;"><a href="<?= SITE_ROOT ?>register">Register</a></li>
        <?php endif; ?>
    </ul>
</div>