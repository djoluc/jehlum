<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;

require_once 'DJOLUC/Helper/php/DbSwitcher.php';
require_once 'UserPassword.php';

use DJOLUC\Helper;

use Exception;
/**
 * Description of UserPasswordDataSource
 *
 * @author djoluc
 */
class UserPasswordDataSource {
    const TABLE_NAME = "user_password_table";
    const COLUMN_USER_PASSWORD = "user_password";
    const COLUMN_PASSWORD_TIME = "password_time";
    const COLUMN_USER_ID = "user_id";
    const COLUMN_IS_CURRENT = "is_current_password";
    
    public $AllColumn;
    
    private $DbPdo;
    private $DbPdoOk;
    private $PropertyOk;
    private $UserPasswordTable;
    
    
    public function __construct() {
        $this->UserPasswordTable = null;
        
        $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $dbswitch = new Helper\php\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTableUserPassword();
            $this->DbPdoOk = TRUE;
        }
        
        $this->AllColumn = "".$this::COLUMN_USER_PASSWORD.", ".$this::COLUMN_PASSWORD_TIME.", ".
                $this::COLUMN_USER_ID.", ".$this::COLUMN_IS_CURRENT."";
    }
    
    
    private function createTableUserPassword(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                       CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME."
                           (
                                ".$this::COLUMN_USER_PASSWORD." text, 
                                ".$this::COLUMN_PASSWORD_TIME." bigint, 
                                ".$this::COLUMN_USER_ID." bigint unsigned NOT NULL,
                                ".$this::COLUMN_IS_CURRENT." bool NOT NULL DEFAULT FALSE,
                                FOREIGN KEY (".$this::COLUMN_USER_ID.") REFERENCES ".UserDataSource::TABLE_NAME." (".UserDataSource::COLUMN_ID.") ON DELETE CASCADE ON UPDATE CASCADE
                           ); 
                    ");
            if(!$query->execute()){
                throw new Exception($query->errorInfo()[2]);
            }
        } catch (Exception $e) {
            echo"Impossible de créer la table ".$this::TABLE_NAME." ".$e->getMessage()."";
            die();
        }
    }
    
    public function isPasswordExist($userId, $password){
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_USER_PASSWORD.") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_USER_PASSWORD." = ?
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $password, \PDO::PARAM_STR);
        $query->execute();
        if($data = $query->fetch()){
            $out = $data["numb"]>0?true:false;
        }
        
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function addUserPassword($userPassword, $passwordTime, $userId, $isCurrentPassword = true):bool{
        $out = false;
        
        if($this->isPasswordExist($userId, $userPassword)){
            return false;
        }
        
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES (?, ?, ?, ?); 
                ");
        $query->bindValue(1, $userPassword, \PDO::PARAM_STR);
        $query->bindValue(2, $passwordTime, \PDO::PARAM_INT);
        $query->bindValue(3, $userId, \PDO::PARAM_INT);
        $query->bindValue(4, $isCurrentPassword, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = TRUE;
            if($isCurrentPassword){
                $this->setCurrentUserPassword($userId, $userPassword);
            }
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    public function setCurrentUserPassword($userId, $password):bool{
        $out = false;
        
        if(!$this->isPasswordExist($userId, $password)){
            return false;
        }
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_IS_CURRENT." = ? WHERE  (".$this::COLUMN_USER_PASSWORD." = ? AND ".$this::COLUMN_USER_ID." = ?);
                ");
        $query->bindValue(1, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue(2, $password, \PDO::PARAM_STR);
        $query->bindValue(3, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_IS_CURRENT." = ? WHERE  (".$this::COLUMN_USER_PASSWORD." != ? AND ".$this::COLUMN_USER_ID." = ?);
                ");
        $query->bindValue(1, FALSE, \PDO::PARAM_BOOL);
        $query->bindValue(2, $password, \PDO::PARAM_STR);
        $query->bindValue(3, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    public function getUserPasswords($userId):array{
        $out = Array();
        
        $query = $this->DbPdo->prepare
                ("
                   SELECT ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUserPasswords($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    public function getUserCurrentPassword($userId): UserPassword{
        $out = Array();
        
        $query = $this->DbPdo->prepare
                ("
                   SELECT ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_IS_CURRENT." = ? ;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, TRUE, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->queryToUserPassword($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    public function queryToUserPassword(\PDOStatement $query):UserPassword{
        $out = UserPassword::getEmptyUserPassword();
        
        if($data = $query->fetch()){
            $out = new UserPassword($data[$this::COLUMN_USER_PASSWORD], $data[$this::COLUMN_PASSWORD_TIME], $data[$this::COLUMN_USER_ID], $data[$this::COLUMN_IS_CURRENT]);
        }
        
        return $out;
    }
    
    
    public function queryToUserPasswords(\PDOStatement $query):array{
        $out = Array();
        
        $i = 0;
        while($data = $query->fetch()){
            $out[$i++] = new UserPassword($data[$this::COLUMN_USER_PASSWORD], $data[$this::COLUMN_PASSWORD_TIME], $data[$this::COLUMN_USER_ID], $data[$this::COLUMN_IS_CURRENT]);
        }
        
        return $out;
    }
}
