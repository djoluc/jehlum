<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;

require_once 'DJOLUC/Helper/php/DbSwitcher.php';
require_once 'UserDataSource.php';
require_once 'ArtisanUser.php';

use DJOLUC\Helper;
use Exception;

//use Symfony\Component\Config\Definition\Exception\Exception;

/**
 * Description of ArtisanUserDataSource
 *
 * @author djoluc
 */
class ArtisanUserDataSource {
    const TABLE_NAME = "artisan_user_table",
          COLUMN_ARTISAN_ID = "artisan_id",
          COLUMN_ARTISAN_COMPANY_NAME = "artisan_company_name",
          COLUMN_ARTISAN_JURIDIC_STATUS = "artisan_juridic_status",
          COLUMN_ARTISAN_ASSOCIATION_NAME = "artisan_association_name",
          COLUMN_FEDERATION_APPARTENANCE = "artisan_federation_appartenance",
          COLUMN_ARTISAN_FORMATOR = "artisan_formator",
          COLUMN_ARTISAN_MATRICULE = "artisan_matricule",
          COLUMN_CORES_USER_ID = "user_id";
    
    public $AllColumn;
    
    private $DbPdo,
            $DbPdoOk,
            $PropertyOk;
    
    
    public function __construct() {
        $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $dbswitch = new Helper\php\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTableArtisanUser();
            $this->DbPdoOk = TRUE;
        }
        
        $this->AllColumn = "".$this::COLUMN_ARTISAN_COMPANY_NAME.", ".$this::COLUMN_ARTISAN_JURIDIC_STATUS.", ".$this::COLUMN_ARTISAN_ASSOCIATION_NAME.
                ", ".$this::COLUMN_FEDERATION_APPARTENANCE.", ".$this::COLUMN_ARTISAN_FORMATOR.", ".$this::COLUMN_ARTISAN_MATRICULE.", ".$this::COLUMN_CORES_USER_ID."";
    }
    
    
    public function createTableArtisanUser(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                        CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME."
                            (
                                ".$this::COLUMN_ARTISAN_ID." bigint unsigned NOT NULL AUTO_INCREMENT,
                                ".$this::COLUMN_ARTISAN_COMPANY_NAME." varchar(500), 
                                ".$this::COLUMN_ARTISAN_JURIDIC_STATUS." int, 
                                ".$this::COLUMN_ARTISAN_ASSOCIATION_NAME." varchar(500), 
                                ".$this::COLUMN_FEDERATION_APPARTENANCE." varchar(500), 
                                ".$this::COLUMN_ARTISAN_FORMATOR." varchar(200), 
                                ".$this::COLUMN_ARTISAN_MATRICULE." varchar(500),
                                ".$this::COLUMN_CORES_USER_ID." bigint unsigned unique NOT NULL,
                                PRIMARY KEY (".$this::COLUMN_ARTISAN_ID."),
                                FOREIGN KEY (".$this::COLUMN_CORES_USER_ID.") REFERENCES ".UserDataSource::TABLE_NAME." (".UserDataSource::COLUMN_ID.") ON DELETE CASCADE ON UPDATE CASCADE
                             );
                    ");
            if(!$query->execute()){
                throw new \Exception($query->errorInfo()[2]);
            }
        } catch (Exception $ex) {
            echo"Impossible de créer la table ".$this::TABLE_NAME." ".$e->getMessage()."";
            die();
        }
    }
    
    public function addArtisanUser($artisanCompanyName, $artisanJusidicStatus, $artisanAssociationName, $artisanFederationAppartenance, 
            $artisanFormator, $artisanMatricule, $coresUserId):int{
        
        $out = 0;
        
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES(?, ?, ?, ?, ?, ?, ?);
                ");
        $query->bindValue(1, $artisanCompanyName, \PDO::PARAM_STR);
        $query->bindValue(2, $artisanJusidicStatus, \PDO::PARAM_INT);
        $query->bindValue(3, $artisanAssociationName, \PDO::PARAM_STR);
        $query->bindValue(4, $artisanFederationAppartenance, \PDO::PARAM_STR);
        $query->bindValue(5, $artisanFormator, \PDO::PARAM_STR);
        $query->bindValue(6, $artisanMatricule, \PDO::PARAM_STR);
        $query->bindValue(7, $coresUserId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->DbPdo->lastInsertId();
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    public function getArtisanUserNumb():int{
        $out = 0;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_ARTISAN_ID.") AS numb FROM ".$this::TABLE_NAME.";
                ");
        if($query->execute()){
            while($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function completeArtisanProfile($userId, $artisanCompanyName, $artisanJuridicStatus, $artisanAssociationName, $artisanFederation, 
            $artisanFormator):bool{
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_ARTISAN_COMPANY_NAME." = ?, ".$this::COLUMN_ARTISAN_JURIDIC_STATUS." = ?, 
                    ".$this::COLUMN_ARTISAN_ASSOCIATION_NAME." = ?, ".$this::COLUMN_FEDERATION_APPARTENANCE." = ?, 
                    ".$this::COLUMN_ARTISAN_FORMATOR." = ? 
                        WHERE ".$this::COLUMN_CORES_USER_ID." = ?
                ");
        $i = 1;
        $query->bindValue($i++, $artisanCompanyName, \PDO::PARAM_STR);
        $query->bindValue($i++, $artisanJuridicStatus, \PDO::PARAM_INT);
        $query->bindValue($i++, $artisanAssociationName, \PDO::PARAM_STR);
        $query->bindValue($i++, $artisanFederation, \PDO::PARAM_STR);
        $query->bindValue($i++, $artisanFormator, \PDO::PARAM_STR);
        $query->bindValue($i++, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        
        if(!$out){
            throw new \Exception($query->errorInfo()[2]);
            
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function setArtisanMatricule($userId, $matricule):bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_ARTISAN_MATRICULE." = ? WHERE ".$this::COLUMN_CORES_USER_ID." = ?;
                ");
        $query->bindValue(1, $matricule, \PDO::PARAM_STR);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new \Exception($query->errorInfo()[2]);
            
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getArtisanUser($userId):ArtisanUser{
        $out = ArtisanUser::getEmptyArtisanUser();
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::COLUMN_ARTISAN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_CORES_USER_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToArtisanUser($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        
        return $out;
    }
    
    
    public function queryToArtisanUser(\PDOStatement $query):ArtisanUser{
        $out = ArtisanUser::getEmptyArtisanUser();
        
        if($data = $query->fetch()){
            $out = new ArtisanUser($data[$this::COLUMN_ARTISAN_ID], $data[$this::COLUMN_ARTISAN_COMPANY_NAME], $data[$this::COLUMN_ARTISAN_JURIDIC_STATUS], $data[$this::COLUMN_ARTISAN_ASSOCIATION_NAME], 
                    $data[$this::COLUMN_FEDERATION_APPARTENANCE], $data[$this::COLUMN_ARTISAN_FORMATOR], $data[$this::COLUMN_ARTISAN_MATRICULE], $data[$this::COLUMN_CORES_USER_ID]);
        }
        
        return $out;
    }
    
    public function queryToArtisanUsers(\PDOStatement $query):array{
        $out = Array();
        
        $i = 0;
        while($data = $query->fetch()){
            $out[$i++] = new ArtisanUser($data[$this::COLUMN_ARTISAN_ID], $data[$this::COLUMN_ARTISAN_COMPANY_NAME], $data[$this::COLUMN_ARTISAN_JURIDIC_STATUS], $data[$this::COLUMN_ARTISAN_ASSOCIATION_NAME], 
                    $data[$this::COLUMN_FEDERATION_APPARTENANCE], $data[$this::COLUMN_ARTISAN_FORMATOR], $data[$this::COLUMN_ARTISAN_MATRICULE], $data[$this::COLUMN_CORES_USER_ID]);
        }
        
        return $out;
    }
}
