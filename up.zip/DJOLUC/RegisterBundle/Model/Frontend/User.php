<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;

require_once 'UserDataSource.php';
require_once 'ProfilPictureDataSource.php';
require_once 'DJOLUC/Helper/php/DateManager.php';

use DJOLUC\Helper;

/**
 * Description of User
 *
 * @author djoluc
 */

class User {
    private $userId,
            $userType,
            $userNom,
            $userPrenomsJson,
            $userBornDate, 
            $userBornLocation,
            $userSexe, 
            $userPhoneNumber, 
            $userMail,
            $userProfession, 
            $userGeolocal,
            $userTown,
            $userQuartier,
            $userLastVisiteTime, 
            $userLastLoadTime, 
            $userRang, 
            $userInscriptConfPass, 
            $userConfInscript, 
            $userActifStatus, 
            $userActivity, 
            $userInscriptTime;
    
    /**
     * 
     * @param type $userId
     * @param type $userType
     * @param type $userNom
     * @param type $userPrenomsJson
     * @param type $userBornDate
     * @param type $userBornLocation
     * @param type $userSexe
     * @param type $userPhoneNumber
     * @param type $userMail
     * @param type $userProfession
     * @param type $userGeolocal
     * @param type $userLastVisiteTime
     * @param type $userLastLoadTime
     * @param type $userRang
     * @param type $userInscriptConfPass
     * @param type $userConfInscript
     * @param type $userActifStatus
     * @param type $userActivity
     * @param type $userInscriptTime
     */
    
    public function __construct($userId, $userType, $userNom, $userPrenomsJson, $userBornDate, $userBornLocation, $userSexe, $userPhoneNumber, $userMail, 
            $userProfession, $userGeolocal, $userTown, $userQuartier, $userLastVisiteTime, $userLastLoadTime, $userRang, $userInscriptConfPass, $userConfInscript, $userActifStatus, 
            $userActivity, $userInscriptTime) {
        
        $this->userId = $userId;
        $this->userType = $userType;
        $this->userNom = $userNom;
        $this->userPrenomsJson = $userPrenomsJson;
        $this->userBornDate = $userBornDate;
        $this->userBornLocation = $userBornLocation;
        $this->userSexe = $userSexe;
        $this->userPhoneNumber = $userPhoneNumber;
        $this->userMail = $userMail;
        $this->userProfession = $userProfession;
        $this->userGeolocal = $userGeolocal;
        $this->userTown = $userTown;
        $this->userQuartier = $userQuartier;
        $this->userLastVisiteTime = $userLastVisiteTime;
        $this->userLastLoadTime = $userLastLoadTime;
        $this->userRang = $userRang;
        $this->userInscriptConfPass = $userInscriptConfPass;
        $this->userConfInscript = $userConfInscript;
        $this->userActifStatus = $userActifStatus;
        $this->userActivity = $userActivity;
        $this->userInscriptTime = $userInscriptTime;
    }
    
    public function getUserId() {
        return $this->userId;
    }

    public function getUserType() {
        return $this->userType;
    }

    public function getUserNom() {
        return $this->userNom;
    }

    public function getUserPrenomsJson() {
        return $this->userPrenomsJson;
    }

    public function getUserBornDate() {
        return $this->userBornDate;
    }

    public function getUserBornLocation() {
        return $this->userBornLocation;
    }

    public function getUserSexe() {
        return $this->userSexe;
    }

    public function getUserPhoneNumber() {
        return $this->userPhoneNumber;
    }

    public function getUserMail() {
        return $this->userMail;
    }

    public function getUserProfession() {
        return $this->userProfession;
    }

    public function getUserGeolocal() {
        return $this->userGeolocal;
    }
    
    public function getUserTown(){
        return $this->userTown;
    }

    public function getUserLastVisiteTime() {
        return $this->userLastVisiteTime;
    }

    public function getUserLastLoadTime() {
        return $this->userLastLoadTime;
    }

    public function getUserRang() {
        return $this->userRang;
    }

    public function getUserInscriptConfPass() {
        return $this->userInscriptConfPass;
    }

    public function getUserConfInscript() {
        return $this->userConfInscript;
    }

    public function getUserActifStatus() {
        return $this->userActifStatus;
    }

    public function getUserActivity() {
        return $this->userActivity;
    }

    public function getUserInscriptTime() {
        return $this->userInscriptTime;
    }

    public function setUserId($userId) {
        $this->userId = $userId;
    }

    public function setUserType($userType) {
        $this->userType = $userType;
    }

    public function setUserNom($userNom) {
        $this->userNom = $userNom;
    }

    public function setUserPrenomsJson($userPrenomsJson) {
        $this->userPrenomsJson = $userPrenomsJson;
    }

    public function setUserBornDate($userBornDate) {
        $this->userBornDate = $userBornDate;
    }

    public function setUserBornLocation($userBornLocation) {
        $this->userBornLocation = $userBornLocation;
    }

    public function setUserSexe($userSexe) {
        $this->userSexe = $userSexe;
    }

    public function setUserPhoneNumber($userPhoneNumber) {
        $this->userPhoneNumber = $userPhoneNumber;
    }

    public function setUserMail($userMail) {
        $this->userMail = $userMail;
    }

    public function setUserProfession($userProfession) {
        $this->userProfession = $userProfession;
    }

    public function setUserGeolocal($userGeolocal) {
        $this->userGeolocal = $userGeolocal;
    }
    
    public function setUserTown($userTown){
        $this->userTown = $userTown;
    }
    
    public function getUserQuartier() {
        return $this->userQuartier;
    }

    public function setUserQuartier($userQuartier) {
        $this->userQuartier = $userQuartier;
    }

    
    public function setUserLastVisiteTime($userLastVisiteTime) {
        $this->userLastVisiteTime = $userLastVisiteTime;
    }

    public function setUserLastLoadTime($userLastLoadTime) {
        $this->userLastLoadTime = $userLastLoadTime;
    }

    public function setUserRang($userRang) {
        $this->userRang = $userRang;
    }

    public function setUserInscriptConfPass($userInscriptConfPass) {
        $this->userInscriptConfPass = $userInscriptConfPass;
    }

    public function setUserConfInscript($userConfInscript) {
        $this->userConfInscript = $userConfInscript;
    }

    public function setUserActifStatus($userActifStatus) {
        $this->userActifStatus = $userActifStatus;
    }

    public function setUserActivity($userActivity) {
        $this->userActivity = $userActivity;
    }

    public static function setUserInscriptTime($userInscriptTime) {
        $this->userInscriptTime = $userInscriptTime;
    }
    
    public function getUserProfilPicture(){
        $profilPictureDataSource = new ProfilPictureDataSource();
        
        return $profilPictureDataSource->getUserCurrentPicture($this->userId)->getProfilePictureLink();
    }
    
    
    public function getUserProfilPictureObject(){
        $profilPictureDataSource = new ProfilPictureDataSource();
        
        return $profilPictureDataSource->getUserCurrentPicture($this->userId);
    }
    
    
    
    public function getUserProfilMiniPicture(){
        $profilPictureDataSource = new ProfilPictureDataSource();
        
        return $profilPictureDataSource->getUserCurrentPicture($this->userId)->getProfilePictureMiniLink();
    }
    
    public function getUserLastLoadReference(){
        $dateManager = new Helper\php\DateManager();
        
        return $dateManager->getDateReference($this->userLastLoadTime);
    }
    
    
    public function getUserOnlineStatus():string{
        return $this->userActifStatus?"Online":"Online ".$this->getUserLastLoadReference()."";
    }
    
    public function getUserBirthdayString():string{
        $dateManager = new Helper\php\DateManager();
        
        return $dateManager->getShortReference($this->userBornDate);
    }
    
    public function getUserBirthdayDay(){
        $dateManager = new Helper\php\DateManager($this->userBornDate);
        
        return $dateManager->getDayOfMouthNum();
    }
    
    
    public function getUserBirthdayMouth(){
        $dateManager = new Helper\php\DateManager($this->userBornDate);
        
        return $dateManager->getMouthOfYearNum();
    }

    public function getUserBirthdayYear(){
        $dateManager = new Helper\php\DateManager($this->userBornDate);
        
        return $dateManager->getYearFourDigits();
    }

    public function getUserSexeString():string{
        return $this->userSexe==0?"F":"M";
    }
    
    public function getUserFullCountry():string{
        require 'App/data/CountriesArrayData.php';
        
        return empty($CountryArrayShortData[$this->userGeolocal]["nativetongue"])?"":$CountryArrayShortData[$this->userGeolocal]["nativetongue"];
    }
    
    public function getUserCountryPhoneCode():string{
        require 'App/data/CountriesArrayData.php';
        
        return empty($CountryArrayWithPhoneCode[$this->userGeolocal])?"":$CountryArrayWithPhoneCode[$this->userGeolocal]["code"];
    }

    
    /**
     * Return empty instence of class User
     * @return \DJOLUC\MainBundle\Model\User
     */
    public static function getEmptyUser():User{
        return new User(0, 1, "", "", 0, "", 1, "", "", "", "", "", "", 0, 0, 1, "", TRUE, FALSE, FALSE, 0);
    }
    
}
