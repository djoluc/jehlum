<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;

require_once 'DJOLUC/Helper/php/DbSwitcher.php';
require_once 'User.php';
require_once 'DJOLUC/Helper/php/DateManager.php';
require_once 'ProfilPictureDataSource.php';
require_once 'DJOLUC/RegisterBundle/Controller/Frontend/SessionManageController.php';
require_once 'ArtisanUserNoteDataSource.php';
require_once 'UserPasswordDataSource.php';
require_once 'DJOLUC/RegisterBundle/Helper/Password.php';
require_once 'DJOLUC/LocationBundle/Model/Frontend/CountryDataSource.php';

use DJOLUC\Helper\php;
use Exception;

//use Symfony\Component\Config\Definition\Exception\Exception;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UserDataSource
 *
 * @author djoluc
 */
class UserDataSource {
    const TABLE_NAME = "user_table";
    const COLUMN_ID = "user_id";
    const COLUMN_USER_TYPE = "user_type";
    const COLUMN_USER_NOM = "user_nom";
    const COLUMN_USER_PRENOM_JSON = "user_prenoms";
    const COLUMN_USER_BORN_DATE = "user_born_date";
    const COLUMN_USER_BORN_LOCATION = "user_born_location";
    const COLUMN_USER_SEXE = "user_sexe";
    const COLUMN_USER_PHONE_NUMBER = "user_phone_number";
    const COLUMN_USER_MAIL = "user_mail"; 
    const COLUMN_USER_PROFESSION = "user_profession";
    const COLUMN_USER_GEOLOCAL = "user_geolocal";
    const COLUMN_USER_TOWN = "user_town";
    const COLUMN_USER_QUARTIER = "user_quartier";
    const COLUMN_USER_LAST_VISITE_TIME = "user_last_visite_time";
    const COLUMN_USER_LAST_LOAD_TIME = "user_last_load_time";
    const COLUMN_USER_RANG = "user_rang";
    const COLUMN_USER_INSCRIPT_CONF_PASS = "user_inscript_conf_pass";
    const COLUMN_USER_CONF_INSCRIPT = "user_conf_inscript";
    const COLUMN_ACTIF_STATUS = "user_actif_status";
    const COLUMN_ACTIVITY = "user_activity";
    const COLUMN_INSCRIPT_TIME = "user_inscript_time";
    
    
    public $AllColumn;
    
    const NORMAL_USER_TYPE = 1;
    const ARTISAN_USER_TYPE = 2;
    
    
    const SIMPLE_RANG = 1;
    const MODO_RAND = 2;
    const MINI_ADM_RANG = 3;
    const ADM_RANG = 4;
    
    const ENABLED_INACTIVITI_TIME = 600; //seconde
    
    private $DbPdo;
    private $DbPdoOk;
    private $PropertyOk;
    private $UserTable;
    
    private $dateManager, 
            $profilPictureDataSource;
    
    public function __construct() {
        $this->UserTable = null;
        
         $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $this->AllColumn = "".$this::COLUMN_USER_TYPE."".", ".$this::COLUMN_USER_NOM.", ".$this::COLUMN_USER_PRENOM_JSON.
                ", ".$this::COLUMN_USER_BORN_DATE.", ".$this::COLUMN_USER_BORN_LOCATION.", ".$this::COLUMN_USER_SEXE.
                ", ".$this::COLUMN_USER_PHONE_NUMBER.", ".$this::COLUMN_USER_MAIL.", ".$this::COLUMN_USER_PROFESSION.
                ", ".$this::COLUMN_USER_GEOLOCAL.", ".$this::COLUMN_USER_TOWN.", ".$this::COLUMN_USER_QUARTIER.", ".$this::COLUMN_USER_LAST_VISITE_TIME.", ".$this::COLUMN_USER_LAST_LOAD_TIME.
                ", ".$this::COLUMN_USER_RANG.", ".$this::COLUMN_USER_INSCRIPT_CONF_PASS.", ".$this::COLUMN_USER_CONF_INSCRIPT.
                ", ".$this::COLUMN_ACTIF_STATUS.", ".$this::COLUMN_ACTIVITY.", ".$this::COLUMN_INSCRIPT_TIME."";
        
        $dbswitch = new php\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTableUser();
            $this->addFirstAdmUser();
            $this->DbPdoOk = TRUE;
        }
        
        
        $this->dateManager = new php\DateManager();
        $this->profilPictureDataSource = new ProfilPictureDataSource();
        
    }
    
    
    public function createTableUser(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                        CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME."
                            (
                                ".$this::COLUMN_ID." bigint unsigned NOT NULL AUTO_INCREMENT,
                                ".$this::COLUMN_USER_TYPE." INT , 
                                ".$this::COLUMN_USER_NOM." varchar(200), 
                                ".$this::COLUMN_USER_PRENOM_JSON." text, 
                                ".$this::COLUMN_USER_BORN_DATE." bigint,
                                ".$this::COLUMN_USER_BORN_LOCATION." varchar(500), 
                                ".$this::COLUMN_USER_SEXE." int, 
                                ".$this::COLUMN_USER_PHONE_NUMBER." varchar(200), 
                                ".$this::COLUMN_USER_MAIL." varchar(200), 
                                ".$this::COLUMN_USER_PROFESSION." varchar(500), 
                                ".$this::COLUMN_USER_GEOLOCAL." text,
                                ".$this::COLUMN_USER_TOWN." varchar(300), 
                                ".$this::COLUMN_USER_QUARTIER." varchar(300), 
                                ".$this::COLUMN_USER_LAST_VISITE_TIME." bigint,
                                ".$this::COLUMN_USER_LAST_LOAD_TIME." bigint, 
                                ".$this::COLUMN_USER_RANG." INT , 
                                ".$this::COLUMN_USER_INSCRIPT_CONF_PASS." text,
                                ".$this::COLUMN_USER_CONF_INSCRIPT." bool NOT NULL DEFAULT false, 
                                ".$this::COLUMN_ACTIF_STATUS." bool NOT NULL DEFAULT false, 
                                ".$this::COLUMN_ACTIVITY." bool NOT NULL DEFAULT true, 
                                ".$this::COLUMN_INSCRIPT_TIME." bigint, 
                                PRIMARY KEY (".$this::COLUMN_ID.")
                            );
                    ");
            if(!$query->execute()){
                throw new \Exception($query->errorInfo()[2]);
            }
            $query->closeCursor();
        } catch (Exception $e) {
            echo"Impossible de créer la table block ".$e->getMessage()."";
            die();
        }
    }
    
    public function testProperty():bool{
        return TRUE;
    }
    
    public function addUser($userType, $userNom, $userPrenomsJson, $userBornDate, $userBornLocation, $userSexe, $userPhoneNumber, $userMail, 
            $userProfession, $userGeolocal, $userTown, $quartier, $userLastVisiteTime, $userLastLoadTime, $userRang, $userInscriptConfPass, $userConfInscript, $userActifStatus, 
            $userActivity, $userInscriptTime):int{
        
        $out = 0;
        
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                ");
        $query->bindValue(1, $userType, \PDO::PARAM_INT);
        $query->bindValue(2, $userNom, \PDO::PARAM_STR);
        $query->bindValue(3, $userPrenomsJson, \PDO::PARAM_STR);
        $query->bindValue(4, $userBornDate, \PDO::PARAM_INT);
        $query->bindValue(5, $userBornLocation, \PDO::PARAM_STR);
        $query->bindValue(6, $userSexe, \PDO::PARAM_INT);
        $query->bindValue(7, $userPhoneNumber, \PDO::PARAM_STR);
        $query->bindValue(8, $userMail, \PDO::PARAM_STR);
        $query->bindValue(9, $userProfession, \PDO::PARAM_STR);
        $query->bindValue(10, $userGeolocal, \PDO::PARAM_STR);
        $query->bindValue(11, $userTown, \PDO::PARAM_STR);
        $query->bindValue(12, $quartier, \PDO::PARAM_STR);
        $query->bindValue(13, $userLastVisiteTime, \PDO::PARAM_INT);
        $query->bindValue(14, $userLastLoadTime, \PDO::PARAM_INT);
        $query->bindValue(15, $userRang, \PDO::PARAM_INT);
        $query->bindValue(16, $userInscriptConfPass, \PDO::PARAM_STR);
        $query->bindValue(17, $userConfInscript, \PDO::PARAM_BOOL);
        $query->bindValue(18, $userActifStatus, \PDO::PARAM_BOOL);
        $query->bindValue(19, $userActivity, \PDO::PARAM_BOOL);
        $query->bindValue(20, $userInscriptTime, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->DbPdo->lastInsertId();
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function deleteUser($userId){
        $out = FALSE;
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_ID." = ?
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = true;
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getUserNumb($currentUserId):int{
        $out = 0;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_ID.") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_ID." != ?
                ");
        $query->bindValue(1, $currentUserId, \PDO::PARAM_INT);
        if($query->execute()){
            while($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function completeUserProfile($userId, $nom, $prenoms, $userBornDate, $userBornLocation, $userSexe, 
            $userPhoneNumber, $userProfession, $userGeolocal, $userTown, $userQuartier):bool{
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_USER_NOM." = ?, ".$this::COLUMN_USER_PRENOM_JSON." = ?, ".$this::COLUMN_USER_BORN_DATE." = ?, 
                    ".$this::COLUMN_USER_BORN_LOCATION." = ?, ".$this::COLUMN_USER_SEXE." = ?, ".$this::COLUMN_USER_PHONE_NUMBER." = ?, 
                    ".$this::COLUMN_USER_PROFESSION." = ?, ".$this::COLUMN_USER_GEOLOCAL." = ?, ".$this::COLUMN_USER_TOWN." = ?, ".$this::COLUMN_USER_QUARTIER." = ? 
                        WHERE ".$this::COLUMN_ID." = ?
                ");
        $i = 1;
        $query->bindValue($i++, $nom, \PDO::PARAM_STR);
        $query->bindValue($i++, $prenoms, \PDO::PARAM_STR);
        $query->bindValue($i++, $userBornDate, \PDO::PARAM_INT);
        $query->bindValue($i++, $userBornLocation, \PDO::PARAM_STR);
        $query->bindValue($i++, $userSexe, \PDO::PARAM_INT);
        $query->bindValue($i++, $userPhoneNumber, \PDO::PARAM_STR);
        $query->bindValue($i++, $userProfession, \PDO::PARAM_STR);
        $query->bindValue($i++, $userGeolocal, \PDO::PARAM_STR);
        $query->bindValue($i++, $userTown, \PDO::PARAM_STR);
        $query->bindValue($i++, $userQuartier, \PDO::PARAM_STR);
        $query->bindValue($i++, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getUser($userId):User{
        $out = User::getEmptyUser();
        
        $query = $this->DbPdo->prepare
                ("
                   SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_ID." = ?
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUser($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getArtisanUsersWithBetterNote($numb, $premier):array{
        $out = Array();
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::TABLE_NAME.".".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." 
                    RIGHT JOIN ".ArtisanUserNoteDataSource::TABLE_NAME." ON ".$this::TABLE_NAME.".".$this::COLUMN_ID." = ".ArtisanUserNoteDataSource::TABLE_NAME.".".ArtisanUserNoteDataSource::COLUMN_ARTISAN_USER_ID." 
                    GROUP BY ".$this::TABLE_NAME.".".$this::COLUMN_ID." ORDER BY (SUM(".ArtisanUserNoteDataSource::COLUMN_NOTE.")/COUNT(".ArtisanUserNoteDataSource::TABLE_NAME.".".ArtisanUserNoteDataSource::COLUMN_USER_ID.")) DESC LIMIT ?, ?;
                ");
        $query->bindValue(1, $premier, \PDO::PARAM_INT);
        $query->bindValue(2, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUsers($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getArtisanUsers($numb, $premier):array{
        $out = Array();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::TABLE_NAME.".".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_TYPE." = ? LIMIT ?, ?;
                ");
        $query->bindValue(1, $this::ARTISAN_USER_TYPE, \PDO::PARAM_INT);
        $query->bindValue(2, $premier, \PDO::PARAM_INT);
        $query->bindValue(3, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUsers($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getActifArtisans($numb, $premier):array{
        $out = Array();
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::TABLE_NAME.".".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_TYPE." = ? AND ".$this::COLUMN_ACTIF_STATUS." = ? AND ".$this::COLUMN_ID." != ? LIMIT ?, ?;
                ");
        $query->bindValue(1, $this::ARTISAN_USER_TYPE, \PDO::PARAM_INT);
        $query->bindValue(2, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue(3, $this::getCurrentUserId(), \PDO::PARAM_INT);
        $query->bindValue(4, $premier, \PDO::PARAM_INT);
        $query->bindValue(5, $numb, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUsers($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }


    public function getUserWithMail($email):User{
        $out = User::getEmptyUser();
        
        $query = $this->DbPdo->prepare
                ("
                   SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_MAIL." = ?
                ");
        $query->bindValue(1, $email, \PDO::PARAM_STR);
        if($query->execute()){
            $out = $this->queryToUser($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getUserWithPhone($phone):User{
        $out = User::getEmptyUser();
        
        $query = $this->DbPdo->prepare
                ("
                   SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_PHONE_NUMBER." = ?
                ");
        $query->bindValue(1, $phone, \PDO::PARAM_STR);
        if($query->execute()){
            $out = $this->queryToUser($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function isArtisan($userId):bool{
        return $this->getUser($userId)->getUserType()==$this::ARTISAN_USER_TYPE?TRUE:FALSE;
    }
    
    public function isMailUsed($mail):bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_ID.") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_MAIL." = ?;
                ");
        $query->bindValue(1, $mail, \PDO::PARAM_STR);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"]>0?true:false;
            }else{
                throw new Exception($query->errorInfo()[2]);
            }
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function isPhoneUsed($phone, $country):bool{
         $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_ID.") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_PHONE_NUMBER." = ? AND ".$this::COLUMN_USER_GEOLOCAL." = ?;
                ");
        $query->bindValue(1, $phone, \PDO::PARAM_STR);
        $query->bindValue(2, $country, \PDO::PARAM_STR);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"]>0?true:false;
            }else{
                throw new Exception($query->errorInfo()[2]);
            }
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function updateUserStatus($userId, $status = true):bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_ACTIF_STATUS." = ? WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, $status, \PDO::PARAM_BOOL);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function updateUsersStatusWithTimestamp(){
        $timestamp = \time() - $this::ENABLED_INACTIVITI_TIME;
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_ACTIF_STATUS." = ? WHERE ".$this::COLUMN_USER_LAST_LOAD_TIME." < ?;
                ");
        $query->bindValue(1, FALSE, \PDO::PARAM_BOOL);
        $query->bindValue(2, $timestamp, \PDO::PARAM_INT);
        $query->execute();
        $query->closeCursor();
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_ACTIF_STATUS." = ? WHERE ".$this::COLUMN_USER_LAST_LOAD_TIME." >= ?;
                ");
        $query->bindValue(1, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue(2, $timestamp, \PDO::PARAM_INT);
        $query->execute();
        $query->closeCursor();
    }
    
    public function updateUserRang($userId, $newRang):bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_USER_RANG." = ? WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, $newRang, \PDO::PARAM_BOOL);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
  
            }
        $query->closeCursor();
        
        return $out;
    }
    
    public function updateUserActivity($userId, $newActivity):bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_ACTIVITY." = ? WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, $newActivity, \PDO::PARAM_BOOL);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function updateUserLastLoad($timestamp, $userId){
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_USER_LAST_LOAD_TIME." = ? WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, $timestamp, \PDO::PARAM_INT);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $query->execute();
        $query->closeCursor();
    }
    
    public function updateUserLastVisite($timestamp, $userId){
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_USER_LAST_VISITE_TIME." = ? WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, $timestamp, \PDO::PARAM_INT);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $query->execute();
        $query->closeCursor();
    }
    
    
    public function updateUserConfPass($pass, $userId):bool{
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_USER_INSCRIPT_CONF_PASS." = ? WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, $pass, \PDO::PARAM_STR);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function activateUserAccount($userId):bool{
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_USER_CONF_INSCRIPT." = ? WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        $query->closeCursor();
        
        return $out;
    }
    
    public function getAllUser($currentUserId, $premier = 0, $nombre = 50, $filter = ""):array{
        $out = "";
        
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME."
                    WHERE ".$this::COLUMN_ID." != ? 
                   ORDER BY ".$this::COLUMN_INSCRIPT_TIME." DESC LIMIT ?, ?;
                ");
        $query->bindValue(1, $currentUserId, \PDO::PARAM_INT);
        $query->bindValue(2, $premier, \PDO::PARAM_INT);
        $query->bindValue(3, $nombre, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUsers($query);
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getSearchUserNumb($currentUserId, $txt, $filter = ""):int{
        $out = 0;
        
        $userQuery = "";
        if($filter == "artisan"){
            $userQuery  = "".$this::COLUMN_USER_TYPE." = ".$this::ARTISAN_USER_TYPE." AND ";
        }else if($filter == "adm"){
            $userQuery  = "".$this::COLUMN_USER_RANG." > ".$this::NORMAL_USER_TYPE." AND ";
        }
        
        $txt = strtolower($txt);
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_ID.") AS numb FROM ".$this::TABLE_NAME."
                    WHERE ".$this::COLUMN_ID." != ? AND ".$userQuery." 
                    (
                        lower(".$this::COLUMN_USER_NOM.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PRENOM_JSON.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_TOWN.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_QUARTIER.") LIKE ? OR 
                        lower(CONCAT(".$this::COLUMN_USER_NOM.", ' ', ".$this::COLUMN_USER_PRENOM_JSON.")) LIKE ?
                    );
                ");
        $query->bindValue(1, $currentUserId, \PDO::PARAM_INT);
        $query->bindValue(2, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(3, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(4, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(5, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(6, "%".$txt."%", \PDO::PARAM_STR);
        if($query->execute()){
            while($data = $query->fetch()){
                $out = $data["numb"];
            }
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getAllUserJson($currentUserId, $txt, $premier = 0, $nombre = 50, $filter = ""):string{
        $out = Array();
        
        $userQuery = "";
        if($filter == "artisan"){
            $userQuery  = "".$this::COLUMN_USER_TYPE." = ".$this::ARTISAN_USER_TYPE." AND ";
        }else if($filter == "adm"){
            $userQuery  = "".$this::COLUMN_USER_RANG." > ".$this::NORMAL_USER_TYPE." AND ";
        }
        
        $txt = strtolower($txt);
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME."
                    WHERE ".$this::COLUMN_ID." != ? AND ".$userQuery." 
                    (
                        lower(".$this::COLUMN_USER_NOM.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PRENOM_JSON.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_TOWN.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_QUARTIER.") LIKE ? OR 
                        lower(CONCAT(".$this::COLUMN_USER_NOM.", ' ', ".$this::COLUMN_USER_PRENOM_JSON.")) LIKE ?
                    )
                   ORDER BY ".$this::COLUMN_INSCRIPT_TIME." DESC LIMIT ?, ?;
                ");
        $query->bindValue(1, $currentUserId, \PDO::PARAM_INT);
        $query->bindValue(2, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(3, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(4, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(5, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(6, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(7, $premier, \PDO::PARAM_INT);
        $query->bindValue(8, $nombre, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToArray($query);
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $loadedNumb = $query->rowCount();
        $query->closeCursor();
        
        $bigOut = Array(
            "users"=>$out, 
            "userNumb"=>$this->getSearchUserNumb($currentUserId, $txt, $filter),
            "loadedNumb"=>$loadedNumb
        );
        
        return json_encode($bigOut);
    }
    
    
    public function getUserSearchPropositionAsJson($currentUserId ,$number, $txt, $filter = ""):string{
        
        $array = Array();
        
        $userQuery = "";
        if($filter == "artisan"){
            $userQuery  = "".$this::COLUMN_USER_TYPE." = ".$this::ARTISAN_USER_TYPE." AND ";
        }else if($filter == "adm"){
            $userQuery  = "".$this::COLUMN_USER_RANG." > ".$this::NORMAL_USER_TYPE." AND ";
        }
        
        $txt = strtolower($txt);
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME."
                    WHERE ".$this::COLUMN_ID." != ? AND ".$userQuery." 
                    (
                        lower(".$this::COLUMN_USER_NOM.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PRENOM_JSON.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_TOWN.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_QUARTIER.") LIKE ? OR 
                        lower(CONCAT(".$this::COLUMN_USER_NOM.", ' ', ".$this::COLUMN_USER_PRENOM_JSON.")) LIKE ?
                    ) 
                   ORDER BY ".$this::COLUMN_INSCRIPT_TIME." DESC LIMIT ?, ?;
                ");
        $query->bindValue(1, $currentUserId, \PDO::PARAM_INT);
        $query->bindValue(2, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(3, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(4, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(5, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(6, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(7, 0, \PDO::PARAM_INT);
        $query->bindValue(8, $number, \PDO::PARAM_INT);
        if($query->execute()){
            $i = 0;
            while($data = $query->fetch()){
                $array[$i++] = $data[$this::COLUMN_USER_NOM]." ".$data[$this::COLUMN_USER_PRENOM_JSON]."";
            }
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return json_encode($array);
    }
    
    
    
    public function getUserSearchPropositionAsArray($currentUserId ,$number, $txt, $filter = ""):array{
        
        $array = Array();
        
        $userQuery = "";
        if($filter == "artisan"){
            $userQuery  = "".$this::COLUMN_USER_TYPE." = ".$this::ARTISAN_USER_TYPE." AND ";
        }else if($filter == "adm"){
            $userQuery  = "".$this::COLUMN_USER_RANG." > ".$this::NORMAL_USER_TYPE." AND ";
        }
        
        
        $txt = strtolower($txt);
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME."
                    WHERE ".$this::COLUMN_ID." != ? AND ".$userQuery." 
                    (
                        lower(".$this::COLUMN_USER_NOM.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PRENOM_JSON.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_TOWN.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_QUARTIER.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PROFESSION.") LIKE ? OR  
                        lower(".$this::COLUMN_USER_GEOLOCAL.") IN  
                            (SELECT lower(".\DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::COLUMN_COUNTRY_SLUG.") FROM ".\DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::TABLE_NAME." WHERE lower(".\DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::COLUMN_COUNTRY_NAME.") LIKE ?)
                            OR 
                        lower(CONCAT(".$this::COLUMN_USER_NOM.", ' ', ".$this::COLUMN_USER_PRENOM_JSON.")) LIKE ?
                    ) 
                   ORDER BY ".$this::COLUMN_INSCRIPT_TIME." DESC LIMIT ?, ?;
                ");
        $query->bindValue(1, $currentUserId, \PDO::PARAM_INT);
        $query->bindValue(2, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(3, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(4, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(5, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(6, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(7, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(8, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(9, 0, \PDO::PARAM_INT);
        $query->bindValue(10, $number, \PDO::PARAM_INT);
        if($query->execute()){
            $i = 0;
            while($data = $query->fetch()){
                if(!empty($data[$this::COLUMN_USER_NOM])) $array[$i++] = $data[$this::COLUMN_USER_NOM]." ".$data[$this::COLUMN_USER_PRENOM_JSON]."";
                if(!empty($data[$this::COLUMN_USER_TOWN])) $array[$i++] = $data[$this::COLUMN_USER_TOWN]."";
                if(!empty($data[$this::COLUMN_USER_QUARTIER])) $array[$i++] = $data[$this::COLUMN_USER_QUARTIER]."";
                if(!empty($data[$this::COLUMN_USER_PROFESSION])) $array[$i++] = $data[$this::COLUMN_USER_PROFESSION]."";
            }
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $array;
    }
    
    
    
    public function getSearchUsers($currentUserId ,$number, $txt, $filter = ""):array{
        
        $out = Array();
        
        $userQuery = "";
        if($filter == "artisan"){
            $userQuery  = "".$this::COLUMN_USER_TYPE." = ".$this::ARTISAN_USER_TYPE." AND ";
        }else if($filter == "adm"){
            $userQuery  = "".$this::COLUMN_USER_RANG." > ".$this::NORMAL_USER_TYPE." AND ";
        }
        
        
        $txt = strtolower($txt);
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::TABLE_NAME.".".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME."
                    WHERE ".$this::TABLE_NAME.".".$this::COLUMN_ID." != ? AND ".$userQuery."
                    (
                        lower(".$this::COLUMN_USER_NOM.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PRENOM_JSON.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_TOWN.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_QUARTIER.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PROFESSION.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_GEOLOCAL.") IN  
                            (SELECT lower(".\DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::COLUMN_COUNTRY_SLUG.") FROM ".\DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::TABLE_NAME." WHERE lower(".\DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::COLUMN_COUNTRY_NAME.") LIKE ?)
                            OR 
                        lower(CONCAT(".$this::COLUMN_USER_NOM.", ' ', ".$this::COLUMN_USER_PRENOM_JSON.")) LIKE ?
                    ) 
                   ORDER BY ".$this::COLUMN_INSCRIPT_TIME." DESC LIMIT ?, ?;
                ");
        $query->bindValue(1, $currentUserId, \PDO::PARAM_INT);
        $query->bindValue(2, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(3, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(4, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(5, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(6, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(7, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(8, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(9, 0, \PDO::PARAM_INT);
        $query->bindValue(10, $number, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUsers($query);
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function getSearchUsersWithQuartier($currentUserId ,$number, $txt, $filter = "", $quartier = ""):array{
        
        $out = Array();
        
        $userQuery = "";
        if($filter == "artisan"){
            $userQuery  = "".$this::COLUMN_USER_TYPE." = ".$this::ARTISAN_USER_TYPE." AND ";
        }else if($filter == "adm"){
            $userQuery  = "".$this::COLUMN_USER_RANG." > ".$this::NORMAL_USER_TYPE." AND ";
        }
        
        
        $txt = strtolower($txt);
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::TABLE_NAME.".".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME."
                    WHERE ".$this::TABLE_NAME.".".$this::COLUMN_ID." != ? AND ".$userQuery." lower(".$this::COLUMN_USER_QUARTIER.") LIKE ? AND 
                    (
                        lower(".$this::COLUMN_USER_NOM.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PRENOM_JSON.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_TOWN.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_QUARTIER.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_PROFESSION.") LIKE ? OR 
                        lower(".$this::COLUMN_USER_GEOLOCAL.") IN  
                            (SELECT lower(". \DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::COLUMN_COUNTRY_SLUG.") FROM ".\DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::TABLE_NAME." WHERE lower(".\DJOLUC\LocationBundle\Model\Frontend\CountryDataSource::COLUMN_COUNTRY_NAME.") LIKE ?)
                            OR 
                        lower(CONCAT(".$this::COLUMN_USER_NOM.", ' ', ".$this::COLUMN_USER_PRENOM_JSON.")) LIKE ?
                    ) 
                   ORDER BY ".$this::COLUMN_INSCRIPT_TIME." DESC LIMIT ?, ?;
                ");
        $query->bindValue(1, $currentUserId, \PDO::PARAM_INT);
        $query->bindValue(2, $quartier, \PDO::PARAM_STR);
        $query->bindValue(3, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(4, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(5, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(6, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(7, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(8, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(9, "%".$txt."%", \PDO::PARAM_STR);
        $query->bindValue(10, 0, \PDO::PARAM_INT);
        $query->bindValue(11, $number, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUsers($query);
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function clearUserConfInscriptPass($userId):bool{
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_USER_INSCRIPT_CONF_PASS." = '' WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    
    public static function getCurrentUserId():int{
        $out = 0;
        
        if(isset($_SESSION[\DJOLUC\RegisterBundle\Controller\Frontend\SessionManageController::SESSION_USER_ID])){
            $out = $_SESSION[\DJOLUC\RegisterBundle\Controller\Frontend\SessionManageController::SESSION_USER_ID];
        }
        
        return $out;
        
        
    }
    
    
    public static function getCurentUserRang():int{
        $userId = UserDataSource::getCurrentUserId();
        $userDataSource = new UserDataSource();
        
        return $userDataSource->getUser($userId)->getUserRang();
    }
    
    
    public function isCompleteAcount($userId):bool{
        return !empty($this->getUser($userId)->getUserNom());
    }
    
    
    
    private function queryToUser(\PDOStatement $query):User{
        $out = User::getEmptyUser();
        
        if($data = $query->fetch()){
            $out = new User($data[$this::COLUMN_ID], $data[$this::COLUMN_USER_TYPE], $data[$this::COLUMN_USER_NOM], $data[$this::COLUMN_USER_PRENOM_JSON], 
                    $data[$this::COLUMN_USER_BORN_DATE], $data[$this::COLUMN_USER_BORN_LOCATION], $data[$this::COLUMN_USER_SEXE], $data[$this::COLUMN_USER_PHONE_NUMBER], 
                    $data[$this::COLUMN_USER_MAIL], $data[$this::COLUMN_USER_PROFESSION], $data[$this::COLUMN_USER_GEOLOCAL], $data[$this::COLUMN_USER_TOWN], $data[$this::COLUMN_USER_QUARTIER], $data[$this::COLUMN_USER_LAST_VISITE_TIME], 
                    $data[$this::COLUMN_USER_LAST_LOAD_TIME], $data[$this::COLUMN_USER_RANG], $data[$this::COLUMN_USER_INSCRIPT_CONF_PASS], $data[$this::COLUMN_USER_CONF_INSCRIPT], 
                    $data[$this::COLUMN_ACTIF_STATUS], $data[$this::COLUMN_ACTIVITY], $data[$this::COLUMN_INSCRIPT_TIME]);
        }
        
        return $out;
    }
    
    public function addFirstAdmUser(){
        
        if($this->getUserNumb(0)>=1){
            return;
        }
        
        //$password = new \DJOLUC\RegisterBundle\Helper\Password("AO_tOr8baR*BiG");
        $password = new \DJOLUC\RegisterBundle\Helper\Password("123456789");
        $userPasswordDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserPasswordDataSource();
        
        if($userId = $this->addUser($this::SIMPLE_RANG, "Webmaster", "Adm", 0, "", 1, 66125039, "admin@jehlum.org", "", "BJ", "Calavi", "", 0, 0, $this::ADM_RANG, "", TRUE, FALSE, TRUE, time())){
            $userPasswordDataSource->addUserPassword($password->getHashPassword(), \time(), $userId);
        }
    }
    
    
    private function queryToUsers(\PDOStatement $query):array{
        $out = Array();
        
        $i = 0;
        while($data = $query->fetch()){
            $out[$i++] = new User($data[$this::COLUMN_ID], $data[$this::COLUMN_USER_TYPE], $data[$this::COLUMN_USER_NOM], $data[$this::COLUMN_USER_PRENOM_JSON], 
                    $data[$this::COLUMN_USER_BORN_DATE], $data[$this::COLUMN_USER_BORN_LOCATION], $data[$this::COLUMN_USER_SEXE], $data[$this::COLUMN_USER_PHONE_NUMBER], 
                    $data[$this::COLUMN_USER_MAIL], $data[$this::COLUMN_USER_PROFESSION], $data[$this::COLUMN_USER_GEOLOCAL], $data[$this::COLUMN_USER_TOWN], $data[$this::COLUMN_USER_QUARTIER],  $data[$this::COLUMN_USER_LAST_VISITE_TIME], 
                    $data[$this::COLUMN_USER_LAST_LOAD_TIME], $data[$this::COLUMN_USER_RANG], $data[$this::COLUMN_USER_INSCRIPT_CONF_PASS], $data[$this::COLUMN_USER_CONF_INSCRIPT], 
                    $data[$this::COLUMN_ACTIF_STATUS], $data[$this::COLUMN_ACTIVITY], $data[$this::COLUMN_INSCRIPT_TIME]);
        }
        
        return $out;
    }
    
    private function queryToJson(\PDOStatement $query):string{
        $out = "";
        
        $i = 0;
        while($data = $query->fetch()){
            $out[$i++] = Array(
                "userId"=>$data[$this::COLUMN_ID], 
                "userType"=>$data[$this::COLUMN_USER_TYPE], 
                "userNom"=>$data[$this::COLUMN_USER_NOM], 
                "userPrenoms"=>$data[$this::COLUMN_USER_PRENOM_JSON], 
                "userBornDate"=>$data[$this::COLUMN_USER_BORN_DATE], 
                "userBornLocation"=>$data[$this::COLUMN_USER_BORN_LOCATION], 
                "userSex"=>$data[$this::COLUMN_USER_SEXE], 
                "userPhoneNumber"=>$data[$this::COLUMN_USER_PHONE_NUMBER], 
                "userMail"=>$data[$this::COLUMN_USER_MAIL], 
                "userProfession"=>$data[$this::COLUMN_USER_PROFESSION], 
                "userGeolocal"=>$data[$this::COLUMN_USER_GEOLOCAL], 
                "userTown"=>$data[$this::COLUMN_USER_TOWN], 
                "userQuartier"=>$data[$this::COLUMN_USER_QUARTIER], 
                "userLastVisiteTime"=>$data[$this::COLUMN_USER_LAST_VISITE_TIME], 
                "userLastLoadTime"=>$this->dateManager->getDateReference($data[$this::COLUMN_USER_LAST_LOAD_TIME]), 
                "userRang"=>$data[$this::COLUMN_USER_RANG], 
                "userInscriptConfPass"=>$data[$this::COLUMN_USER_INSCRIPT_CONF_PASS], 
                "userConfInscript"=>$data[$this::COLUMN_USER_CONF_INSCRIPT], 
                "userActifStatus"=>$data[$this::COLUMN_ACTIF_STATUS], 
                "userActivity"=>$data[$this::COLUMN_ACTIVITY], 
                "userInscriptTime"=>$data[$this::COLUMN_INSCRIPT_TIME], 
                "userProfilPicture"=>$this->profilPictureDataSource->getUserCurrentPicture($data[$this::COLUMN_ID])->getPictureName()
            );
        }
        
        return json_encode($out);
    }
    
    private function queryToArray(\PDOStatement $query):array{
        $out = Array();
        
        $i = 0;
        while($data = $query->fetch()){
            $out[$i++] = Array(
                "userId"=>$data[$this::COLUMN_ID], 
                "userType"=>$data[$this::COLUMN_USER_TYPE], 
                "userNom"=>$data[$this::COLUMN_USER_NOM], 
                "userPrenoms"=>$data[$this::COLUMN_USER_PRENOM_JSON], 
                "userBornDate"=>$data[$this::COLUMN_USER_BORN_DATE], 
                "userBornLocation"=>$data[$this::COLUMN_USER_BORN_LOCATION], 
                "userSex"=>$data[$this::COLUMN_USER_SEXE], 
                "userPhoneNumber"=>$data[$this::COLUMN_USER_PHONE_NUMBER], 
                "userMail"=>$data[$this::COLUMN_USER_MAIL], 
                "userProfession"=>$data[$this::COLUMN_USER_PROFESSION], 
                "userGeolocal"=>$data[$this::COLUMN_USER_GEOLOCAL], 
                "userTown"=>$data[$this::COLUMN_USER_TOWN],
                "userQuartier"=>$data[$this::COLUMN_USER_QUARTIER], 
                "userLastVisiteTime"=>$data[$this::COLUMN_USER_LAST_VISITE_TIME], 
                "userLastLoadTime"=>$this->dateManager->getDateReference($data[$this::COLUMN_USER_LAST_LOAD_TIME]), 
                "userRang"=>$data[$this::COLUMN_USER_RANG], 
                "userInscriptConfPass"=>$data[$this::COLUMN_USER_INSCRIPT_CONF_PASS], 
                "userConfInscript"=>$data[$this::COLUMN_USER_CONF_INSCRIPT], 
                "userActifStatus"=>$data[$this::COLUMN_ACTIF_STATUS], 
                "userActivity"=>$data[$this::COLUMN_ACTIVITY], 
                "userInscriptTime"=>$data[$this::COLUMN_INSCRIPT_TIME], 
                "userProfilPicture"=>$this->profilPictureDataSource->getUserCurrentPicture($data[$this::COLUMN_ID])->getPictureName()
            );
        }
        
        return $out;
    }
}
