<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/PageBundle/Model/Frontend/PageDataSource.php';

/**
 * Description of UserVavoriteArtisan
 *
 * @author djoluc
 */
class UserFavoriteArtisan {
    private $userId, 
            $artisanUserId, 
            $time;
    
    
    public function __construct($userId, $artisanUserId, $time) {
        $this->userId = $userId;
        $this->artisanUserId = $artisanUserId;
        $this->time = $time;
    }
    
    
    public function getUserId() {
        return $this->userId;
    }

    public function getArtisanUserId() {
        return $this->artisanUserId;
    }

    public function getTime() {
        return $this->time;
    }

    public function setUserId($userId) {
        $this->userId = $userId;
    }

    public function setArtisanUserId($artisanUserId) {
        $this->artisanUserId = $artisanUserId;
    }

    public function setTime($time) {
        $this->time = $time;
    }
    
    public function getUser():User{
        $userDataSource = new UserDataSource();
        
        return $userDataSource->getUser($this->userId);
    }
    
    public function getArtisanUser():User{
        $userDataSource = new UserDataSource();
        
        return $userDataSource->getUser($this->artisanUserId);
    }
    
    
    public function getArtisanUserPage():\DJOLUC\PageBundle\Model\Frontend\Page{
        $pageDataSource = new \DJOLUC\PageBundle\Model\Frontend\PageDataSource();
        
        return $pageDataSource->getUserPage($this->artisanUserId);
    }

    
    public static function getEmpty():UserFavoriteArtisan{
        return new UserFavoriteArtisan(0, 0, 0);
    }

}
