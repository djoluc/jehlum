<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;
require_once 'DJOLUC/Helper/php/DbSwitcher.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'UserFavoriteArtisan.php';

use DJOLUC\Helper;
use Exception;
/**
 * Description of UserFavoriteArtisanDataSource
 *
 * @author djoluc
 */
class UserFavoriteArtisanDataSource {
    const TABLE_NAME = "user_favorite_artisan_table";
    const COLUMN_USER_ID = "user_id";
    const COLUMN_ARTISAN_USER_ID = "artisan_user_id";
    const COLUMN_TIME = "time";
    
    
    public $AllColumn;
    
    private $DbPdo,
            $DbPdoOk,
            $PropertyOk;
    
    
    
    public function __construct() {
        $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $this->AllColumn = "".$this::COLUMN_USER_ID.", ".$this::COLUMN_ARTISAN_USER_ID.", ".$this::COLUMN_TIME."";
        
        $dbswitch = new Helper\php\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTable();
            $this->DbPdoOk = TRUE;
        }  
    }
    
    
    public function createTable(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                        CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME."
                            (
                                ".$this::COLUMN_USER_ID." bigint unsigned NOT NULL,
                                ".$this::COLUMN_ARTISAN_USER_ID." bigint unsigned NOT NULL,
                                ".$this::COLUMN_TIME." bigint,
                                FOREIGN KEY (".$this::COLUMN_USER_ID.") REFERENCES ". \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME." (". \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID.") ON DELETE CASCADE ON UPDATE CASCADE, 
                                FOREIGN KEY (".$this::COLUMN_ARTISAN_USER_ID.") REFERENCES ". \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME." (". \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID.") ON DELETE CASCADE ON UPDATE CASCADE 
                            );
                            
                    ");
            if(!$query->execute()){
                throw new \Exception($query->errorInfo()[2]);
            }
            $query->closeCursor();
        } catch (Exception $e) {
             echo"Impossible de créer la table ".$this::TABLE_NAME." ".$e->getMessage()."";
             die();
        }
    }
    
    
    
    public function addFavorite($userId, $artisanUserId, $time):bool{
        
        if($this->isUserFavoriteArtisan($userId, $artisanUserId)){
            return FALSE;
        }
        
        if($userId == 0 || $artisanUserId == 0){
            return FALSE;
        }
        
        
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES(?, ?, ?);
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $artisanUserId, \PDO::PARAM_INT);
        $query->bindValue(3, $time, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    
    public static function addUserFavoriteArtisanStatically($userId, $artisanUserId, $time):bool{
        $thisClass = new UserFavoriteArtisanDataSource();
        
        return $thisClass->addFavorite($userId, $artisanUserId, $time);
    }




    public function getUserFavoriteArtisans($userId, $first, $numb):array{
        $out = Array();
        
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ?  
                        ORDER BY ".$this::COLUMN_TIME." DESC  LIMIT ? OFFSET ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $numb, \PDO::PARAM_INT);
        $query->bindValue(3, $first, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUserFavoriteArtisans($query);
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getUserFavoriteArtisansNumb($userId):int{
        $out = 0;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_ARTISAN_USER_ID.") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"];
            }
        }
        else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function isUserFavoriteArtisan($userId, $artisanUserId):bool{
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_USER_ID.") AS numb FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_ARTISAN_USER_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $artisanUserId, \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"]>0?TRUE:FALSE;
            }
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function deleteUserFavoriteArtisan($userId, $artisanUserId){
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_ARTISAN_USER_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $artisanUserId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    
    private function queryToUserFavoriteArtisan(\PDOStatement $query):PageVisitor{
        $out = PageVisitor::getEMpty();
        
        if($data = $query->fetch()){
            $out = new UserFavoriteArtisan($data[$this::COLUMN_USER_ID], $data[$this::COLUMN_ARTISAN_USER_ID], $data[$this::COLUMN_TIME]);
        }
        
        return $out;
    }
    
    
    
    private function queryToUserFavoriteArtisans(\PDOStatement $query):array{
        $out = Array();
        
        $i = 0;
        while($data = $query->fetch()){
            $out[$i++] = new UserFavoriteArtisan($data[$this::COLUMN_USER_ID], $data[$this::COLUMN_ARTISAN_USER_ID], $data[$this::COLUMN_TIME]);
        }
        
        return $out;
    }
    
}
