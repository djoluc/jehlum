<?php
namespace DJOLUC\RegisterBundle\Model\Frontend;

require_once 'DJOLUC/Helper/php/DbSwitcher.php';
require_once 'UserDataSource.php';
require_once 'ArtisanUser.php';
require_once 'ProfilPicture.php';

use DJOLUC\Helper;
use Exception;

/**
 * Description of ProfilPictureDataSource
 *
 * @author djoluc
 */
class ProfilPictureDataSource {
    const TABLE_NAME = "profile_picture_table";
    const COLUMN_ID = "picture_id";
    const COLUMN_USER_ID = "user_id";
    const COLUMN_PICTURE_NAME = "picture_name";
    const COLUMN_TIME = "picture_time";
    const COLUMN_IS_CURRENT = "is_current";
    
    const IMAGE_DIR = "avatar";
    
    public $AllColumn;
    
    private $DbPdo,
            $DbPdoOk,
            $PropertyOk;
    
    public function __construct() {
        $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $dbswitch = new Helper\php\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTableProfilePicture();
            $this->DbPdoOk = TRUE;
        }
        
        $this->AllColumn = "".$this::COLUMN_USER_ID.", ".$this::COLUMN_PICTURE_NAME.", ".$this::COLUMN_TIME.", ".$this::COLUMN_IS_CURRENT."";
        
        //profilePicture folder
        if(!is_dir("avatar")) mkdir("avatar");
    }
    
    
    public function createTableProfilePicture(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                        CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME."
                            (
                                ".$this::COLUMN_ID." bigint unsigned not null auto_increment,
                                ".$this::COLUMN_USER_ID." bigint unsigned NOT NULL, 
                                ".$this::COLUMN_PICTURE_NAME." varchar(200), 
                                ".$this::COLUMN_TIME." bigint, 
                                ".$this::COLUMN_IS_CURRENT." boolean NOT NULL DEFAULT false,
                                PRIMARY KEY (".$this::COLUMN_ID."),
                                FOREIGN KEY (".$this::COLUMN_USER_ID.") REFERENCES ".UserDataSource::TABLE_NAME." (".UserDataSource::COLUMN_ID.") ON DELETE CASCADE ON UPDATE CASCADE
                            );
                            
                    ");
            if(!$query->execute()){
                throw new \Exception($query->errorInfo()[2]);
            }
            $query->closeCursor();
        } catch (Exception $e) {
             echo"Impossible de créer la table ".$this::TABLE_NAME." ".$e->getMessage()."";
             die();
        }
    }
    
    
    public function addUserProfilPicture($userId, $pictureName):bool{
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES(?, ?, ?, ?);
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $pictureName, \PDO::PARAM_STR);
        $query->bindValue(3, time(), \PDO::PARAM_INT);
        $query->bindValue(4, TRUE, \PDO::PARAM_BOOL);
        $out = $query->execute();
        if(!$out){
            throw new \Exception($query->errorInfo()[2]);
        }
        $this->setAsCurrent($this->DbPdo->lastInsertId(), $userId);
        $query->closeCursor();
        
        return $out;
    }
    
    public function removePicture($pictureId, $userId):bool{
        $out = false;
        $fileName = $this->getPicture($pictureId)->getPictureName();
        if(\unlink($this::IMAGE_DIR."/".$userId."/".$fileName) && \unlink($this::IMAGE_DIR."/".$userId."/mini/".$fileName)){
            $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_ID." = ? 
                ");
            $query->bindValue(1, $pictureId, \PDO::PARAM_INT);
            $out = $query->execute();
            if(!$out){
                throw new Exception($query->errorInfo()[2]);
            }
            $query->closeCursor();
        }
        
        $userPictures = $this->getUserProfilPictures($userId);
        if(count($userPictures)){
            $this->setAsCurrent($userPictures[0]->getPictureId(), $userId);
        }
        
        return $out;
    }
    
    
    public function setAsCurrent($pictureId, $userId){
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_IS_CURRENT." = ? WHERE ".$this::COLUMN_ID." = ?;
               ");
        $query->bindValue(1, TRUE, \PDO::PARAM_BOOL);
        $query->bindValue(2, $pictureId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_IS_CURRENT." = ? WHERE ".$this::COLUMN_ID." != ? AND ".$this::COLUMN_USER_ID." = ?;
               ");
        $query->bindValue(1, FALSE, \PDO::PARAM_BOOL);
        $query->bindValue(2, $pictureId, \PDO::PARAM_INT);
        $query->bindValue(3, $userId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
    }
    
    public function getPicture($pictureId):ProfilPicture{
        $out = ProfilPicture::getEMpty();
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_ID." = ?;
                ");
        $query->bindValue(1, $pictureId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToProfilPicture($query);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getUserProfilPictures($userId):array{
        $out = Array();
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToProfilPictures($query);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getUserCurrentPicture($userId):ProfilPicture{
        $out = ProfilPicture::getEMpty();
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this::COLUMN_ID.", ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_IS_CURRENT." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, TRUE, \PDO::PARAM_BOOL);
        if($query->execute()){
            $out = $this->queryToProfilPicture($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    public function queryToProfilPicture(\PDOStatement $query):ProfilPicture{
        $out = ProfilPicture::getEMpty();
        
        if($data = $query->fetch()){
            $out = new ProfilPicture($data[$this::COLUMN_ID], $data[$this::COLUMN_USER_ID], $data[$this::COLUMN_PICTURE_NAME], 
                    $data[$this::COLUMN_TIME], $data[$this::COLUMN_IS_CURRENT]);
            //print $data[$this::COLUMN_PICTURE_NAME_ID];
        }
        
        return $out;
    }
    
    
    public function queryToProfilPictures(\PDOStatement $query):array{
        $out = Array();
        
        $i = 0;
        while($data = $query->fetch()){
            $out[$i++] = new ProfilPicture($data[$this::COLUMN_ID], $data[$this::COLUMN_USER_ID], $data[$this::COLUMN_PICTURE_NAME], 
                    $data[$this::COLUMN_TIME], $data[$this::COLUMN_IS_CURRENT]);
        }
        
        
        return $out;
    }
    
}
