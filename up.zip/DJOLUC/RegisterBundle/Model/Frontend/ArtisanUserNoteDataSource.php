<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;

require_once 'DJOLUC/Helper/php/DbSwitcher.php';
require_once 'UserDataSource.php';
require_once 'ArtisanUserNote.php';

use DJOLUC\Helper;
use Exception;

/**
 * Description of ArtisanUserNoteDataSource
 *
 * @author djoluc
 */
class ArtisanUserNoteDataSource {
    const TABLE_NAME = "artisan_user_note";
    const COLUMN_USER_ID = "user_id";
    const COLUMN_ARTISAN_USER_ID = "artisan_user_id";
    const COLUMN_NOTE = "user_note";
    const COLUMN_TIME = "time";
    
    public $AllColumn;
    
    private $DbPdo,
            $DbPdoOk,
            $PropertyOk;
    
    public function __construct() {
        $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $this->AllColumn = "".$this::COLUMN_USER_ID.", ".$this::COLUMN_ARTISAN_USER_ID.", ".$this::COLUMN_NOTE.", ".$this::COLUMN_TIME."";
        
        $dbswitch = new Helper\php\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTable();
            $this->DbPdoOk = TRUE;
        }
    }
    
    
    public function createTable(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                        CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME."
                            (
                                ".$this::COLUMN_USER_ID." bigint unsigned NOT NULL,
                                ".$this::COLUMN_ARTISAN_USER_ID." bigint unsigned NOT NULL,
                                ".$this::COLUMN_NOTE." int, 
                                ".$this::COLUMN_TIME." bigint,
                                FOREIGN KEY (".$this::COLUMN_USER_ID.") REFERENCES ".UserDataSource::TABLE_NAME." (".UserDataSource::COLUMN_ID.") ON DELETE CASCADE ON UPDATE CASCADE,
                                FOREIGN KEY (".$this::COLUMN_ARTISAN_USER_ID.") REFERENCES ".UserDataSource::TABLE_NAME." (".UserDataSource::COLUMN_ID.") ON DELETE CASCADE ON UPDATE CASCADE
                             );
                    ");
            if(!$query->execute()){
                throw new Exception($query->errorInfo()[2]);
            }
        } catch (Exception $ex) {
            echo"Impossible de créer la table ".$this::TABLE_NAME." ".$e->getMessage()."";
            die();
        }
    }
    
    
    
    public function addUserNote($userId, $artisanUserId, $note, $time):bool{
        
        if($this->isUserNoteToArtisanExist($userId, $artisanUserId)){
            return $this->updateUserNoteToArtisan($userId, $artisanUserId, $note);
        }
        
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES(?, ?, ?, ?);
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $artisanUserId, \PDO::PARAM_INT);
        $query->bindValue(3, $note, \PDO::PARAM_INT);
        $query->bindValue(4, $time, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function getUserNoteToArtisan($userId, $artisanUserId):ArtisanUserNote{
        $out = 0;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_ARTISAN_USER_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $artisanUserId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToArtisanUserNote($query);
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    
    public function updateUserNoteToArtisan($userId, $artisanUserId, $newNote):bool{
        $query = $this->DbPdo->prepare
                ("
                    UPDATE ".$this::TABLE_NAME." SET ".$this::COLUMN_NOTE." = ?  WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_ARTISAN_USER_ID." = ?; 
                ");
        $query->bindValue(1, $newNote, \PDO::PARAM_INT);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        $query->bindValue(3, $artisanUserId, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function isUserNoteToArtisanExist($userId, $artisanUserId):bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_USER_ID.") AS numb FROM ".$this::TABLE_NAME."  WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_ARTISAN_USER_ID." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $artisanUserId, \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"]>0;
            }
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    
    public function getArtisanUserGeneralNote($artisanUserId):float{
        $out = 0;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ((SUM(".$this::COLUMN_NOTE."))/COUNT(".$this::COLUMN_USER_ID.")) AS note FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_ARTISAN_USER_ID." = ?;
                ");
        $query->bindValue(1, $artisanUserId, \PDO::PARAM_INT);
        if($query->execute()){
            if($data = $query->fetch()){
                $out = empty($data["note"])?0:$data["note"];
            }
        }else{
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    private function queryToArtisanUserNote(\PDOStatement $query): ArtisanUserNote{
        $out = ArtisanUserNote::getEmpty();
        
        if($data = $query->fetch()){
            $out = new ArtisanUserNote($data[$this::COLUMN_USER_ID], $data[$this::COLUMN_ARTISAN_USER_ID], $data[$this::COLUMN_NOTE], $data[$this::COLUMN_TIME]);
        }
        
        return $out;
    }
    
    
    private function queryToArtisanUserNotes(\PDOStatement $query): array{
        $out = Array();
        
        $i = 0;
        if($data = $query->fetch()){
            $out[$i++] = new ArtisanUserNote($data[$this::COLUMN_USER_ID], $data[$this::COLUMN_ARTISAN_USER_ID], $data[$this::COLUMN_NOTE], $data[$this::COLUMN_TIME]);
        }
        
        return $out;
    }
}
