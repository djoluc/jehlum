<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;

/**
 * Description of ProfilPicture
 *
 * @author djoluc
 */
class ProfilPicture {
    private $pictureId, 
            $userId, 
            $pictureName, 
            $pictureTime, 
            $isCurrent;
    
    public function __construct($pictureId, $userId, $pictureName, $pictureTime, bool$isCurrent) {
        $this->pictureId = $pictureId;
        $this->userId = $userId;
        $this->pictureName = $pictureName;
        $this->pictureTime = $pictureTime;
        $this->isCurrent = $isCurrent;
    }
    
    public function getPictureId() {
        return $this->pictureId;
    }

    public function getUserId() {
        return $this->userId;
    }

    public function getPictureName() {
        return $this->pictureName;
    }
    
    public function getProfilePictureLink(){
        if(!empty($this->pictureName))
            return SITE_ROOT."avatar/".$this->userId."/".$this->pictureName."";
        
        return $this->pictureName;
    }
    
    public function getProfilePictureMiniLink(){
        if(!empty($this->pictureName))
            return SITE_ROOT."avatar/".$this->userId."/mini/".$this->pictureName."";
        
        return $this->pictureName;
    }

    public function getPictureTime() {
        return $this->pictureTime;
    }

    public function getIsCurrent() {
        return $this->isCurrent;
    }

    public function setPictureId($pictureId) {
        $this->pictureId = $pictureId;
    }

    public function setUserId($userId) {
        $this->userId = $userId;
    }

    public function setPictureName($pictureName) {
        $this->pictureName = $pictureName;
    }
    

    public function setPictureTime($pictureTime) {
        $this->pictureTime = $pictureTime;
    }

    public function setIsCurrent($isCurrent) {
        $this->isCurrent = $isCurrent;
    }    
    
    public static function getEMpty(){
        return new ProfilPicture(0, 0, "", 0, FALSE);
    }

}
