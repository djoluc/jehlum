<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DJOLUC\RegisterBundle\Model\Frontend;

/**
 * Description of ArtisanUser
 *
 * @author djoluc
 */
class ArtisanUser {
    private $artisanId,
            $artisanCompanyName, 
            $artisanJusidicStatus, 
            $artisanAssociationName, 
            $artisanFederationAppartenance, 
            $artisanFormator, 
            $artisanMatricule, 
            $coresUserId;
    
    
    public function __construct($artisanId, $artisanCompanyName, $artisanJusidicStatus, $artisanAssociationName, $artisanFederationAppartenance, 
            $artisanFormator, $artisanMatricule, $coresUserId) {
        $this->artisanId = $artisanId;
        $this->artisanCompanyName = $artisanCompanyName;
        $this->artisanJusidicStatus = $artisanJusidicStatus;
        $this->artisanAssociationName = $artisanAssociationName;
        $this->artisanFederationAppartenance = $artisanFederationAppartenance;
        $this->artisanFormator = $artisanFormator;
        $this->artisanMatricule = $artisanMatricule;
        $this->coresUserId = $coresUserId;
    }
    
    public function getArtisanId() {
        return $this->artisanId;
    }

    public function getArtisanCompanyName() {
        return $this->artisanCompanyName;
    }

    public function getArtisanJusidicStatus() {
        return $this->artisanJusidicStatus;
    }

    public function getArtisanAssociationName() {
        return $this->artisanAssociationName;
    }

    public function getArtisanFederationAppartenance() {
        return $this->artisanFederationAppartenance;
    }

    public function getArtisanFormator() {
        return $this->artisanFormator;
    }

    public function getArtisanMatricule() {
        return $this->artisanMatricule;
    }

    public function getCoresUserId() {
        return $this->coresUserId;
    }

    public function setArtisanId($artisanId) {
        $this->artisanId = $artisanId;
    }

    public function setArtisanCompanyName($artisanCompanyName) {
        $this->artisanCompanyName = $artisanCompanyName;
    }

    public function setArtisanJusidicStatus($artisanJusidicStatus) {
        $this->artisanJusidicStatus = $artisanJusidicStatus;
    }

    public function setArtisanAssociationName($artisanAssociationName) {
        $this->artisanAssociationName = $artisanAssociationName;
    }

    public function setArtisanFederationAppartenance($artisanFederationAppartenance) {
        $this->artisanFederationAppartenance = $artisanFederationAppartenance;
    }

    public function setArtisanFormator($artisanFormator) {
        $this->artisanFormator = $artisanFormator;
    }

    public function setArtisanMatricule($artisanMatricule) {
        $this->artisanMatricule = $artisanMatricule;
    }

    public function setCoresUserId($coresUserId) {
        $this->coresUserId = $coresUserId;
    }
    
    public function getArtisanJuridicStatusString(){
        
        $out = "Informel";
        
        switch ($this->artisanJusidicStatus){
            case "2":
                $out = "PME";
                break;;
            case "3":
                
                $out = "ETS";
                
                break;
            
            case "4":
                
                $out = "SARL";
                
                break;
        }
        
        return $out;
    }
    
    public static function getEmptyArtisanUser():ArtisanUser{
        return new ArtisanUser(0, "", 0, "", "", "", "", 0);
    }
}
