<?php

namespace DJOLUC\RegisterBundle\Model\Frontend;



/**
 * Description of ArtisanUserNote
 *
 * @author djoluc
 */
class ArtisanUserNote {
    private $userId, 
            $artisanUserNote, 
            $note, 
            $time;
    
    
    
    
    public function __construct($userId, $artisanUserNote, $note, $time) {
        $this->userId = $userId;
        $this->artisanUserNote = $artisanUserNote;
        $this->note = $note;
        $this->time = $time;
    }
    
    
    
    public function getUserId() {
        return $this->userId;
    }

    public function getArtisanUserNote() {
        return $this->artisanUserNote;
    }

    public function getNote() {
        return $this->note;
    }

    public function getTime() {
        return $this->time;
    }

    public function setUserId($userId) {
        $this->userId = $userId;
    }

    public function setArtisanUserNote($artisanUserNote) {
        $this->artisanUserNote = $artisanUserNote;
    }

    public function setNote($note) {
        $this->note = $note;
    }

    public function setTime($time) {
        $this->time = $time;
    }
    
    
    public static function getEmpty():ArtisanUserNote{
        return new ArtisanUserNote(0, 0, 0, 0);
    }

}
