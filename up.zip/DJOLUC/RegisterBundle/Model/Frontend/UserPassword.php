<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace DJOLUC\RegisterBundle\Model\Frontend;

 /* Description of UserPassword
 *
 * @author djoluc
 */
class UserPassword {
    private $userPassword, 
            $passwordTime, 
            $userId, 
            $isCurrentPassword;
    
    
    public function __construct($userPassword, $passwordTime, $userId, $isCurrentPassword) {
        $this->userPassword = $userPassword;
        $this->passwordTime = $passwordTime;
        $this->userId = $userId;
        $this->isCurrentPassword = $isCurrentPassword;
    }
    
    public function getUserPassword() {
        return $this->userPassword;
    }

    public function getPasswordTime() {
        return $this->passwordTime;
    }

    public function getUserId() {
        return $this->userId;
    }

    public function setUserPassword($userPassword) {
        $this->userPassword = $userPassword;
    }

    public function setPasswordTime($passwordTime) {
        $this->passwordTime = $passwordTime;
    }

    public function setUserId($userId) {
        $this->userId = $userId;
    }
    
    function getIsCurrentPassword() {
        return $this->isCurrentPassword;
    }

    function setIsCurrentPassword($isCurrentPassword) {
        $this->isCurrentPassword = $isCurrentPassword;
    }

        
    public static function getEmptyUserPassword(){
        return new UserPassword("", 0, 0, FALSE);
    }
}
