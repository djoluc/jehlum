var loginObject = null;

$(document).ready(function(){
    loginObject = new Login(".account_confirm_form");
});

function Login(formElement){
    this.formElement = formElement;
    
    let thisElement = this;
    $(this.formElement).submit(function(e){
        e.preventDefault();
        
        thisElement.requestLogin();
    });
}

Login.prototype.checkMail = function(mail){
    let re = /^(?:[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
    
    //return re.test(mail);
    return true;
};

Login.prototype.checkPasswordLenght = function(password){
    return (password.length >= 8);
};

Login.prototype.requestLogin = function(){
    this.loading();
    let email = $("input[name='mail']").val();
    let password = $("input[name='pass']").val();
    let rememb = $("input[name='remember']").prop("checked");
    
    $("form > label > p > a").text("");
    $("form > label > p").css("display", "none");
    
    if(!this.checkMail(email)){
        $(".email_info").css("display", "block");
        $(".email_info > a").text("Adresse email invalide.");
        loginObject.stopLoading();
        return;
    }
    
    if(!this.checkPasswordLenght(password)){
        $(".pass_info").css("display", "block");
        $(".pass_info > a").text("Mot de passe trop court");
        loginObject.stopLoading();
        return;
    }
    
    $.post("./authenticate/login/ajax", 
        {mail: email, pass: password, remember: rememb, sent: ""}, 
        function(result){
            loginObject.stopLoading();
            //alert(result);
            var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
                        
            if(rep.result){
                window.location = "./";
            }else{
                if(!rep.emailExist){
                    $(".email_info").css("display", "block");
                    $(".email_info > a").text(rep.emailMessage);
                }else{
                    if(!rep.passwordMatch){
                        $(".pass_info").css("display", "block");
                        $(".pass_info > a").text(rep.passwordMessage);
                    }
                }
                
            }
        });
};

Login.prototype.loading = function(){
    $("form > button[type='submit'] > i").css("display", "inline-block");
    $("form > button[type='submit']").attr("disabled", "disabled");
};

Login.prototype.stopLoading = function(){
    $("form > button[type='submit'] > i").css("display", "none");
    $("form > button[type='submit']").removeAttr("disabled");
};