var codeConfirmObject = null;

$(document).ready(function(){
    codeConfirmObject  = new CodeConfirm($(".account_confirm_form"));
});


function CodeConfirm(formElement){
    this.formElement = formElement;
    
    let thisElement = this;
    
    $(this.formElement).submit(function(e){
        e.preventDefault();
        thisElement.confirmAccount();
    });
    
    $(".resend_button").click(function(){
        thisElement.resendCode();
    });
}


CodeConfirm.prototype.confirmAccount = function(){
    this.loading();
    $(".message").css("display", "none");
    let cCode = $("input[type='number']").val();
    
     $.post("./accountConfirm/confirmCode/ajax", 
        {code: cCode, sent: ""}, 
        function(result){
            codeConfirmObject.stopLoading();
            //alert(result);
            var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
                        
            if(rep.result){
                window.location = "./register/complete";
            }else{
                //alert("error");
                codeConfirmObject.displayError(rep.message);
                
            }
        });
};

CodeConfirm.prototype.resendCode = function(){
    this.animResend();
    $.post("./accountConfirm/resend/ajax", 
        { sent: ""}, 
        function(result){
            codeConfirmObject.stopAnimResend();
            //alert(result);
            var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
                        
            codeConfirmObject.setResendMessage(rep.message);
        });
};

CodeConfirm.prototype.loading = function(){
    $("form > label > button > i.fa").css("display", "inline-block");
};


CodeConfirm.prototype.stopLoading = function(){
    $("form > label > button > i.fa").css("display", "none");
};

CodeConfirm.prototype.displayError = function(error){
    $(".message").css("display", "block");
    $(".message > a").text(error);
};

CodeConfirm.prototype.animResend = function(){
    $(".resend_button > i").css("display", "inline-block");
};

CodeConfirm.prototype.stopAnimResend = function(){
    $(".resend_button > i").css("display", "none");
};

CodeConfirm.prototype.setResendMessage = function(message){
    $(".resend_message").css("display", "block");
    $(".resend_message > a").text(message);
    var tmpTimeout = window.setTimeout(function(){
        $(".resend_message > a").text("");
        $(".resend_message").css("display", "none");
        window.clearTimeout(tmpTimeout);
    }, 5000);
};