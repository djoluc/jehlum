$(document).ready(function(){
    /*var searchBar = new SearchBar(function(text){
        //alert(text);
    }, 
    function(){
        //alert("Tout va bien");
    });*/
    
    //searchBar.fillAutoComplete(["luc", "lucas", "lolo"]);
});

function SearchBar(searchingCallback, submitedCallback, preventSubmitDefault = true){
    this.formElement = $("#searchForm");
    this.searchingCallback = searchingCallback;
    this.submitedCallback = submitedCallback;
    this.preventSubmitDefault = preventSubmitDefault;
    
    var thisElement = this;
    
    $(this.formElement).submit(function(e){
        if(thisElement.preventSubmitDefault){
            e.preventDefault();
        }
        thisElement.submitedCallback($("#searchForm > input[name='search']").val());
    });
    
    $("#searchForm > input[name='search']").keyup(function(e){
        e.preventDefault();
        thisElement.searchingCallback($(e.target).val());
        
        if($(e.target).val() === ""){
            thisElement.submitForm();
        }
    });
}

SearchBar.prototype.fillAutoComplete = function(listArray){
    this.clearAutoComplete();
    for(let i = 0; i < listArray.length; i++){
        this.appendLi(listArray[i]);
    }
    
    var thisElement = this;
    $("#searchForm > ul > li").click(function(e){
        $("#searchForm > input[name='search']").val($(e.target).text());
        
        thisElement.clearAutoComplete();
        
        thisElement.submitForm();
    });
};

SearchBar.prototype.appendLi = function(proposition){
    $("#searchForm > ul").append("<li>"+proposition+"</li>");
};

SearchBar.prototype.clearAutoComplete = function(){
    $("#searchForm > ul").empty();
};

SearchBar.prototype.submitForm = function(){
    $(this.formElement).submit();
};

