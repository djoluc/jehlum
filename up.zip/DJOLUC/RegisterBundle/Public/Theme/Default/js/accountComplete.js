var geolocalManager = null;
var accountCompleter = null;
var map = null;

$(document).ready(function(){
    geolocalManager = new GeolocalManager();
    accountCompleter = new AccountCompleter($(".complete_form"));
    //détermination du pays de l'utilisateur
    
    $(".choose_avatar").click(function(e){
        e.preventDefault();
        $("input[type='file'][name='avatar']").click();
    });
    
    $("input[name='avatar']").change(function(e){
        accountCompleter.loadProfilPicture();
    });
    
    $(".send_avatar").click(function(e){
        e.preventDefault();
        accountCompleter.uploadProfilePicture();
    });
    
    geolocalManager.locateIp(function(countryCode, country, city, lat, lon, region, regionName, query){
        $("select[name='country']").val(countryCode);
        $("input[name='town']").val(city);
        //accountCompleter.showUserPosOnMap(lat, lon);
    });
    
    geolocalManager.locate(function(lat, lon){
        accountCompleter.showUserPosOnMap(lat, lon);
    });
    //profile image change with resize
    //$("#image_crop").Jcrop();
});


function AccountCompleter(formElement){
    this.formElement = formElement;
    
    thisElement = this;
    $(this.formElement).submit(function(e){
        e.preventDefault();
        
        thisElement.complete();
    });
}

AccountCompleter.prototype.complete = function(){
    this.loading();
   // alert("ok");
    let userNom = $("input[name='nom']").val();
    //alert("ok");
    let userPrenoms = $("input[name='prenom']").val();
    let userDayNaiss = $("select[name='naiss_day']").val();
    let userMonthNaiss = $("select[name='naiss_month']").val();
    let userYearNaiss = $("select[name='naiss_year']").val();
    let userLieuNaiss = $("input[name='lieu_naiss']").val();
    //alert(userDateNaiss);
    let userGenre  = $("select[name='gender']").val();
    let userPhone = $("input[name='phone']").val();
    let userProfession = $("input[name='profession']").val();
    let userCountry = $("select[name='country']").val();
    let userTown = $("input[name='town']").val();
    
    let userCompany = "";
    let userJuridique = "";
    let userAssociation = "";
    let userFederation = "";
    let userFormator = "";
    
    if($("input[name='company']").length){
        userCompany = $("input[name='company']").val();
        userJuridique = $("select[name='juridique']").val();
        userAssociation = $("input[name='association']").val();
        userFederation = $("input[name='federation']").val();
        userFormator = $("input[name='formator']").val();
    }
    
    
    $.post("../register/completeRequest/ajax", 
        {nom: userNom, prenom: userPrenoms, dayNaiss: userDayNaiss, mouthNaiss: userMonthNaiss, yearNaiss: userYearNaiss,
            naissLieu: userLieuNaiss, genre: userGenre, phone: userPhone,  
            profession: userProfession, country: userCountry, town: userTown, company: userCompany, 
            juridic: userJuridique, association: userAssociation, 
            federation: userFederation, formator: userFormator, sent: ""}, 
        function(result){
            accountCompleter.stopLoading();
            //alert(result);
            var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
                        
            if(rep.result){
               accountCompleter.displayMessage(rep.message);
               window.location = "../profil"
            }else{
                
                accountCompleter.displayMessage(rep.message);
            }
        });
    
    
  
};

AccountCompleter.prototype.showUserPosOnMap = function(latitude, longitude){
    
    //var mymap = L.map('mapField').setView([51.505, -0.09], 13);
    
    var map = L.map('mapField', {
    center: [latitude, longitude],
    zoom: 13
    });
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    
    //sattelite
    /*mapLink = 
            '<a href="http://www.esri.com/">Esri</a>';
        wholink = 
            'i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community';
        L.tileLayer(
            'http://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '&copy; '+mapLink+', '+wholink,
            maxZoom: 18,
            }).addTo(map);*/
            
            
      //mapbox
      /*L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoiZGpvbHVjIiwiYSI6ImNqbWN4M3Z5NDNlNmgzcm8yNzNkOWkya2QifQ.C5IdVepGUHKudQajnDpQvg', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox.streets',
    accessToken: 'your.mapbox.access.token'
}).addTo(map);*/
            
            

    L.marker([latitude, longitude]).addTo(map)
        .bindPopup('Approximation Votre position')
        .openPopup();


    
   /* map = new OpenLayers.Map("mapField");
    var mapnik = new OpenLayers.Layer.OSM();
    map.addLayer(mapnik);

    var lonlat = new OpenLayers.LonLat(longitude, latitude).transform(
        new OpenLayers.Projection("EPSG:4326"), // transform from WGS 1984
        new OpenLayers.Projection("EPSG:900913") // to Spherical Mercator
    );

    var zoom = 14;

    var markers = new OpenLayers.Layer.Markers( "Markers" );
    map.addLayer(markers);
    markers.addMarker(new OpenLayers.Marker(lonlat));

    map.setCenter(lonlat, zoom);*/
};

AccountCompleter.prototype.loading = function(){
    $("form > button > i.fa").css("display", "inline-block");
};


AccountCompleter.prototype.stopLoading = function(){
    $("form > button > i.fa").css("display", "none");
};

AccountCompleter.prototype.displayMessage = function(error){
    $(".error_indicator").text(error);
    var tmpTimeout = window.setTimeout(function(){
        $(".error_indicator").text("");
        
        window.clearTimeout(tmpTimeout);
    }, 5000);
};


AccountCompleter.prototype.loadProfilPicture = function(){
    let fileReader = new FileReader();
    
    fileReader.onload = function(e){
        $("#image_crop").html("");
        $("#image_crop").append($("<img src = '"+fileReader.result+"' />"));
        $(".send_avatar").removeAttr("disabled");
    };
    
    fileReader.readAsDataURL($("input[name='avatar']").prop("files")[0]);
};


AccountCompleter.prototype.uploadProfilePicture = function(){
    
    function displayMes(mess){
        $("form > .message").attr("style", "display: block;");
        $("form > .message").text(mess);
        $("#avatar_progress").attr("value", "0");
        var tmp = window.setTimeout(function(){
            $("form > .message").attr("style", "display: none;");
            $("form > .message").text("");
            
            window.clearTimeout(tmp);
        }, 5000);
    }
    
    var formData = new FormData($("#profil_picture_form")[0]);
    
    $.ajax({
    method: 'POST',
    enctype: 'multipart/form-data',
    url: "../register/completeRequest/avatar/ajax",
    data: formData,
    processData: false,
    contentType: false,
    cache: false,
    timeout: 60000,
    success: function(result) {
        //alert(result);
        var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
        $(".send_avatar").attr("disabled", "disabled");
        displayMes(rep.message);
    },
    error: function() {displayMes(rep.message); },
    progress: function(e) {
            //make sure we can compute the length
            //alert("ok");
            if(e.lengthComputable) {
                $("#avatar_progress").attr("max", e.total);
                $("#avatar_progress").attr("value", e.loaded);
            }
            //this usually happens when Content-Length isn't set
        else {
            console.warn('Content Length not reported!');
        }
    }
    });
};
