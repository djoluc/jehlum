var userAdmin = null;

var userFrom = 0;
var userNumber = 20;

$(document).ready(function(){
    userAdmin = new UserAdmin();
});


function UserAdmin(){
    this.cardContener = $(".cards_contener");
    this.allUserNumb = 2;
    this.loadedNumb = 0;
    this.currentSearchText = "";
    
    var thisElement = this;
    this.searchBar = new SearchBar(function(text){
        thisElement.loadProposition(text);
    }, 
    function(text){
        thisElement.currentSearchText = text;
        thisElement.loadedNumb = 0;
        userFrom = 0;
        
        thisElement.loadUsers(userFrom, userNumber, thisElement.currentSearchText);
    });
    
    
    $(".more_button").click(function(){
        userFrom += userNumber;
        thisElement.loadUsers(userFrom, userNumber, thisElement.currentSearchText, true);
    });
    
    
    this.loadUsers(userFrom, userNumber, this.currentSearchText);
    
}

UserAdmin.prototype.loadUsers = function(from, number, searchText, complete = false){
    this.loading();
    let userFilter = $(".userFilter").val();
    $.post("/useradmin/ajaxusers"+((userFilter == "")?"":"/"+userFilter+""), 
        {premier: from, nombre: number, search: searchText, sent: ""}, 
        function(result){
            userAdmin.stopLoading();
            //alert(result);
            var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
             
            userAdmin.allUserNumb = rep.userNumb;
            
            if(!(userFrom === 0 && userAdmin.loadedNumb >= userNumber)){//solution d'urgence pour éviter la répétition de submit après enter
                userAdmin.loadedNumb += rep.loadedNumb;
            }
            
            if(!complete){
                
                userAdmin.putUsersCardToContener(rep.users);
                
            }else{
                
                userAdmin.completeUsersList(rep.users);
                
                
            }
            
            if(searchText === ""){
                userAdmin.searchBar.clearAutoComplete();
            }
            /*if(rep.result){
                window.location = "./";
            }else{
                if(!rep.emailExist){
                    $(".email_info").css("display", "block");
                    $(".email_info > a").text(rep.emailMessage);
                }else{
                    if(!rep.passwordMatch){
                        $(".pass_info").css("display", "block");
                        $(".pass_info > a").text(rep.passwordMessage);
                    }
                }
                
            }*/
        });
};

UserAdmin.prototype.putUsersCardToContener = function(usersArray){
    var thisElement = this;
    $(this.cardContener).html("");
    for(var i = 0; i < usersArray.length; i++){
        this.putUserCardToContener(usersArray[i]);
    }
    
    this.manageMoreButton();
    
    
    $(".theback > form").submit(function(e){
        e.preventDefault();
        
        thisElement.userEditLoading($(e.target).find("button[type='submit']"));
        
        thisElement.submitUserSetting(e.target);
        
    });
};

UserAdmin.prototype.completeUsersList = function(usersArray){
    
    var thisElement = this;
    for(var i = 0; i < usersArray.length; i++){
        this.putUserCardToContener(usersArray[i]);
    }
    
    this.manageMoreButton();
    
    $(".theback > form").off("submit");
    
    $(".theback > form").submit(function(e){
        e.preventDefault();
        
        thisElement.userEditLoading($(e.target).find("button[type='submit']"));
        
        thisElement.submitUserSetting(e.target);
        
    });
    
};

UserAdmin.prototype.putUserCardToContener = function(userObject){
    
    var cardDiv = $("<div class='thecard'></div>");
    
    var artisanNote = userObject.userType === 2?"<p><i class='fa fa-star'></i> <i class='fa fa-star'></i> <i class='fa fa-star'></i> <i class='fa fa-star'></i> <i class='fa fa-star'></i></p>":"";
    
    var profilImg = userObject.userProfilPicture!==""?"<img src='avatar/"+userObject.userId+"/mini/"+userObject.userProfilPicture+"'/>":"";
    
    let cardContent = "<div class='cardcontainer'>"+
                        "<div class='thefront'>"+
                            "<span class='profil_pic'>"+
                                profilImg+
                            "</span>"+
                            "<h1>"+userObject.userNom+" "+userObject.userPrenoms+"</h1>"+
                            "<p><i class='fa fa-map-marker'></i> "+userObject.userGeolocal+"("+userObject.userTown+")"+"</p>"+
                            "<p><i class='fa fal fa-clock'></i> Online "+userObject.userLastLoadTime+"</p>"+
                            artisanNote+
                        "</div>"+
                        "<div class='theback'>"+
                            "<p><i class='fa fa-envelope'></i> "+userObject.userMail+"</p>"+
                            "<p><i class='fa fa-phone'></i> "+userObject.userPhoneNumber+"</p>"+
                            "<h1>Editing</h1>"+
                            "<form>"+
                                "<label>"+
                                    "Role:"+ 
                                    "<select name='userRang'>"+
                                        "<option value='1' "+((userObject.userRang==1)?'selected':'')+">Simple user</option>"+
                                        "<option value='2' "+((userObject.userRang==2)?'selected':'')+">Moderator</option>"+
                                        "<option value='3' "+((userObject.userRang==3)?'selected':'')+">Mini-Adminstrator</option>"+
                                        "<option value='4' "+((userObject.userRang==4)?'selected':'')+">Administrator</option>"+
                                    "</select>"+
                                "</label>"+
                                "<label>"+
                                    "Disable the account:"+ 
                                    "<input type='checkbox' "+(userObject.userActivity?'':'checked')+" name='activity' class='activity' />"+
                                "</label>"+
                                "<input type='hidden' name='userId' value='"+userObject.userId+"' />"+
                                "<button type='submit'>Edit <i class='fa fa-spinner fa-pulse' style='display: none;'></i></button>"+
                            '</form>'+
                            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style='position: absolute; z-index: 100: display: inline-block; color: red; margin-top: 90px; float: left;' href='/useradmin/delete/"+userObject.userId+"'>Delete user</a>"+
                        "</div>"+
                      "</div>";
              
              
    $(cardDiv).append(cardContent);
    $(this.cardContener).append(cardDiv);
    
};

UserAdmin.prototype.loadProposition = function(text){
     let userFilter = $(".userFilter").val();
    $.post("/useradmin/ajaxNameSearchProposition"+((userFilter == "")?"":"/"+userFilter+""),
        {txt: text, sent: ""}, 
        function(result){
            //alert(result);
            var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
            
            userAdmin.searchBar.fillAutoComplete(rep);
            
        });
};

UserAdmin.prototype.loading = function(){
    $(".cards_contener").append("<div class='loading_div'></div>");
};

UserAdmin.prototype.stopLoading = function(){
    $(".loading_div").remove();
};


UserAdmin.prototype.submitUserSetting = function(formElement){
    
    var formData = new FormData(formElement);
    
    formData.append("userActivity", !$(formElement).find("input[name='activity']").prop("checked"));
    
    $.ajax({
    method: 'POST',
    enctype: 'multipart/form-data',
    url: "/useradmin/editUserRequest",
    data: formData,
    processData: false,
    contentType: false,
    cache: false,
    timeout: 600000,
    success: function(result) {
        //alert(result);
        userAdmin.stopUserEditLoading($(formElement).find("button[type='submit']"));
        var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
        //$(".send_avatar").attr("disabled", "disabled");
        //displayMes(rep.message);
    },
    error: function() {
        //displayMes(rep.message); 
    },
    progress: function(e) {
            //make sure we can compute the length
            /*if(e.lengthComputable) {
                $("#avatar_progress").attr("max", e.total);
                $("#avatar_progress").attr("value", e.loaded);
            }
            //this usually happens when Content-Length isn't set
        else {
            console.warn('Content Length not reported!');
        }*/
    }
    });
};

UserAdmin.prototype.userEditLoading = function(button){
    $(button).find("i").attr("class", "fa fa-spinner fa-pulse");
    $(button).find("i").css("display", "inline-block");
};

UserAdmin.prototype.stopUserEditLoading = function(button){
    $(button).find("i").attr("class", "fa fas fa-check");
    var tmp = window.setTimeout(function(){
        $(button).find("i").css("display", "none");
        window.clearTimeout(tmp);
    }, 5000);
};


UserAdmin.prototype.manageMoreButton = function(){
    if(this.loadedNumb >= this.allUserNumb){
        $(".more_button").hide();
    }else{
        $(".more_button").show();
    }
};




