
var MultipleImageField = function(){
    $(".multipleImageField > .preview").attr("style", "display: block;");
    $(".multipleImageField > .select > .no-jsSelect").attr("style", "display: none;");
    $(".multipleImageField > .select > .jsSelect").attr("style", "display: block;");
    $(".multipleImageField > .select > .jsSelect > button").click(function(e){
        e.preventDefault();
        $(".multipleImageField > .select > .no-jsSelect > input[type='file']").click();
    });
    
    $(".multipleImageField > .select > .no-jsSelect > input[type='file']").change(function(){
        if(this.files.length > 10){
            alert("You can add at most 10 pictures");
            return;
        }
        $(".multipleImageField > .preview").html('');
        
        for(var i = 0; i < this.files.length; i++){
            var reader = new FileReader();
            reader.onload = function(){
                $(".multipleImageField > .preview").append($("<img src='"+this.result+"' />"));
            };
            reader.readAsDataURL(this.files.item(i));
        }
    });
}; 