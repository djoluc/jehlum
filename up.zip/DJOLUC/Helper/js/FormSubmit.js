var FormSubmit = function(url, formClass, successCallback, failedCallback){
    this.url = url;
    this.formClass = formClass;
    this.successCallback = successCallback;
    this.failedCallback = failedCallback;
    
    var thisObject = this;
    $("."+this.formClass).submit(function(e){
        e.preventDefault();
        thisObject.submit(e.target);
    });
    
};


FormSubmit.prototype.submit = function(form){
    var thisObject = this;
    var formData = new FormData(form);
        formData.append("sent", "");
        
        $.ajax({
            method: 'POST',
            enctype: 'multipart/form-data',
            url: thisObject.url,
            data: formData,
            processData: false,
            contentType: false,
            timeout: 60000,
            xhr: function(){
                var xhr = $.ajaxSettings.xhr();
        
                xhr.onprogress = function(e){
                    //
                };
        
                xhr.upload.onprogress = function(e){
                    $("."+thisObject.formClass+" progress").attr("style", "display: block;");
                    $("."+thisObject.formClass+" progress").attr("max", e.total);
                    $("."+thisObject.formClass+" progress").attr("value", e.loaded);
                };
        
                return xhr;
            }
        }).done(function(result){ 
            //alert(result);
            //var rep = JSON.parse(result);
            $("."+thisObject.formClass+" progress").attr("value", 0);
            $("."+thisObject.formClass+" progress").attr("style", "display: none;");
            if(typeof thisObject.successCallback == "function"){
                thisObject.successCallback(result);
            }
            
        }).fail(function(){
            $("."+thisObject.formClass+" progress").attr("value", 0);
            if(typeof thisObject.failedCallback == "function"){
                thisObject.failedCallback();
            }
        });
};