<?php 
namespace DJOLUC\Helper\php;

require_once 'ApplicationNews.php';
require_once 'DbSwitcher.php';



class Session implements \SessionHandlerInterface{
 
    private $sessionTime = 7200;
	private $session = array();
    private $dbPDO;
    private $nomSite;
    private $sqlHost;
    private $sqlDb;
    private $sqlUser;
    private $sqlPass;
    private $connexion_pdo;
    private $dbSwitch;


    public function __construct()
	{
		$this->connexion_pdo = null;
		$out = false;
                
                $this->dbswitch = new DbSwitcher();
        
                if($dbPDO = $this->dbswitch->getMysqlPdo()){
                    $this->connexion_pdo = $dbPDO;
                    $this->CreateTableSessionIfNotExist();
                    $out = true;
                }
		
	   return $out;
	}

    public function open($path, $name)
	{
	   $sessionTime = 7200;
	   $out = false;
	   $this->sessionTime = $sessionTime;
	   if($this->dbPDO = $this->dbswitch->getMysqlPdo()){
                $this->connexion_pdo = $this->dbPDO;
                $this->CreateTableSessionIfNotExist();
                $out = true;
            }
	   return $out;
     }
 
    public function close() {
		return $this->gc(0);
    }
	
	public function CreateTableSessionIfNotExist()
	{
		$sessionTable = "".$this->nomSite."_session";
		$this->sessionTable = $sessionTable;
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    CREATE TABLE IF NOT EXISTS ".$this->sessionTable."
				(
				    sess_id char(40) NOT NULL,
				    sess_datas text,
				    sess_expire bigint(20) NOT NULL,
				    UNIQUE KEY sess_id (sess_id)
				)ENGINE=InnoDB DEFAULT CHARSET=utf8; 					
			");
			$query->execute();
			$query->closeCursor();
		}
		catch(Exception $e)
		{
			$mysqlLogFile = fopen('mysqlLogError.txt','w+');
            fputs($mysqlLogFile, $e->getMessage());
	        fclose($mysqlLogFile);   
		}
	}
        
        public function createPosgreTable(){
            $sessionTable = "".$this->nomSite."_session";
		$this->sessionTable = $sessionTable;
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    CREATE TABLE IF NOT EXISTS ".$this->sessionTable."
				(
				    sess_id text NOT NULL UNIQUE,
				    sess_datas text NOT NULL,
				    sess_expire bigint NOT NULL, 
                                    PRIMARY KEY (sess_id)
				); 					
			");
			$query->execute();
			$query->closeCursor();
		}
		catch(Exception $e)
		{
			$mysqlLogFile = fopen('mysqlLogError.txt','w+');
            fputs($mysqlLogFile, $e->getMessage());
	        fclose($mysqlLogFile);   
		}
        }
 
    public function read($id_session) 
	{
    	$out = '';
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    SELECT sess_datas AS d FROM ".$this->sessionTable."  
				WHERE sess_id = ?  
				AND sess_expire > ".time()."
			");
			$query->bindValue(1, $id_session, \PDO::PARAM_STR);
			$query->execute();
			$data = $query->fetch();
			if($query->rowCount() > 0)
			{
				$out = $data['d'];
			}
			$query->closeCursor();
		}
		catch(Exception $e)
		{
			$mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
		}
		return $out;
    }
    
 
    public function write($id_session,$variables_session) 
	{
    	$out = false;
		try
		{
			$newSessionTime = time() + $this->sessionTime;
			$query = $this->connexion_pdo->prepare
			("
			    SELECT COUNT(sess_id) AS numb FROM ".$this->sessionTable." 
				WHERE sess_id = ?
			");
			$query->bindValue(1, $id_session, \PDO::PARAM_STR);
                        $query->execute();
                        $nombre = 0;
                        if($data = $query->fetch()){
                            $nombre = $data["numb"];
                        }
			if($nombre > 0)
			{
				$query = $this->connexion_pdo->prepare
				("
				    UPDATE ".$this->sessionTable."  
					 SET sess_expire = ?,  
					sess_datas = ? 
					WHERE sess_id = ? 
				");
				$query->bindValue(1, $newSessionTime, \PDO::PARAM_INT);
				$query->bindValue(2, $variables_session, \PDO::PARAM_STR);
				$query->bindValue(3, $id_session, \PDO::PARAM_STR);
				$out = $query->execute();
				$query->closeCursor();	
			}
			else
			{
				$query = $this->connexion_pdo->prepare
				("
				    INSERT INTO ".$this->sessionTable." (
							 sess_id,  
							 sess_expire,  
							 sess_datas)  
							 VALUES( ?, ?, ?)
				");
				$query->bindValue( 1, $id_session, \PDO::PARAM_STR );
				$query->bindValue( 2, $newSessionTime, \PDO::PARAM_INT );
				$query->bindValue( 3, $variables_session, \PDO::PARAM_STR );						
				$out = $query->execute();
				$query->closeCursor();
			}
		}
	    catch(Exception $e)
		{
			  $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
		}
		return $out;
    }
 
    public function destroy($id_session) 
	{
    	$out = false;
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    DELETE FROM ".$this->sessionTable." WHERE sess_id = ?
			");
			$query->bindValue(1, $id_session, \PDO::PARAM_STR);
			$out = $query->execute();
			$query->closeCursor();
		}
		catch(Exception $e)
		{
			  $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
		}
		return $out;
    }
 
    public function gc($lifeTime) 
	{
    	$out = false;
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    DELETE FROM ".$this->sessionTable." WHERE sess_expire <= ".time()."
			");
			$out = $query->execute();
			$query->closeCursor();
		}
		catch(Exception $e)
		{
		      $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
		}
		return $out;
	}
}

$session = new Session();
session_set_save_handler($session);
session_start();
@ini_set('session.entropy_length','0');
@ini_set('session.entropy_length','16');
@ini_set('session.entropy_file','/dev/urandom');
@ini_set('session.hash_function','1');
@ini_set('session.hash_bits_per_character','6');
@ini_set('post_max_size', '0');
