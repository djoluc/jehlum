<?php

namespace DJOLUC\Helper\php;

class ApplicationNews
{
	private $nomSite = "Jehlum";
	private $sqlHost = "localhost";
	private $sqlDb = "jehlum";
	private $sqlUser = "djoluc";
	private $sqlPass = "8cincoti";
    
        
	private $newPDO;
	public function __contruct()
	{
		
		try 
		{
			$this->newPDO = new PDO('mysql:host='.$this->sqlHost.';dbname='.$this->sqlDb, $this->sqlUser, $this->sqlPass);
		}
		catch(Exception $e)
		{
			$mysqlLogFile = fopen('mysqlLogError.txt','w+');
			fputs($mysqlLogFile, $e->getMessage());
			fclose($mysqlLogFile);
		}
		
	}
	
	public function getPDO()
	{
		return $this->newPDO;
	}
	
	public function getNomSite()
	{
		return $this->nomSite;
	}
	
	public function getsqlHost()
	{
		return $this->sqlHost;
	}
	
	public function getSqlDb()
	{
		return $this->sqlDb;
	}
	
	public function getSqlUser()
	{
		return $this->sqlUser;
	}
	
	public function getSqlPassword()
	{
		return $this->sqlPass;
	}
}