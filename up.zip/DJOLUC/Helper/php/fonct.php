<?php 
//les fonctions de l'application

//*fonction qui retourne l'extention d'un fichier

//la fonction qui affiche les images
function img($link,$title,$alt,$cssid,$cssclass,$style)
{
	$img = '<img title="'.$title.'" alt="'.$alt.'" id="'.$cssid.'" class="'.$cssclass.'" style="'.$style.'" src="'.$link.'"/>';
	return $img;
}

//la fonction qui affiche les liens
function a_href($link,$element,$title,$alt,$cssid,$cssclass,$style)
{
	$a = '<a title="'.$title.'" alt="'.$alt.'" id="'.$cssid.'" class="'.$cssclass.'" style="'.$style.'" href="'.$link.'">'.$element.'</a>';
	return $a;
}

//la fonction retournant la chaine de caractère entre deux symboles
function char_between($text,$s1,$s2)
{
	$text = $text;
	$ps1 = null; 
	$ps2 = null;
	$chaine = null;
	for($i = 0;$i < strlen($text);$i++)
	{
		if($text[$i] == $s1) $ps1 = $i;
		if($text[$i] == $s2) $ps2 = $i;
	} 
	if($ps1 != null && $ps2 != null)
	{
		if($ps1 < $ps2)
		{
			for($j = $ps1+1;$j < $ps2;$j++)
			{
				$chaine += $text[$j];
			}
		}
		else if($ps1 > $ps2)
		{
			for($j = $ps2+1;$j < $ps1;$j++)
			{
				$chaine += $text[$j];
			}
		}
		
	}
	
	return $chaine;
}

function get_descript($string,$lien)
{
	include_once'inclus/head.php';	
	$texte=$string;
	$sorti=null;
	$suite=READ_MORE;
	if(strlen($texte) > 200) 
	{
		for($i=0;$i<400;$i++) $sorti="{$sorti}{$texte[$i]}";
		return "{$sorti}...<a href=".$lien.">{$suite}</a>";		
	}
	else
	return $texte;
}

function miniature($dir,$ratio,$save,$file_name)
{
	if(!is_dir($save)) mkdir($save);
		// récupération de la taille de l'image
		if(is_file(''.$dir.'/'.$file_name)){
		    $pixel=getimagesize(''.$dir.'/'.$file_name);
			$width=$pixel[0];
			$height=$pixel[1];
			// echo $width;
			// jpeg
			if($pixel[2] == 2){
			    $new_image=imagecreatefromjpeg(''.$dir.'/'.$file_name);
			    if($width>$height){
					// echo'image paysage';
				    $im=imagecreatetruecolor(round(($ratio/$height)*$width),$ratio);
				    imagecopyresampled($im,$new_image,0,0,0,0,round(($ratio/$height)*$width),$ratio,$width,$height);
			    }
			    else{
                    $im=imagecreatetruecolor($ratio,round(($ratio/$width)*$height));
				    imagecopyresampled($im,$new_image,0,0,0,0,$ratio,round($height*($ratio/$width)),$width,$height);
			    }
				
				imagejpeg($im,$save.'/'.$file_name);	
			}
			// png
			else if($pixel[2] == 3){
				$new_image=imagecreatefrompng(''.$dir.'/'.$file_name);
			    if($width>$height){
				    $im=imagecreatetruecolor(round(($ratio/$height)*$width),$ratio);
				    imagecopyresampled($im,$new_image,0,0,0,0,round(($ratio/$height)*$width),$ratio,$width,$height);
			    }
			    else{
                    $im=imagecreatetruecolor($ratio,round(($ratio/$width)*$height));
				    imagecopyresampled($im,$new_image,0,0,0,0,$ratio,round($height*($ratio/$width)),$width,$height);
			    }
				
				imagepng($im,$save.'/'.$file_name);
			}
			// gif
			else if($pixel[2] == 1){
				$new_image=imagecreatefromgif(''.$dir.'/'.$file_name);
			    if($width>$height){
				    $im=imagecreatetruecolor(round(($ratio/$height)*$width),$ratio);
				    imagecopyresampled($im,$new_image,0,0,0,0,round(($ratio/$height)*$width),$ratio,$width,$height);
			    }
			    else{
                    $im=imagecreatetruecolor($ratio,round(($ratio/$width)*$height));
				    imagecopyresampled($im,$new_image,0,0,0,0,$ratio,round($height*($ratio/$width)),$width,$height);
			    }	
				imagegif($im,$save.'/'.$file_name);
			}	
		}
}


function addTextToAnImage($picture, $text, $saveTo, $red = 255, $green = 255, $blue = 255, $alpha = 70){
    if(is_file($picture)){
        $pixel=getimagesize($picture);
	$width=$pixel[0];
	$height=$pixel[1];
        //$fontPath = "./arial.ttf";
        $fontPath = "./ARIALBD.TTF";
        $size = (7*$width)/60;
        $angle = 0;
        $left = 0;
        $top = $height/2;
        switch ($pixel[2]){
            case 2:
                
                $image = imagecreatefromjpeg($picture);
                $whiteColor = imagecolorallocatealpha($image, $red, $green, $blue, $alpha);
                
                imagettftext($image, $size, $angle, $left, $top, $whiteColor, $fontPath, $text);
                
                imagejpeg($image, $saveTo);
                
                
                break;
            
            case 3:
                
                $image = imagecreatefrompng($picture);
                $whiteColor = imagecolorallocatealpha($image, $red, $green, $blue, $alpha);
                
                imagettftext($image, $size, $angle, $left, $top, $whiteColor, $fontPath, $text);
                
                
                imagepng($image, $saveTo);
                
                break;
            
            case 1:
                
                $image = imagecreatefromgif($picture);
                $whiteColor = imagecolorallocatealpha($image, $red, $green, $blue, $alpha);
                
                imagettftext($image, $size, $angle, $left, $top, $whiteColor, $fontPath, $text);
                
                imagegif($image, $saveTo);
                
                break;
        }
    }
}


function addBorderToImage($picture, $border, $saveTo, $red = 255, $green = 255, $blue = 255){
    if(is_file($picture)){
        $pixel=getimagesize($picture);
	$width=$pixel[0];
	$height=$pixel[1];
        $border = (7*$width)/60;
        $imgAdjWidth = $width + (2*$border);
        $imgAdjHeight = $height + (2*$border);
        $fontPath = "./arial.ttf";
        $size = (7*$width)/60;
        $angle = 0;
        $left = $width/2 - 10*($size/3);
        $top = $height/2;
        switch ($pixel[2]){
            case 2:
                
                $image = imagecreatefromjpeg($picture);
                $newImage = imagecreatetruecolor($imgAdjWidth, $imgAdjHeight);
                $borderColor = imagecolorallocate($newImage, $red, $green, $blue);
                
                imagefilledrectangle($newImage, 0, 0, $imgAdjWidth, $imgAdjHeight, $borderColor);
                
                imagecopyresized($newImage, $image, $border, $border, 0, 0, $width, $height, $width, $height);
                
                imagejpeg($newImage, $saveTo);
                
                
                break;
            
            case 3:
                
                $image = imagecreatefrompng($picture);
                $newImage = imagecreatetruecolor($imgAdjWidth, $imgAdjHeight);
                $borderColor = imagecolorallocate($newImage, $red, $green, $blue);
                
                imagefilledrectangle($newImage, 0, 0, $imgAdjWidth, $imgAdjHeight, $borderColor);
                
                imagecopyresized($newImage, $image, $border, $border, 0, 0, $width, $height, $width, $height);
                
                imagepng($newImage, $saveTo);
                
                break;
            
            case 1:
                
                $image = imagecreatefromgif($picture);
                $newImage = imagecreatetruecolor($imgAdjWidth, $imgAdjHeight);
                $borderColor = imagecolorallocate($newImage, $red, $green, $blue);
                
                imagefilledrectangle($newImage, 0, 0, $imgAdjWidth, $imgAdjHeight, $borderColor);
                
                imagecopyresized($newImage, $image, $border, $border, 0, 0, $width, $height, $width, $height);
                
                imagegif($newImage, $saveTo);
                
                break;
        }
    }
}

function code($texte,$descript,$action,$id,$lien){
		 if($descript){
		     $div=1/2;
	         $texte=$texte;
	         $sorti=null;
	         $suite=" Lire la suite";
	         for($i=0;$i<strlen($texte)*$div;$i++) $sorti="{$sorti}{$texte[$i]}";
		     $texte = $sorti;
		 }
		 $texte=stripslashes(htmlspecialchars($texte));
		 $texte=str_replace(':D','<img src="design/images/smilies/heureux.gif" title="heureux" alt="heureux" id="smilies" />',$texte);
		 $texte=str_replace(':lol:','<img src="design/images/smilies/lol.gif" title="lol" alt="lol" id="smilies"/>',$texte);
		 $texte=str_replace(':triste:','<img src="design/images/smilies/triste.gif" title="triste" alt="triste" id="smilies"/>',$texte);
		 $texte=str_replace(':cool:','<img src="design/images/smilies/cool.gif" title="cool" alt="cool" id="smilies"/>',$texte);
		 $texte=str_replace(':rir:','<img src="design/images/smilies/rire.gif" title="rire" alt="rire" id="smilies"/>',$texte);
		 $texte=str_replace(':conf:','<img src="design/images/smilies/confus.gif" title="confus" alt="confus" id="smilies"/>',$texte);
		 $texte=str_replace(':o','<img src="design/images/smilies/choc.gif" title="choc" alt="choc" id="smilies"/>',$texte);
		 $texte=str_replace(':inte:','<img src="design/images/smilies/interrogation.gif" title="?" alt"?" id="smilies"/>',$texte);
		 $texte=str_replace(':excla:','<img src="design/images/smilies/exclamation.gif" title="!" alt="!" id="smilies"/>',$texte);
		 $texte=str_replace(':cont:','<img src="design/images/smilies/content.gif" title="Content" id="smilies".>',$texte);
		 $texte=str_replace(':aim:','<imag src="design/images/smilies/aime.gif" title="Aime" id="smilies"/>',$texte);
		 $texte=str_replace(':supr:','<img src="design/images/smilies/supris.gif" title="Supris" id="smilies"/>',$texte);
		 $texte=str_replace(':endo:','<img src="design/images/smilies/endormi.gif" title="Endormi" id="smilies"/>',$texte);
		 $texte=str_replace(':rech:','<img src="design/images/smilies/cherche.gif" title="Recherche" id="smilies"/>',$texte);
		 $texte=str_replace(':resp:','<img src="design/images/smilies/respect.gif" title="Respect" id="smilies"/>',$texte);
		 $texte=str_replace(':dang:','<img src="design/images/smilies/danger.gif" title="Danger" id="smilies"/>',$texte);
		 $texte=str_replace(':comb:','<img src="design/images/smilies/combat.gif" title="Combat" id="smilies"/>',$texte);
		 $texte=str_replace(':sup:','<img src="design/images/smilies/super.gif" title="Super" id="smilies"/>',$texte);
		 //mise en form du texte
		 //gra
		 $texte=preg_replace('`\[g\](.+)\[/g\]`isU','<strong>$1</strong>',$texte);
		 //italique
		 $texte=preg_replace('`\[i\](.+)\[/i\]`isU','<em>$1</em>',$texte);
		 //souligner
		 $texte=preg_replace('`\[s\](.+)\[/s\]`isU','<u>$1</u>',$texte);
		 //paragraphe
		 $texte=preg_replace('`\[p\](.+)\[/p\]`isU','<p>$1</p>',$texte);
		 //lien
		 //  $texte=preg_replace('#http://[a-z0-9._/-]+#i','<a href="$0">$0</a>',$texte);
		 $texte=preg_replace('`\[l\](.+)\[/l\]`isU','<a href="$1">$1</a>',$texte);
		 if($lien){
		     return "{$texte}...<a href=traitement.php?a=".md5($action)."&amp;i=".md5($id).">{$suite}</a>";
	     }
	     else{
		    return $texte;
	     }
	 }


?>