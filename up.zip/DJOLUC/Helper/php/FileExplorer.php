<?php
namespace DJOLUC\Helper\php;

class FileExplorer
{
	public function __construct($folder = "/")
	{
		$this->folder = $folder;
		$this->openedFolder = null;
		if(is_dir($folder)) $this->openedFolder = opendir($folder);	
	}
	
	public function removeFile($file):bool
	{
		$response = true;
		if($this->isFile($file)) $response = unlink($file);
		return $response;
	}
	
	public function removeFolder($folder = null)
	{
		$folder = $folder!=null?$folder:$this->folder;
		if($this->isFolder($folder))
		{
			$comptRemoveFolder = 0;
			$openedFolder = opendir($folder);
		    while($fileOrFolder = readdir($openedFolder))
		    {
			    if($fileOrFolder != '.' && $fileOrFolder != ".." && $fileOrFolder != "...")
			    {
				    if($this->isFile($folder."/".$fileOrFolder)) $this->removeFile($folder."/".$fileOrFolder);
			        else if($this->isFolder($folder."/".$fileOrFolder))
			        {
			            $this->removeFolder($folder."/".$fileOrFolder);
						$comptRemoveFolder++;		
			        }
					if($comptRemoveFolder == 98) break; 	
			    }
		    }
		    if($this->isEmptyFolder($folder)) rmdir($folder);	
		}
	}
        
        
	public function getUniqueFileIneFolder($folder = null)
	{
		$folder = $folder!=null?$folder:$this->folder;
		$fileName = "";
		if($this->isFolder($folder))
		{
			$openedFolder = opendir($folder);
			while($fileOrFolder = readdir($openedFolder))
			{
				if($fileOrFolder != '.' && $fileOrFolder != ".." && $fileOrFolder != "...")
				{
					if($this->isFile($folder."/".$fileOrFolder))
					{
						$fileName = $fileOrFolder;	
					}
				}
			}
		}
		return $fileName;
	}
	
	public function isFile($objet)
	{
		return is_file($objet);
	}
	
	public function isFolder($objet)
	{
		return is_dir($objet);
	}
	
	public function isEmptyFolder($folder)
	{
		$response = true;
		if($this->isFolder($folder))
		{
			$openedFolder = opendir($folder);
			while($fileOrFolder = readdir($openedFolder))
			{
				if($fileOrFolder != "." && $fileOrFolder != ".." && $fileOrFolder != "...")
				{
					$response = false;
				}
			}
		}
		return $response;
	}
	
	public function give_ext($fichier)
    {
		$ext = substr(strrchr($fichier,'.'),1);
	    return $ext;
	}
}

?>