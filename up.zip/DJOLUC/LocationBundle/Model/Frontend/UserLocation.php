<?php

namespace DJOLUC\LocationBundle\Model\Frontend;

/**
 * Description of UserLocation
 *
 * @author djoluc
 */
class UserLocation {
    private $userId,
            $latitude, 
            $longitude, 
            $altitude, 
            $country, 
            $town, 
            $district, 
            $means, 
            $time;
    
    public function __construct($userId, $latitude, $longitude, $altitude, $country, $town, $district, $means, $time) {
        $this->userId = $userId;
        $this->latitude = $latitude;
        $this->longitude = $longitude;
        $this->altitude = $altitude;
        $this->country = $country;
        $this->town = $town;
        $this->district = $district;
        $this->means = $means;
        $this->time = $time;
    }
    
    
    public function getUserId() {
        return $this->userId;
    }

    public function getLatitude() {
        return $this->latitude;
    }

    public function getLongitude() {
        return $this->longitude;
    }

    public function getAltitude() {
        return $this->altitude;
    }

    public function getCountry() {
        return $this->country;
    }

    public function getTown() {
        return $this->town;
    }

    public function getDistrict() {
        return $this->district;
    }

    public function getMeans() {
        return $this->means;
    }

    public function getTime() {
        return $this->time;
    }

    public function setUserId($userId) {
        $this->userId = $userId;
    }

    public function setLatitude($latitude) {
        $this->latitude = $latitude;
    }

    public function setLongitude($longitude) {
        $this->longitude = $longitude;
    }

    public function setAltitude($altitude) {
        $this->altitude = $altitude;
    }

    public function setCountry($country) {
        $this->country = $country;
    }

    public function setTown($town) {
        $this->town = $town;
    }

    public function setDistrict($district) {
        $this->district = $district;
    }

    public function setMeans($means) {
        $this->means = $means;
    }

    public function setTime($time) {
        $this->time = $time;
    }
    
    public static function getEMpty(){
        return new UserLocation(0, 0, 0, 0, "", "", "", 0, 0);
    }
}
