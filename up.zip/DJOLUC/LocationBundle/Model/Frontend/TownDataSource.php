<?php

namespace DJOLUC\LocationBundle\Model\Frontend;

require_once 'DJOLUC/Helper/php/DbSwitcher.php';

use DJOLUC\Helper;

/**
 * Description of TownDataSource
 *
 * @author djoluc
 */
class TownDataSource {
    const TABLE_NAME = "town_table";
    const COLUMN_TOWN_ID = "town_id";
    const COLUMN_TOWN_NAME = "town_name";
    const COLUMN_TOWN_REGION = "town_region";
    const COLUMN_COUNTRY_SLUG = "slug";
    const COLUMN_TOWN_LATITUDE = "town_latitude";
    const COLUMN_TOWN_LONGITUDE = "town_longitude";
    
    public $AllColumn;
    
    private $DbPdo;
    private $DbPdoOk;
    private $PropertyOk;
    private $UserTable;
    
    
    public function __construct() {
        $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $this->AllColumn = "".$this::COLUMN_TOWN_NAME.", ".$this::COLUMN_TOWN_REGION.", ".$this::COLUMN_COUNTRY_SLUG.", ".$this::COLUMN_TOWN_LATITUDE.", ".$this::COLUMN_TOWN_LONGITUDE."";
        
        $dbswitch = new Helper\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTable();
            $this->insertAllTowns();
            $this->DbPdoOk = TRUE;
        }     
    }
    
    
    public function createTable(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                        CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME." 
                            (
                                ".$this::COLUMN_TOWN_ID." bigint unsigned NOT NULL AUTO_INCREMENT,
                                ".$this::COLUMN_TOWN_NAME." varchar(500), 
                                ".$this::COLUMN_TOWN_REGION." varchar(200), 
                                ".$this::COLUMN_COUNTRY_SLUG." varchar(500), 
                                ".$this::COLUMN_TOWN_LATITUDE." real, 
                                ".$this::COLUMN_TOWN_LONGITUDE." real, 
                                PRIMARY KEY (".$this::COLUMN_TOWN_ID.")
                            )
                    ");
            if(!$query->execute()){
                throw new \Exception($query->errorInfo()[2]);
            }
            $query->closeCursor();
        } catch (\Exception $e) {
            echo"Impossible de créer la table ".$this::TABLE_NAME." ".$e->getMessage()."";
            die();
        }
    }
    
    
    public function addTown($townName, $townRegion, $countrySlug, $latitude, $longitude):int{
        $out = 0;
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES(?, ?, ?, ?, ?);
                ");
        $query->bindValue(1, $townName, \PDO::PARAM_STR);
        $query->bindValue(2, $townRegion, \PDO::PARAM_STR);
        $query->bindValue(3, $countrySlug, \PDO::PARAM_STR);
        $query->bindValue(4, $latitude);
        $query->bindValue(5, $longitude);
        if($query->execute()){
            $out = $this->DbPdo->lastInsertId();
        }else{
            throw new \Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function isEmpty():bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_TOWN_ID.") AS numb FROM ".$this::TABLE_NAME.";
                ");
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] <= 0;
            }
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function insertAllTowns(){
        if(!$this->isEmpty()){
            return;
        }
        
        require_once 'App/data/WorldCitiesArray.php';
        
        foreach ($cities_array AS $town){
            $this->addTown($town["city"], $town["region"], $town["country"], $town["latitude"], $town["longitude"]);
        }
    }
}
