<?php

namespace DJOLUC\LocationBundle\Model\Frontend;

require_once 'DJOLUC/Helper/php/DbSwitcher.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'UserLocation.php';

use DJOLUC\Helper;
use Exception;

/**
 * Description of UserLocationDataSource
 *
 * @author djoluc
 */
class UserLocationDataSource {
    const TABLE_NAME = "user_location";
    const COLUMN_USER_ID = "user_id";
    const COLUMN_LATITUDE = "location_latitude";
    const COLUMN_LONGITUDE = "location_longitude";
    const COLUMN_ALTITUDE = "location_altitude";
    const COLUMN_COUNTRY = "location_country";
    const COLUMN_TOWN = "location_town";
    const COLUMN_DISTRICT = "location_district";
    const COLUMN_MEANS = "data_means";
    const COLUMN_TIME = "data_time";
    
    public $AllColumn;
    
    private $DbPdo,
            $DbPdoOk,
            $PropertyOk;
    
    const IP_MEANS = 1;
    const BROWSER_MEANS = 2;
    
    public function __construct() {
        $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $this->AllColumn = "".$this::COLUMN_USER_ID.", ".$this::COLUMN_LATITUDE.", ".$this::COLUMN_LONGITUDE.", ".$this::COLUMN_ALTITUDE.", ".
                $this::COLUMN_COUNTRY.",".$this::COLUMN_TOWN.", ".$this::COLUMN_DISTRICT.", ".$this::COLUMN_MEANS.", ".$this::COLUMN_TIME."";
        
        $dbswitch = new Helper\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTableUserLocation();
            $this->DbPdoOk = TRUE;
            $this->deleteUserOldLocation(\DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId());
        }
        
        
        
    }
    
    
    public function createTableUserLocation(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                        CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME." 
                            (
                                ".$this::COLUMN_USER_ID." bigint unsigned NOT NULL,
                                ".$this::COLUMN_LATITUDE." real NOT NULL DEFAULT 0, 
                                ".$this::COLUMN_LONGITUDE." real NOT NULL DEFAULT 0, 
                                ".$this::COLUMN_ALTITUDE." real NOT NULL DEFAULT 0, 
                                ".$this::COLUMN_COUNTRY." varchar(200), 
                                ".$this::COLUMN_TOWN." varchar(200), 
                                ".$this::COLUMN_DISTRICT." varchar(200), 
                                ".$this::COLUMN_MEANS." int NOT NULL DEFAULT 1,
                                ".$this::COLUMN_TIME." bigint NOT NULL DEFAULT 0,
                                FOREIGN KEY (".$this::COLUMN_USER_ID.") REFERENCES ". \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::TABLE_NAME." (". \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::COLUMN_ID.") ON DELETE CASCADE ON UPDATE CASCADE
                            )
                    ");
            if(!$query->execute()){
                throw new Exception($query->errorInfo()[2]);
            }
            $query->closeCursor();
        } catch (Exception $e) {
            echo"Impossible de créer la table ".$this::TABLE_NAME." ".$e->getMessage()."";
            die();
        }
    }
    
    public function addLocation($userId, $latitude, $longitude, $altitude, $country, $town, $district, $means, $time):bool{
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?); 
               ");
        $i = 1;
        $query->bindValue($i++, $userId, \PDO::PARAM_INT);
        $query->bindValue($i++, $latitude);
        $query->bindValue($i++, $longitude);
        $query->bindValue($i++, $altitude);
        $query->bindValue($i++, $country, \PDO::PARAM_STR);
        $query->bindValue($i++, $town, \PDO::PARAM_STR);
        $query->bindValue($i++, $district, \PDO::PARAM_STR);
        $query->bindValue($i++, $means, \PDO::PARAM_INT);
        $query->bindValue($i++, $time, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;
    }
    
    
    
    public function getUserLocations($userId):array{
        $out = Array();
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? ORDER BY ".$this::COLUMN_TIME." ASC;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUserLocations($query);
        }else{
           throw new Exception($query->errorInfo()[2]); 
        }
        $query->closeCursor();
        
        return $out;
    }
    
    public function getUserLastLocation($userId):UserLocation{
        $out = UserLocation::getEMpty();
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT ".$this->AllColumn." FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_TIME." IN "
                . "( SELECT MAX(".$this::COLUMN_TIME.") FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ?);
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $userId, \PDO::PARAM_INT);
        if($query->execute()){
            $out = $this->queryToUserLocation($query);
        }else{
           throw new Exception($query->errorInfo()[2]); 
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function deleteUserOldLocation($userId):bool{
        $out = TRUE;
        
        $userLocations = $this->getUserLocations($userId);
        if(count($userLocations) > 10){
            for($i = 0; $i < count($userLocations) - 5; $i++){
                $out = $this->deleteUserLocation($userLocations[$i]->getUserId(), $userLocations[$i]->getTime());
            }
        }
        
        return $out;
    }
    
    
    public function deleteUserLocation($userId, $time):bool{
        $query = $this->DbPdo->prepare
                ("
                    DELETE FROM ".$this::TABLE_NAME." WHERE ".$this::COLUMN_USER_ID." = ? AND ".$this::COLUMN_TIME." = ?;
                ");
        $query->bindValue(1, $userId, \PDO::PARAM_INT);
        $query->bindValue(2, $time, \PDO::PARAM_INT);
        $out = $query->execute();
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    
    
    private function queryToUserLocation(\PDOStatement $query): UserLocation{
        $out = UserLocation::getEMpty();
        
        if($data = $query->fetch()){
            $out = new UserLocation($data[$this::COLUMN_USER_ID], $data[$this::COLUMN_LATITUDE], $data[$this::COLUMN_LONGITUDE], $data[$this::COLUMN_ALTITUDE], $data[$this::COLUMN_COUNTRY], $data[$this::COLUMN_TOWN], $data[$this::COLUMN_DISTRICT], $data[$this::COLUMN_MEANS], $data[$this::COLUMN_TIME]);
        }
        
        return $out;
    }
    
    private function queryToUserLocations(\PDOStatement $query):array{
        $out = Array();
        
        $i = 0;
        while($data = $query->fetch()){
            $out[$i++] = new UserLocation($data[$this::COLUMN_USER_ID], $data[$this::COLUMN_LATITUDE], $data[$this::COLUMN_LONGITUDE], $data[$this::COLUMN_ALTITUDE], $data[$this::COLUMN_COUNTRY], $data[$this::COLUMN_TOWN], $data[$this::COLUMN_DISTRICT], $data[$this::COLUMN_MEANS], $data[$this::COLUMN_TIME]);
        }
        
        return $out;
    }
}
