<?php

namespace DJOLUC\LocationBundle\Model\Frontend;

require_once 'DJOLUC/Helper/php/DbSwitcher.php';

use DJOLUC\Helper;
/**
 * Description of CountryDataSource
 *
 * @author djoluc
 */
class CountryDataSource {
    const TABLE_NAME = "country_table";
    const COLUMN_COUNTRY_SLUG = "slug";
    const COLUMN_COUNTRY_NAME = "name";
    
    public $AllColumn;
    
    private $DbPdo;
    private $DbPdoOk;
    private $PropertyOk;
    private $UserTable;
    
    
    public function __construct() {
        $this->UserTable = null;
        
         $this->DbPdo = null;
        $this->DbPdoOk = false;
        //vérification de la justesse des propriétés de l'utilisateur
        $this->PropertyOk = true;
        
        $this->AllColumn = "".$this::COLUMN_COUNTRY_SLUG.", ".$this::COLUMN_COUNTRY_NAME."";
        
        $dbswitch = new Helper\DbSwitcher();
        
        if($this->DbPdo = $dbswitch->getMysqlPdo()){
            $this->createTable();
            $this->putArrayCountrys();
            $this->DbPdoOk = TRUE;
        }
    }
    
    
    public function createTable(){
        try{
            $query = $this->DbPdo->prepare
                    ("
                        CREATE TABLE IF NOT EXISTS ".$this::TABLE_NAME."
                            ( 
                                ".$this::COLUMN_COUNTRY_SLUG." varchar(500), 
                                ".$this::COLUMN_COUNTRY_NAME." varchar(500)
                            );
                    ");
            if(!$query->execute()){
                throw new \Exception($query->errorInfo()[2]);
            }
            $query->closeCursor();
        } catch (Exception $e) {
            echo"Impossible de créer la table block ".$e->getMessage()."";
            die();
        }
    }
    
    
    
    public function addCountry($slug, $name): bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    INSERT INTO ".$this::TABLE_NAME."(".$this->AllColumn.") VALUES(?, ?);
                ");
        $query->bindValue(1, $slug);
        $query->bindValue(2, $name);
        $out = $query->execute();
        if(!$out){
            throw new Exception($query->errorInfo()[2]);
        }
        $query->closeCursor();
        
        
        return $out;  
    }
    
    
    public function isEmpty():bool{
        $out = false;
        
        $query = $this->DbPdo->prepare
                ("
                    SELECT COUNT(".$this::COLUMN_COUNTRY_SLUG.") AS numb FROM ".$this::TABLE_NAME.";
                ");
        if($query->execute()){
            if($data = $query->fetch()){
                $out = $data["numb"] <= 0;
            }
        }
        $query->closeCursor();
        
        return $out;
    }
    
    
    public function putArrayCountrys(){
        
        if(!$this->isEmpty()){
            return;
        }
        
        require_once 'App/data/CountriesArrayData.php';
        
        foreach ($CountryArrayData AS $country){
            $this->addCountry($country["slug"], $country["title"]);
        }
    }
}
