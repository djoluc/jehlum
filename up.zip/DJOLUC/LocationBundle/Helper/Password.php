<?php 
namespace DJOLUC\MainBundle\Helper;

class Password
{
    private $salt = 'zUl8*ryP$_';
	private static $password;
	function __construct($password = "")
	{
		$this::$password = $this->salt."".$password;
		// $this->hashPassword = password_hash(md5($this::$password), 1);
		$this->hashPassword = password_hash($this::$password, PASSWORD_DEFAULT);
	}
	public function getHashPassword()
	{
		$this->hashPassword = password_hash($this::$password, PASSWORD_DEFAULT);
		
		return $this->hashPassword;		
	}
		
	public function isPassMatch($password, $alsoGive="")
	{
            $password = $this->salt."".$password;
		if($alsoGive == "")
		{
			if(password_hash($password, PASSWORD_DEFAULT) == $this->hashPassword)
		        return true;
		    else
		        return false;	
		}
		else
		{
			if(password_hash($password, PASSWORD_DEFAULT) == $alsoGive)
		        return true;
		    else
		        return false;	
		}
	}
	
	public function setPassword($password = "")
	{
            $password = $this->salt."".$password;
		$this::$password = $password;
		
		$this->hashPassword = password_hash($this::$password, PASSWORD_DEFAULT);;
	}
};

?>