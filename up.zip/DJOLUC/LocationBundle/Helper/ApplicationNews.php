<?php

namespace DJOLUC\MainBundle\Helper;

class ApplicationNews
{
	private $nomSite = "Artisandici";
	private $sqlHost = "localhost";
	private $sqlDb = "artisan";
	private $sqlUser = "djoluc";
	private $sqlPass = "8cincoti";
	private $newPDO;
	function __contruct()
	{
		$this->nomSite = "Artisandici";
		$this->sqlHost = "localhost";
		$this->sqlDb = "artisan";
		$this->sqlUser = "djoluc";
		$this->sqlPass = "8cincoti";
		
		try 
		{
			$this->newPDO = new PDO('mysql:host='.$this->sqlHost.';dbname='.$this->sqlDb, $this->sqlUser, $this->sqlPass);
		}
		catch(Exception $e)
		{
			$mysqlLogFile = fopen('mysqlLogError.txt','w+');
			fputs($mysqlLogFile, $e->getMessage());
			fclose($mysqlLogFile);
		}
		
	}
	
	public function getPDO()
	{
		return $this->newPDO;
	}
	
	public function getNomSite()
	{
		return $this->nomSite;
	}
	
	public function getsqlHost()
	{
		return $this->sqlHost;
	}
	
	public function getSqlDb()
	{
		return $this->sqlDb;
	}
	
	public function getSqlUser()
	{
		return $this->sqlUser;
	}
	
	public function getSqlPassword()
	{
		return $this->sqlPass;
	}
}

?>