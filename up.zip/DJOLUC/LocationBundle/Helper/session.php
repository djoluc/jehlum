<?php 
require_once 'applicationNews.class.php';

class session{
 
    private $sessionTime = 7200;
	private $session = array();
    private $dbPDO;
    private $nomSite;
    private $sqlHost;
    private $sqlDb;
    private $sqlUser;
    private $sqlPass;
    private $connexion_pdo;
	
	public function __construct($sqlHost, $sqlDb, $sqlUser, $sqlPass)
	{
		$applicationNews = new applicationNews();
		$this->nomSite = $applicationNews->getNomSite();
		$this->sqlHost = $applicationNews->getsqlHost();
		$this->sqlDb = $applicationNews->getSqlDb();
		$this->sqlUser = $applicationNews->getSqlUser();
		$this->sqlPass = $applicationNews->getSqlPassword();
		$this->connexion_pdo = null;
		$out = false;
		
		
		try
	   {
		  $dbPDO = new PDO('mysql:host='.$this->sqlHost.';dbname='.$this->sqlDb, $this->sqlUser, $this->sqlPass);
		  if(!$dbPDO)
		  {
			  $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, 'connexion échoué');
			  fclose($mysqlLogFile);
		  } 
		  else
		  {
			  $this->connexion_pdo = $dbPDO;
			  $this->CreateTableSessionIfNotExist();
			  $out = true;
		  }
	   }
	   catch(Exception $e)
	   {
		      $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
	   }
	   return $out;
	}

    public function open()
	{
	   $sessionTime = 7200;
	   $out = false;
	   $this->sessionTime = $sessionTime;
	   try
	   {
		  $dbPDO = new PDO('mysql:host='.$this->sqlHost.';dbname='.$this->sqlDb, $this->sqlUser, $this->sqlPass);
		  if(!$dbPDO)
		  {
			  $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, 'connexion échoué');
			  fclose($mysqlLogFile);
		  } 
		  else
		  {
			  $this->connexion_pdo = $dbPDO;
			  $this->CreateTableSessionIfNotExist();
			  $out = true;
		  }
	   }
	   catch(Exception $e)
	   {
		      $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
	   }
	   return $out;
     }
 
    public function close() {
		return $this->gc();
    }
	
	public function CreateTableSessionIfNotExist()
	{
		$sessionTable = "".$this->nomSite."_session";
		$this->sessionTable = $sessionTable;
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    CREATE TABLE IF NOT EXISTS ".$this->sessionTable."
				(
				    sess_id char(40) NOT NULL,
				    sess_datas text,
				    sess_expire bigint(20) NOT NULL,
				    UNIQUE KEY sess_id (sess_id)
				)ENGINE=InnoDB DEFAULT CHARSET=utf8; 					
			");
			$query->execute();
			$query->closeCursor();
		}
		catch(Exception $e)
		{
			$mysqlLogFile = fopen('mysqlLogError.txt','w+');
            fputs($mysqlLogFile, $e->getMessage());
	        fclose($mysqlLogFile);   
		}
	}
 
    public function read($id_session) 
	{
    	$out = '';
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    SELECT sess_datas AS d FROM ".$this->sessionTable."  
				WHERE sess_id = ?  
				AND sess_expire > ".time()."
			");
			$query->bindValue(1, $id_session, PDO::PARAM_STR);
			$query->execute();
			$data = $query->fetch();
			if($query->rowCount() > 0)
			{
				$out = $data['d'];
			}
			$query->closeCursor();
		}
		catch(Exception $e)
		{
			$mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
		}
		return $out;
    }
 
    public function write($id_session,$variables_session) 
	{
    	$out = false;
		try
		{
			$newSessionTime = time() + $this->sessionTime;
			$query = $this->connexion_pdo->prepare
			("
			    SELECT sess_id FROM ".$this->sessionTable." 
				WHERE sess_id = ?
			");
			$query->bindValue(1, $id_session, PDO::PARAM_STR);
		    $query->execute();
			$nombre = $query->rowCount();
			if($nombre > 0)
			{
				$query = $this->connexion_pdo->prepare
				("
				    UPDATE ".$this->sessionTable."  
					 SET sess_expire = ?,  
					sess_datas = ? 
					WHERE sess_id = ? 
				");
				$query->bindValue(1, $newSessionTime, PDO::PARAM_INT);
				$query->bindValue(2, $variables_session, PDO::PARAM_STR);
				$query->bindValue(3, $id_session, PDO::PARAM_STR);
				$query->execute();
				if($query)
				{
					$out = true;
				}
				$query->closeCursor();	
			}
			else
			{
				$query = $this->connexion_pdo->prepare
				("
				    INSERT INTO ".$this->sessionTable." (
							 sess_id,  
							 sess_expire,  
							 sess_datas)  
							 VALUES( ?, ?, ?)
				");
				$query->bindValue( 1, $id_session, PDO::PARAM_STR );
				$query->bindValue( 2, $newSessionTime, PDO::PARAM_INT );
				$query->bindValue( 3, $variables_session, PDO::PARAM_STR );						
				$query->execute();
				
				if ($query)
				{
					$out = true;
				}
				$query->closeCursor();
			}
		}
	    catch(Exception $e)
		{
			  $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
		}
		return $out;
    }
 
    public function destroy($id_session) 
	{
    	$out = false;
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    DELETE FROM ".$this->sessionTable." WHERE sess_id = ?
			");
			$query->bindValue(1, $id_session, PDO::PARAM_STR);
			$query->execute();
			$data = $query->fetch();
			if($data)
			{
				$out = true;
			}
			$query->closeCursor();
		}
		catch(Exception $e)
		{
			  $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
		}
		return $out;
    }
 
    public function gc() 
	{
    	$out = false;
		try
		{
			$query = $this->connexion_pdo->prepare
			("
			    DELETE FROM ".$this->sessionTable." WHERE sess_expire <= ".time()."
			");
			$query->execute();
			if($query) $out = true;
		}
		catch(Exception $e)
		{
		      $mysqlLogFile = fopen('mysqlLogError.txt','w+');
			  fputs($mysqlLogFile, $e->getMessage());
			  fclose($mysqlLogFile);
		}
		return $out;
	}
};
/*$applicationNew = new applicationNews();
 $sqlHost = $applicationNew->getsqlHost();
 $sqlDb = $applicationNew->getSqlDb();
 $sqlUser = $applicationNew->getSqlUser();
 $sqlPass = $applicationNew->getSqlPassword();
$session = new session($sqlHost, $sqlDb, $sqlUser, $sqlPass);*/
/*session_set_save_handler(array($session,"open"),
                         array($session,"close"),
                         array($session,"read"),
                         array($session,"write"),
                         array($session,"destroy"),
                         array($session,"gc"));*/
session_start();
ini_set('session.entropy_length','0');
ini_set('session.entropy_length','16');
ini_set('session.entropy_file','/dev/urandom');
ini_set('session.hash_function','1');
ini_set('session.hash_bits_per_character','6');
ini_set('post_max_size', '0');
