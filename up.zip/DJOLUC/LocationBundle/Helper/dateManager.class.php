<?php
/**
 * 
 * @author DJOSSA Luc
 * @version 1.1
 * @copyright 2017
 * 
 *
 *
 */
class DateManager
{
	private $timeStamp;
	private $seconde;
	private $minute;
	private $hours;
	private $dayOfWeakNum;
	private $dayOfMouthNum;
	private $mouthOfYearNum;
	private $yearTwoDigits;
	private $yearFourDigits;
	public function __construct($timeStamp = 0)
	{
		$this->timeStamp = $timeStamp;
		$this->seconde = date('s', $this->timeStamp);
		$this->minute = date('i', $this->timeStamp);
		$this->hours = date('H', $this->timeStamp);
		$this->dayOfWeakNum = date('N', $this->timeStamp);
		$this->dayOfMouthNum = date('j', $this->timeStamp);
		$this->mouthOfYearNum = date('n', $this->timeStamp);
		$this->yearTwoDigits = date('y', $this->timeStamp);
		$this->yearFourDigits = date('Y', $this->timeStamp);
	}
	
	public function getSeconde($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		return date('s', $timeStamp);
	}
	
	public function getMinute($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		return date('i', $timeStamp);
	}
	
	public function getHours($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		return date('H', $timeStamp);
	}
	
	public function getDayOfWeakNum($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		return date('N', $timeStamp);
	}
	
	public function getDayOfMouthNum($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		return date('d', $timeStamp);
	}
	
	public function getMouthOfYearNum($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		return date('m', $timeStamp);
	}
	
	public function getYearTwoDigits($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		return date('y', $timeStamp);
	}
	
	public function getYearFourDigits($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		return date('Y', $timeStamp);
	}
	
	public function getDateReference($timeStamp = 0)
	{
		$out = "";
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		$days = array('','Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche');
		$mouth = array('','Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octorbre', 'Novembre', 'Décembre');
		$out = "le ".$days[$this->getDayOfWeakNum($timeStamp) - 0]." ".$this->getdayOfMouthNum($timeStamp)." ".$mouth[$this->getMouthOfYearNum($timeStamp) - 0]." ".$this->getYearFourDigits($timeStamp);
		if($this->getYearFourDigits($timeStamp) == $this->getYearFourDigits(time()))
		{
			$out = "le ".$days[$this->getDayOfWeakNum($timeStamp) - 0]." ".$this->getdayOfMouthNum($timeStamp)." ".$mouth[$this->getMouthOfYearNum($timeStamp) - 0]." de cette année"." à ".$this->getHours($timeStamp)."h".$this->getMinute($timeStamp);
			if($this->getMouthOfYearNum($timeStamp) == $this->getMouthOfYearNum(time()))
			{
				$out = "le ".$days[$this->getDayOfWeakNum($timeStamp) - 0]." ".$this->getdayOfMouthNum($timeStamp)." de ce mois"." à ".$this->getHours($timeStamp)."h".$this->getMinute($timeStamp);
				//if((($this->getDayOfMouthNum(time()) + 0) - ($this->getDayOfMouthNum($timeStamp) + 0) < 7) && ((($this->getDayOfWeakNum(time())+ 0) - ($this->getDayOfWeakNum($timeStamp)) + 0)<= 5 - ($this->getDayOfWeakNum($timeStamp) + 0)))
				//{
					if(($this->getDayOfWeakNum(time())+ 0) - ($this->getDayOfWeakNum($timeStamp) + 0) >= 0)
					{
						$out = "le ".$days[$this->getDayOfWeakNum($timeStamp) - 0]." passé"." à ".$this->getHours($timeStamp)."h".$this->getMinute($timeStamp);
						if(($this->getDayOfMouthNum(time()) + 0) == ($this->getDayOfMouthNum($timeStamp) + 0) + 1)
						{
							$out = " hier à ".$this->getHours($timeStamp)."h".$this->getMinute($timeStamp);
						}
						elseif (($this->getDayOfMouthNum(time()) + 0) == ($this->getDayOfMouthNum($timeStamp) + 0))
						{
							$out = "aujourd'hui à ".$this->getHours($timeStamp)."h".$this->getMinute($timeStamp);
							$interval = time() - $timeStamp;
							if($interval < 60*60)
							{
								$minute = (floor($interval/60) >= 2)?"minutes":"minute";
								$out = " il-y-a environ ".floor($interval/60)." ".$minute;
								if($interval < 60)
								{
									$seconde = ($interval >= 2)?"secondes":"seconde";
									$out = " il-y-a ".$interval." ".$seconde;
									if($interval == 0)
									{
										$out = " à l'instant";
									}
								}
							}
						}
					}
				//}
			}
		}
	    return $out;
	}
        
        public function getShortReference($timeStamp = 0){
            
            $out = "";
            
            $out = $this->getDayOfMouthNum($timeStamp)."/".$this->getMouthOfYearNum($timeStamp)."/".$this->getYearTwoDigits($timeStamp);
            if($this->getDayOfMouthNum(time()) == $this->getDayOfMouthNum($timeStamp) && $this->getMouthOfYearNum(time()) == $this->getMouthOfYearNum($timeStamp) && 
                    $this->getYearFourDigits(time()) == $this->getYearFourDigits($timeStamp)){
                $out = "Aujourd'hui";
            }
            
            return $out;
        }


        public function getTimestampFromdate($year, $mouth, $dayOfMouth, $hours = 0, $minute = 0, $seconde = 0)
	{
		$mouthAndDayNumb = array(0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		$timestamp = 0;
		//On atteind l'année à partie de 0
		while(($this->getYearFourDigits($timestamp)+0) < $year)
		{
			if($this->getYearFourDigits($timestamp)+0 < $year-1)
			    $timestamp += 365*24*60*60;
			else 
				$timestamp += 24*60*60;
		}
		//On atteind le mois
		while(($this->getMouthOfYearNum($timestamp)+0) < $mouth)
		{
			$timestamp += 24*60*60;
		}
		//On atteind le jour
		while(($this->getDayOfMouthNum($timestamp)+0) < $dayOfMouth)
		{
			$timestamp += 24*60*60;
		}
		//On atteind l'heure
		while(($this->getHours($timestamp)+0) != $hours)
		{
			$timestamp += 60*60;
		}
		//On atteind la minute
		while(($this->getMinute($timestamp)+0) != $minute)
		{
			$timestamp += 60;
		}
		
		//On atteind la seconde
		while(($this->getSeconde($timestamp)+0) != $seconde)
		{
			$timestamp += 1;
		}
		return $timestamp;
	}
	
	public function getNextMouthTimestamp($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		$mouthAndDayNumb = array(0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		$out = $timeStamp + $mouthAndDayNumb[$this->getMouthOfYearNum($timeStamp)+0]*24*60*60;
		return $out;
	}
	
	public function getMouthDaysNumb($timeStamp = 0)
	{
		$timeStamp = ($timeStamp != 0)?$timeStamp:$this->timeStamp;
		$mouthAndDayNumb = array(0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		return $mouthAndDayNumb[$this->getMouthOfYearNum($timeStamp)+0];
	}
	
	public function setTimeStamp($timeStamp)
	{
		$this->timeStamp = $timeStamp;
	}
        
        public function unPackSeconde($secondeTime):string{
            $out = $secondeTime;
            $tmp =$secondeTime;
            $h = 0;
            $m = 0;
            $s = 0;
            
            $h = (int)($tmp/3600);
            $t = $tmp - 3600*$h;
            $m =  (int)($tmp/60);
            $s = $t - $m*60;
            
            $h = $h>0?$h."h ":"";
            $m = $m>0?$m."min ":"";
            $s = $s>0?$s."s":"";
            
            $out = $h."".$m."".$s;
            
            return $out;
        }
}