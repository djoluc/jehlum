<?php 


/* @author Luc DJOSSA
 * Gestionnaire de chargement de fichier sur le serveur
 * date de création : 12/07/17
 * date de mise à jour: 29/07/18
 * version: 1.1
 */

class UploadFile
{
    const TIME_AND_USER_ID_NAME = 1;
    
	public function __construct($index="", $destination="", $coId = 0, $type="", $newNameType="", $ownName="")
	{
		$this->index = $index;
		$this->destination = $destination;
		$this->coId = $coId;
		$this->type = $type;
		$this->newNameType = $newNameType;
		$this->ownName = $ownName;
		$this->newName = "";
		$this->maxSizeImage = 2000000000; //octet
		$this->maxSizeDocument = 4000000000;
		$this->maxSizeVideo = 100000000;
		$this->maxSizeApplication = 50000000;
                $this->maxSizeAudio = 100000000;
		$this->extImage = Array('jpg','jpeg','png','gif','bmp');
		$this->extDocument = Array('pdf','doc','xdoc','ppt');
		$this->extVideo = Array('mp4', 'avi', '3gp', 'mpg');
		$this->extAppli = Array('apk', 'exe');
                $this->extAudio = Array('mp3', 'mp4', 'wav', 'ogg', "m4a");
		$this->extention  = "";
	}
	
	public function testProperty()
	{
		$this->propertyOk = true;
		if(!empty($_FILES[$this->index]['tmp_name']))
		{
			if($_FILES[$this->index]['error'] > 0)
			{
				$this->propertyOk = false;
				echo"Erreur lors du transfère du fichier";
			}
			$this->extention = strtolower(substr(strrchr($_FILES[$this->index]['name'],'.'),1)); //extention
			if($this->type == "image")
			{
				if($_FILES[$this->index]['size'] > $this->maxSizeImage)
			    {
				    $this->propertyOk = false;
				    echo"Le fichier est trop volumineux. Veuillez choisir un fichier de ".($this->maxSizeImage/1000000)." Mb au plus.";
			    }
				if(!in_array($this->extention, $this->extImage))
				{
					$this->propertyOk = false;
					$exts = "";
					$n = sizeof($this->extImage);
					for($i = 0; $i < $n; $i++)
					{
						$exts = $exts." ".$this->extImage[$i].", ";
					}
					echo"Veuillez choisir entre les extentions suivante ".$exts; 
				}
			}
			else if($this->type == "document")
			{
				if($_FILES[$this->index]['size'] > $this->maxSizeDocument)
			    {
				    $this->propertyOk = false;
				    echo"Le fichier est trop volumineux. Veuillez choisir un fichier de ".($this->maxSizeDocument/1000000)." Mb au plus.";
			    }
				if(!in_array($this->extention, $this->extDocument))
				{
					$this->propertyOk = false;
					$exts = "";
					$n = sizeof($this->extDocument);
					for($i = 0; $i < $n; $i++)
					{
						$exts = $exts." ".$this->extDocument[$i].", ";
					}
					echo"Veuillez choisir entre les extentions suivantes ".$exts; 
				}
			}
			else if($this->type == "video")
			{
				if($_FILES[$this->index]['size'] > $this->maxSizeDocument)
			    {
				    $this->propertyOk = false;
				    echo"Le fichier est trop volumineux. Veuillez choisir un fichier de ".($this->maxSizeVideo/1000000)." Mb au plus.";
			    }
				if(!in_array($this->extention, $this->extVideo))
				{
					$this->propertyOk = false;
					$exts = "";
					$n = sizeof($this->extVideo);
					for($i = 0; $i < $n; $i++)
					{
						$exts = $exts." ".$this->extVideo[$i].", ";
					}
					echo"Veuillez choisir entre les extentions suivante ".$exts; 
				}
			}
			else if($this->type == "application")
			{
				if($_FILES[$this->index]['size'] > $this->maxSizeApplication)
			    {
				    $this->propertyOk = false;
				    echo"Le fichier est trop volumineux. Veuillez choisir un fichier de ".($this->maxSizeApplication/1000000)." Mb au plus.";
			    }
				if(!in_array($this->extention, $this->extAppli))
				{
					$this->propertyOk = false;
					$exts = "";
					$n = sizeof($this->extAppli);
					for($i = 0; $i < $n; $i++)
					{
						$exts = $exts." ".$this->extAppli[$i].", ";
					}
					echo"Veuillez choisir entre les extentions suivante ".$exts; 
				}
			}else if($this->type == "audio"){
                            
                            if($_FILES[$this->index]['size'] > $this->maxSizeAudio){
                                $this->propertyOk = false;
                                echo"Le fichier est trop volumineux. Veuillez choisir un fichier de ".($this->maxSizeAudio/1000000)." Mb au plus.";
                            }
                            
                            if(!in_array($this->extention, $this->extAudio)){
                                $this->propertyOk = false;
                                $exts = "";
                                $n = sizeof($this->extAudio);
				for($i = 0; $i < $n; $i++)
				{
                                    $exts = $exts." ".$this->extAudio[$i].", ";
				}
				echo"Veuillez choisir entre les extentions suivante ".$exts; 
                            }
                        }
		}
		return $this->propertyOk;
	}
	
	
	public function upload($showMessage = true)
	{
		$result = false;
		if($this->testProperty())
		{
			$time = time();
			$orgnom = "";
			$dest_nom = "";
			$orgnom = $_FILES[$this->index]['name'];
			$dest_nom = "{$this->destination}/{$orgnom}";
			$this->newName = "{$orgnom}";
			if($this->newNameType == "coid")
			{
				$dest_nom="{$this->destination}/{$coid}";
				$this->newName = "{$coid}.{$this->extention}";
			}
			else if($this->newNameType == "time_name")
			{
				$this->newName = "{$time}_{$orgnom}";
				$dest_nom="{$this->destination}/{$this->newName}";
			}
			else if($this->newNameType == "own_name")
			{
				$dest_nom="{$this->destination}/{$this->ownName}.{$this->extention}";
				$this->newName = "{$this->ownName}.{$this->extention}";
			}
			//creation du dossier de destination si elle n'existe pas 
		    if(!is_dir($this->destination)) mkdir($this->destination, 0777, true);
                    
                    $result=move_uploaded_file($_FILES[$this->index]['tmp_name'], $dest_nom);
                    
		    if($result)
		    {
	            if($showMessage) echo'Transfère réussit!';
                    echo'Transfère réussit!';
			    // miniature('avatar',150,'avatar/mini',$nom);
		    } 
		    else 
		        echo'Echec du transfère';	
		}
		return $result;
	}
	
	public function getFileName()
	{
		return $this->newName;
	}
	
	public function isVideo($name)
	{
		$response = false;
		$extention = strtolower(substr(strrchr($name,'.'),1));
		if(in_array($extention, $this->extVideo))
		{
			$response = true;
		}
		return $response;
	}
	
	public function isImage($name)
	{
		$response = false;
		$extention = strtolower(substr(strrchr($name,'.'),1));
		if(in_array($extention, $this->extImage))
		{
			$response = true;
		}
		return $response;
	}
}