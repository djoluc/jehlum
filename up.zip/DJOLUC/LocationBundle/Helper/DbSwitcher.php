<?php
namespace DJOLUC\MainBundle\Helper;

require_once 'ApplicationNews.php';;


class DbSwitcher
{
    public static $dbPDO;
    public static $i = 0;
    public function __construct()
	{
            //..
	}
	
	public function getMysqlPdo($dbHost = "", $dbName = "", $dbUser = "", $dbUserPass = "")
	{
            if($dbHost == ""){
                $applicationNew = new ApplicationNews();
        
                $this->nomSite = $applicationNew->getNomSite();
                $dbHost = $applicationNew->getsqlHost();
                $dbName = $applicationNew->getSqlDb();
                $dbUser = $applicationNew->getSqlUser();
                $dbUserPass = $applicationNew->getSqlPassword();
            }
            
            try
            {
                //print "+++++++++++++++++++++++++++++++++++++++".++$this::$i."+++++++++++++++++++++++";
                if($this::$dbPDO == NULL){
                    //print "+++++++++++++++++++++++++++++++++++++++".++$this::$i."+++++++++++++++++++++++";
                    $this::$dbPDO = new \PDO('mysql:host='.$dbHost.';dbname='.$dbName, $dbUser, $dbUserPass);
                }
            }
            catch (Exception $e)
            {
		$mysqlLogFile = fopen('mysqlLogError.txt','w+');
		fputs($mysqlLogFile, $e->getMessage());
		fclose($mysqlLogFile);
		echo "Erreur lors de la connexion à la base de données:".$e->getMessage()."";
		die();
            }
		
            return $this::$dbPDO;
	}
	
	public function getSqlitePdo($fileName="mine.db")
	{
		try{
                        if($this::$dbPDO == NULL){
                            $this::$dbPDO= new \PDO('sqlite:'.$fileName."");
                            $this::$dbPDO->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                            $this::$dbPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // ERRMODE_WARNING | ERRMODE_EXCEPTION | ERRMODE_SILENT
                        }
		} catch(Exception $e) {
			echo "Impossible d'accéder à la base de données SQLite : ".$e->getMessage();
			die();
		}
		return $this::$dbPDO;
	}
        
        public function getPostgrePdo(): \PDO{
            
            $applicationNew = new ApplicationNews();
        
            $this->nomSite = $applicationNew->getNomSite();
            $dbHost = $applicationNew->getsqlHost();
            $dbName = $applicationNew->getSqlDb();
            $dbUser = $applicationNew->getSqlUser();
            $dbUserPass = $applicationNew->getSqlPassword();
            
            try{
                if($this::$dbPDO == NULL){
                    $this::$dbPDO = new \PDO('pgsql:host='.$dbHost.';dbname='.$dbName, $dbUser, $dbUserPass);
                    if($this::$dbPDO){
                        $this::$dbPDO->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
                    }
                    
                }
            } catch (Exception $e) {
                $mysqlLogFile = fopen('mysqlLogError.txt','w+');
		fputs($mysqlLogFile, $e->getMessage());
		fclose($mysqlLogFile);
		echo "Erreur lors de la connexion à la base de données:".$e->getMessage()."";
		die();
            }
            
            return $this::$dbPDO;
        }
}

DbSwitcher::$dbPDO = NULL;