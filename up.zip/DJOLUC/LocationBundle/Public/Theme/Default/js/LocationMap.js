var locationMap = null;

$(document).ready(function(){
    locationMap = new LocationMap("map_div");
    
    //var map = L.map('map_div');

/*L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
	attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);*/


});

function LocationMap(contener_id){
    this.contener = $("#"+contener_id+"")[0];
    this.map = null;  
    this.geolocalManager = new GeolocalManager();
    
    this.requestLocationAuthority(function(){
        locationMap.geolocalManager.locate(function(lat, long){
           locationMap.registerCurrentUserLocation(long, lat, 0, "", "", "", 2);
        locationMap.map = L.map(contener_id, {
            center: [lat, long],//latitude, longitude
            zoom: 10
        });
    
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(locationMap.map);
        
        locationMap.addPositionPointerAndPopup("Approximation de votre position", lat, long);
        
        locationMap.getArtisanLocation(function(artisanLat, artisanLong){
            //alert(lat);
            locationMap.addRootBetween(artisanLat, artisanLong, lat, long);
            });
        });
        
        
    },
    function(){
        
        locationMap.map = L.map(contener_id, {
            center: [6, 2],//latitude, longitude
            zoom: 5
        });
    
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(locationMap.map);
        
        locationMap.getArtisanLocation();
        
    });

}



LocationMap.prototype.myLocation = function(positionCallback){
    this.geolocalManager.locate(function(lat, long){
        if(typeof positionCallback === "function"){
            positionCallback(lat, long);
        }
    });
};


LocationMap.prototype.addPositionPointerAndPopup = function(popupMessage, lat, long){
    L.marker([lat, long]).addTo(locationMap.map)
        .bindPopup(popupMessage)
        .openPopup();
};



LocationMap.prototype.registerCurrentUserLocation = function(pLongitude, pLatitude, pAltitude, pCountry, pTown, pDistrict, pMeans){
    $.post(
     "?a=userLocation&add", 
     {sent: "", longitude: pLongitude, latitude: pLatitude, altitude: pAltitude, country: pCountry, pTown, district: pDistrict, means: pMeans}, 
     function(result){
         //alert(result);
     });
};

LocationMap.prototype.getArtisanLocation = function(answerCallback){
    var artisanId = $("input[name='artisanId']").val();
    $.post(
     "?a=userLocation&getArtisanLocation&artisanId="+artisanId, 
     {sent: ""}, 
     function(result){
         //alert(result);
         var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
         if(rep.result){
             locationMap.addPositionPointerAndPopup("Position de l'artisan", parseFloat(rep.latitude), parseFloat(rep.longitude));
             
             if(typeof answerCallback === "function"){
                 answerCallback(rep.latitude, rep.longitude);
             }
         }
     });
};

LocationMap.prototype.requestLocationAuthority = function(acceptCallback, rejectCallback){

    function hideDialog(){
        $("#location_request_box").css("bottom", "-300px");
    }
    
    if($("#location_request_box .user_accept_setting").val() === "1"){
        acceptCallback();
        hideDialog();
        return;
    }

    var tmp = window.setTimeout(function(){
        $("#location_request_box").css("bottom", "0px");
        window.clearTimeout(tmp);
    },1000);
    
    $("#location_request_box .accept").click(function(){
        if(typeof acceptCallback === "function"){
            acceptCallback();
            hideDialog();
        }
    });
    
    $("#location_request_box .reject").click(function(){
        if(typeof rejectCallback === "function"){
            rejectCallback();
            hideDialog();
        }
    });
};


LocationMap.prototype.addRootBetween = function(Alat, Along, Blat, Blong){
    var control = L.Routing.control(L.extend(window.lrmConfig, {
	waypoints: [
		L.latLng(Alat, Along),
		L.latLng(Blat, Blong)
	],
	geocoder: L.Control.Geocoder.nominatim(),
	routeWhileDragging: true,
	reverseWaypoints: true,
	showAlternatives: true,
	altLineOptions: {
		styles: [
			{color: 'red', opacity: 0.15, weight: 9},
			{color: 'white', opacity: 0.8, weight: 6},
			{color: 'blue', opacity: 0.5, weight: 2}
		]
	}
    })).addTo(locationMap.map);

    L.Routing.errorControl(control).addTo(locationMap.map);
};