var registerFormObject = null;
$(document).ready(function(){
    registerFormObject = new RegisterFormObject($("#register_form"));
});


function RegisterFormObject(formElement){
    this.formElement = formElement;
    //alert($("input[name='email']").attr("value"));
    let thisElement = this;
    $(this.formElement).submit(function(e){
        e.preventDefault();
        //alert();
        thisElement.requestRegister();
    });
}

RegisterFormObject.prototype.checkMail = function(mail){
    let re = /^(?:[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
    
    return re.test(mail);
};


RegisterFormObject.prototype.checkPasswordLenght = function(password){
    return (password.length >= 8);
};

RegisterFormObject.prototype.checkPasswordMatch = function(password, passwordConf){
    return password === passwordConf;
};

RegisterFormObject.prototype.requestRegister = function(){
    let email = $("input[name='email']").val();
    let password = $("input[name='password']").val();
    let passwordConf = $("input[name='password_conf']").val();
    $(".email_info").text("");
    $(".pass_info").text("");
    $(".pass_conf_info").text("");
    if(!this.checkMail(email)){
        $(".email_info").text("Adresse email invalide.");
        return;
    }
    
    
    if(!this.checkPasswordLenght(password)){
        $(".pass_info").text("Mot de passe trop court");
        return;
    }
    
    if(!this.checkPasswordMatch(password, passwordConf)){
        $(".pass_conf_info").text("Le mot de passe ne correspond pas au premier");
        return;
    }
    
    //Envoie de la requete de d'inscription
    
    $.post("?a=ajaxRegister", 
        {user_mail: email, user_password: password, user_conf_password: passwordConf, userType: $("select[name='user_type']").val()}, 
        function(result){
            alert(result);
            var rep = JSON.parse(result.slice(result.indexOf("|"), result.lastIndexOf("|")).substr(1));
                        
            if(rep.result){
                //iconDiv.setAttribute("link", rep.link);
                if(window.navigator.geolocation){
                    alert("disponible");
                    navigator.geolocation.getCurrentPosition(function(position){
                        alert("Latitude: "+position.coords.latitude+" Longitude: "+position.coords.longitude+" Altitude: "+position.coords.latitude);
                        
                       
                        /*L.mapquest.map('gmap', {
                            center: [position.coords.latitude, position.coords.longitude],
                            layers: L.mapquest.tileLayer('map'),
                            zoom: 12
                        });

                        alert("ok");*/

                        
                        //let map = new google.maps.Map(document.getElementById("gmap"), optionsGmaps);
                    });
                }else{
                    alert("non disponible");
                }
            }else{
                alert("error");
                if(!rep.userMail){
                    alert("errorOk");
                    $(".email_info").text(rep.userMailMessage);
                }
            }
        });
};