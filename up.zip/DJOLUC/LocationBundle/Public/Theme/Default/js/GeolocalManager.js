
function GeolocalManager(userId){
    this.userId = userId;
}


GeolocalManager.prototype.locate = function(callback, errorCallback, unsetCallback){
    if ("geolocation" in navigator) {
    // check if geolocation is supported/enabled on current browser
        navigator.geolocation.getCurrentPosition(
            function success(position) {
                // for when getting location is a success
                if(typeof callback === "function"){
                    callback(position.coords.latitude, position.coords.longitude);
                }
                //alert('latitude:'+position.coords.latitude+' longitude:'+position.coords.longitude);
            },
            function error(error_message) {
                // for when getting location results in an error
                if(typeof errorCallback === "function"){
                    errorCallback(error_message);
                }
                //alert('An error has occured while retrieving location'+error_message);
            }  
        );
    } else {
        // geolocation is not supported
        // get your location some other way
        if(typeof unsetCallback === "function"){
            unsetCallback();
        }
        //alert('geolocation is not enabled on this browser');
    }
};


GeolocalManager.prototype.locateIp = function(callback, failCallback){
    $.ajax("http://ip-api.com/json")
    .then(
      function success(response) {
          if(typeof callback === "function"){
              callback(response.countryCode, response.country, response.city, response.lat, response.lon, response.region, response.regionName, response.query);
          }
      },

      function fail(data, status) {
          if(typeof failCallback === "function"){
              failCallback(data, status);
          }
      }
  );
};