<?php

namespace DJOLUC\LocationBundle\Controller\Frontend;

require_once 'App/Controller/BaseController.php';
require_once 'DJOLUC/RegisterBundle/Model/Frontend/UserDataSource.php';
require_once 'DJOLUC/LocationBundle/Model/Frontend/UserLocationDataSource.php';

/**
 * Description of UserLocationController
 *
 * @author djoluc
 */
class UserLocationController extends \App\Controller\BaseController {
    private $userDataSource, 
            $userLoacationDataSource, 
            $userId;
    
    public function __construct() {
        $this->userDataSource = new \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource();
        $this->userLoacationDataSource = new \DJOLUC\LocationBundle\Model\Frontend\UserLocationDataSource();
        $this->userId = \DJOLUC\RegisterBundle\Model\Frontend\UserDataSource::getCurrentUserId();
    }
    
    
    public function addUserLocation(){
        $out = Array(
            "result"=>false,
            "message"=>"Echec lors de l'ajout de la localisation"
        );
        
        if(array_key_exists("sent", $_POST)){
            $longitude = filter_input(INPUT_POST, "longitude");
            $latitude = filter_input(INPUT_POST, "latitude");
            $altitude = filter_input(INPUT_POST, "altitude");
            $country = filter_input(INPUT_POST, "country");
            $town = filter_input(INPUT_POST, "town");
            $district = filter_input(INPUT_POST, "district");
            $means = filter_input(INPUT_POST, "means");
            
            
            if($this->userId > 0 && $this->userLoacationDataSource->addLocation($this->userId, $latitude, $longitude, $altitude, $country, $town, $district, $means, \time())){
                $out["result"] = TRUE;
                $out["message"] = "Réussit!";
            }else{
                $out["message"] = "Utilisateur non connecté!";
            }
        }
        
        
        $this->printDjolucJson($out);
    }
    
    
    public function getUserLastLocation(){
        
        $out["result"] = false;
        $out["longitude"] = 0;
        $out["latitude"] = 0;
        if(array_key_exists("sent", $_POST)){
            $userId = filter_input(INPUT_POST, "userId");
            $userLocation = $this->userLoacationDataSource->getUserLastLocation($userId);
            $out["result"] = TRUE;
            $out["longitude"] = $userLocation->getLongitude();
            $out["latitude"] = $userLocation->getLatitude();
        }
        
        $this->printDjolucJson($out);  
    }
    
    
    public function getArtisanLocation(){
        $out["result"] = false;
        $out["longitude"] = 0;
        $out["latitude"] = 0;
        if(array_key_exists("sent", $_POST)){
            $userId = (int)filter_input(INPUT_GET, "artisanId");
            $userLocation = $this->userLoacationDataSource->getUserLastLocation($userId);
            $out["longitude"] = $userLocation->getLongitude();
            $out["latitude"] = $userLocation->getLatitude();
            if($out["longitude"] != 0 && $out["latitude"] != 0){
                $out["result"] = TRUE;
            }
        }
        
        $this->printDjolucJson($out);  
    }
    
    
    public function displayPageAction() {
        parent::displayPageAction();
    }
    
    

    public static function rooter() {
        parent::rooter();
        
        $thisClass = new \DJOLUC\LocationBundle\Controller\Frontend\UserLocationController();
        
        if(array_key_exists("add", $_GET)){
            $thisClass->addUserLocation();
        }else if(array_key_exists("get", $_GET)){
            $thisClass->getUserLastLocation();
        }else if(array_key_exists("getArtisanLocation", $_GET)){
            $thisClass->getArtisanLocation();
        }else{
            $thisClass->displayPageAction();
        }
    }
}
